const CACHE='work-area-shell-7d802104f35bf40366f1',ASSETS=["/android-release.json","/app-updates.js","/app.js","/ckd-code.js","/ckd.js","/cutting.css","/cutting.js","/heatsink.js","/holding.css","/holding.js","/hs-code.js","/icon.svg","/index.html","/manifest.webmanifest","/offline-build.json","/offline-runtime.js","/offline.css","/offline/licenses/@noble-hashes.txt","/offline/licenses/base64-js.txt","/offline/licenses/buffer.txt","/offline/licenses/fflate.txt","/offline/licenses/ieee754.txt","/offline/licenses/sql.js.txt","/offline/sql-wasm-browser.wasm","/offline/sql-wasm.wasm","/scanner-tools.js","/scanner.css","/scanner.js","/sorting.js","/style.css","/vendor/JsBarcode.code128-3.12.3.min.js","/vendor/THIRD_PARTY_NOTICES.md","/vendor/jsbarcode-LICENSE","/vendor/zxing-0.21.3.min.js","/vendor/zxing-LICENSE","/watch-results.js","/web-boot.js"],SHELL=new Set(ASSETS);
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{for(const url of ASSETS){const response=await fetch(new Request(url,{cache:'reload',credentials:'omit'}));if(!response.ok)throw Error('Incomplete shell');await cache.put(url,response);}}
 catch(error){await caches.delete(CACHE);throw error;}
 // Existing tabs finish on their current version; never replace a running workspace.
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const name of await caches.keys())if(name.startsWith('work-area-shell-')&&name!==CACHE)await caches.delete(name);
})()));
self.addEventListener('message',event=>{if(event.data?.type!=='SHELL_READY'||!event.ports[0])return;event.waitUntil((async()=>{const cache=await caches.open(CACHE),keys=new Set((await cache.keys()).map(r=>new URL(r.url).pathname));event.ports[0].postMessage({ready:ASSETS.every(p=>keys.has(p))});})());});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/downloads/')||['/register','/register.html','/registration-page.js','/registration-page.css'].includes(url.pathname))return;
 const key=request.mode==='navigate'&&(url.pathname==='/'||url.pathname==='/index.html')?'/index.html':url.pathname;
 if(!SHELL.has(key))return;
 event.respondWith((async()=>{const cached=await(await caches.open(CACHE)).match(key);return cached||fetch(request);})());
});
