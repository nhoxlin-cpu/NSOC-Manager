var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err2) => function __init() {
  if (err2) throw err2[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err2 = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../.tools/offline-build/node_modules/base64-js/index.js
var require_base64_js = __commonJS({
  "../.tools/offline-build/node_modules/base64-js/index.js"(exports) {
    "use strict";
    init_polyfills();
    exports.byteLength = byteLength;
    exports.toByteArray = toByteArray;
    exports.fromByteArray = fromByteArray;
    var lookup = [];
    var revLookup = [];
    var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
    var code2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i2 = 0, len = code2.length; i2 < len; ++i2) {
      lookup[i2] = code2[i2];
      revLookup[code2.charCodeAt(i2)] = i2;
    }
    var i2;
    var len;
    revLookup["-".charCodeAt(0)] = 62;
    revLookup["_".charCodeAt(0)] = 63;
    function getLens(b64) {
      var len2 = b64.length;
      if (len2 % 4 > 0) {
        throw new Error("Invalid string. Length must be a multiple of 4");
      }
      var validLen = b64.indexOf("=");
      if (validLen === -1) validLen = len2;
      var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
      return [validLen, placeHoldersLen];
    }
    function byteLength(b64) {
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function _byteLength(b64, validLen, placeHoldersLen) {
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function toByteArray(b64) {
      var tmp;
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
      var curByte = 0;
      var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
      var i3;
      for (i3 = 0; i3 < len2; i3 += 4) {
        tmp = revLookup[b64.charCodeAt(i3)] << 18 | revLookup[b64.charCodeAt(i3 + 1)] << 12 | revLookup[b64.charCodeAt(i3 + 2)] << 6 | revLookup[b64.charCodeAt(i3 + 3)];
        arr[curByte++] = tmp >> 16 & 255;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i3)] << 2 | revLookup[b64.charCodeAt(i3 + 1)] >> 4;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i3)] << 10 | revLookup[b64.charCodeAt(i3 + 1)] << 4 | revLookup[b64.charCodeAt(i3 + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      return arr;
    }
    function tripletToBase64(num) {
      return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
    }
    function encodeChunk(uint8, start, end) {
      var tmp;
      var output = [];
      for (var i3 = start; i3 < end; i3 += 3) {
        tmp = (uint8[i3] << 16 & 16711680) + (uint8[i3 + 1] << 8 & 65280) + (uint8[i3 + 2] & 255);
        output.push(tripletToBase64(tmp));
      }
      return output.join("");
    }
    function fromByteArray(uint8) {
      var tmp;
      var len2 = uint8.length;
      var extraBytes = len2 % 3;
      var parts = [];
      var maxChunkLength = 16383;
      for (var i3 = 0, len22 = len2 - extraBytes; i3 < len22; i3 += maxChunkLength) {
        parts.push(encodeChunk(uint8, i3, i3 + maxChunkLength > len22 ? len22 : i3 + maxChunkLength));
      }
      if (extraBytes === 1) {
        tmp = uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
        );
      } else if (extraBytes === 2) {
        tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
        );
      }
      return parts.join("");
    }
  }
});

// ../.tools/offline-build/node_modules/ieee754/index.js
var require_ieee754 = __commonJS({
  "../.tools/offline-build/node_modules/ieee754/index.js"(exports) {
    init_polyfills();
    exports.read = function(buffer, offset, isLE, mLen, nBytes) {
      var e, m;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var nBits = -7;
      var i2 = isLE ? nBytes - 1 : 0;
      var d = isLE ? -1 : 1;
      var s = buffer[offset + i2];
      i2 += d;
      e = s & (1 << -nBits) - 1;
      s >>= -nBits;
      nBits += eLen;
      for (; nBits > 0; e = e * 256 + buffer[offset + i2], i2 += d, nBits -= 8) {
      }
      m = e & (1 << -nBits) - 1;
      e >>= -nBits;
      nBits += mLen;
      for (; nBits > 0; m = m * 256 + buffer[offset + i2], i2 += d, nBits -= 8) {
      }
      if (e === 0) {
        e = 1 - eBias;
      } else if (e === eMax) {
        return m ? NaN : (s ? -1 : 1) * Infinity;
      } else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
      }
      return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
    };
    exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
      var e, m, c;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
      var i2 = isLE ? 0 : nBytes - 1;
      var d = isLE ? 1 : -1;
      var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
      value = Math.abs(value);
      if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
      } else {
        e = Math.floor(Math.log(value) / Math.LN2);
        if (value * (c = Math.pow(2, -e)) < 1) {
          e--;
          c *= 2;
        }
        if (e + eBias >= 1) {
          value += rt / c;
        } else {
          value += rt * Math.pow(2, 1 - eBias);
        }
        if (value * c >= 2) {
          e++;
          c /= 2;
        }
        if (e + eBias >= eMax) {
          m = 0;
          e = eMax;
        } else if (e + eBias >= 1) {
          m = (value * c - 1) * Math.pow(2, mLen);
          e = e + eBias;
        } else {
          m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
          e = 0;
        }
      }
      for (; mLen >= 8; buffer[offset + i2] = m & 255, i2 += d, m /= 256, mLen -= 8) {
      }
      e = e << mLen | m;
      eLen += mLen;
      for (; eLen > 0; buffer[offset + i2] = e & 255, i2 += d, e /= 256, eLen -= 8) {
      }
      buffer[offset + i2 - d] |= s * 128;
    };
  }
});

// ../.tools/offline-build/node_modules/buffer/index.js
var require_buffer = __commonJS({
  "../.tools/offline-build/node_modules/buffer/index.js"(exports) {
    "use strict";
    init_polyfills();
    var base64 = require_base64_js();
    var ieee754 = require_ieee754();
    var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
    exports.Buffer = Buffer3;
    exports.SlowBuffer = SlowBuffer;
    exports.INSPECT_MAX_BYTES = 50;
    var K_MAX_LENGTH = 2147483647;
    exports.kMaxLength = K_MAX_LENGTH;
    Buffer3.TYPED_ARRAY_SUPPORT = typedArraySupport();
    if (!Buffer3.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
      console.error(
        "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
      );
    }
    function typedArraySupport() {
      try {
        const arr = new Uint8Array(1);
        const proto = { foo: function() {
          return 42;
        } };
        Object.setPrototypeOf(proto, Uint8Array.prototype);
        Object.setPrototypeOf(arr, proto);
        return arr.foo() === 42;
      } catch (e) {
        return false;
      }
    }
    Object.defineProperty(Buffer3.prototype, "parent", {
      enumerable: true,
      get: function() {
        if (!Buffer3.isBuffer(this)) return void 0;
        return this.buffer;
      }
    });
    Object.defineProperty(Buffer3.prototype, "offset", {
      enumerable: true,
      get: function() {
        if (!Buffer3.isBuffer(this)) return void 0;
        return this.byteOffset;
      }
    });
    function createBuffer(length) {
      if (length > K_MAX_LENGTH) {
        throw new RangeError('The value "' + length + '" is invalid for option "size"');
      }
      const buf = new Uint8Array(length);
      Object.setPrototypeOf(buf, Buffer3.prototype);
      return buf;
    }
    function Buffer3(arg, encodingOrOffset, length) {
      if (typeof arg === "number") {
        if (typeof encodingOrOffset === "string") {
          throw new TypeError(
            'The "string" argument must be of type string. Received type number'
          );
        }
        return allocUnsafe(arg);
      }
      return from(arg, encodingOrOffset, length);
    }
    Buffer3.poolSize = 8192;
    function from(value, encodingOrOffset, length) {
      if (typeof value === "string") {
        return fromString(value, encodingOrOffset);
      }
      if (ArrayBuffer.isView(value)) {
        return fromArrayView(value);
      }
      if (value == null) {
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
        return fromArrayBuffer(value, encodingOrOffset, length);
      }
      if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
        return fromArrayBuffer(value, encodingOrOffset, length);
      }
      if (typeof value === "number") {
        throw new TypeError(
          'The "value" argument must not be of type number. Received type number'
        );
      }
      const valueOf = value.valueOf && value.valueOf();
      if (valueOf != null && valueOf !== value) {
        return Buffer3.from(valueOf, encodingOrOffset, length);
      }
      const b = fromObject(value);
      if (b) return b;
      if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
        return Buffer3.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
      }
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
      );
    }
    Buffer3.from = function(value, encodingOrOffset, length) {
      return from(value, encodingOrOffset, length);
    };
    Object.setPrototypeOf(Buffer3.prototype, Uint8Array.prototype);
    Object.setPrototypeOf(Buffer3, Uint8Array);
    function assertSize(size) {
      if (typeof size !== "number") {
        throw new TypeError('"size" argument must be of type number');
      } else if (size < 0) {
        throw new RangeError('The value "' + size + '" is invalid for option "size"');
      }
    }
    function alloc(size, fill2, encoding) {
      assertSize(size);
      if (size <= 0) {
        return createBuffer(size);
      }
      if (fill2 !== void 0) {
        return typeof encoding === "string" ? createBuffer(size).fill(fill2, encoding) : createBuffer(size).fill(fill2);
      }
      return createBuffer(size);
    }
    Buffer3.alloc = function(size, fill2, encoding) {
      return alloc(size, fill2, encoding);
    };
    function allocUnsafe(size) {
      assertSize(size);
      return createBuffer(size < 0 ? 0 : checked(size) | 0);
    }
    Buffer3.allocUnsafe = function(size) {
      return allocUnsafe(size);
    };
    Buffer3.allocUnsafeSlow = function(size) {
      return allocUnsafe(size);
    };
    function fromString(string, encoding) {
      if (typeof encoding !== "string" || encoding === "") {
        encoding = "utf8";
      }
      if (!Buffer3.isEncoding(encoding)) {
        throw new TypeError("Unknown encoding: " + encoding);
      }
      const length = byteLength(string, encoding) | 0;
      let buf = createBuffer(length);
      const actual = buf.write(string, encoding);
      if (actual !== length) {
        buf = buf.slice(0, actual);
      }
      return buf;
    }
    function fromArrayLike(array) {
      const length = array.length < 0 ? 0 : checked(array.length) | 0;
      const buf = createBuffer(length);
      for (let i2 = 0; i2 < length; i2 += 1) {
        buf[i2] = array[i2] & 255;
      }
      return buf;
    }
    function fromArrayView(arrayView) {
      if (isInstance(arrayView, Uint8Array)) {
        const copy = new Uint8Array(arrayView);
        return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
      }
      return fromArrayLike(arrayView);
    }
    function fromArrayBuffer(array, byteOffset, length) {
      if (byteOffset < 0 || array.byteLength < byteOffset) {
        throw new RangeError('"offset" is outside of buffer bounds');
      }
      if (array.byteLength < byteOffset + (length || 0)) {
        throw new RangeError('"length" is outside of buffer bounds');
      }
      let buf;
      if (byteOffset === void 0 && length === void 0) {
        buf = new Uint8Array(array);
      } else if (length === void 0) {
        buf = new Uint8Array(array, byteOffset);
      } else {
        buf = new Uint8Array(array, byteOffset, length);
      }
      Object.setPrototypeOf(buf, Buffer3.prototype);
      return buf;
    }
    function fromObject(obj) {
      if (Buffer3.isBuffer(obj)) {
        const len = checked(obj.length) | 0;
        const buf = createBuffer(len);
        if (buf.length === 0) {
          return buf;
        }
        obj.copy(buf, 0, 0, len);
        return buf;
      }
      if (obj.length !== void 0) {
        if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
          return createBuffer(0);
        }
        return fromArrayLike(obj);
      }
      if (obj.type === "Buffer" && Array.isArray(obj.data)) {
        return fromArrayLike(obj.data);
      }
    }
    function checked(length) {
      if (length >= K_MAX_LENGTH) {
        throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
      }
      return length | 0;
    }
    function SlowBuffer(length) {
      if (+length != length) {
        length = 0;
      }
      return Buffer3.alloc(+length);
    }
    Buffer3.isBuffer = function isBuffer(b) {
      return b != null && b._isBuffer === true && b !== Buffer3.prototype;
    };
    Buffer3.compare = function compare(a, b) {
      if (isInstance(a, Uint8Array)) a = Buffer3.from(a, a.offset, a.byteLength);
      if (isInstance(b, Uint8Array)) b = Buffer3.from(b, b.offset, b.byteLength);
      if (!Buffer3.isBuffer(a) || !Buffer3.isBuffer(b)) {
        throw new TypeError(
          'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
        );
      }
      if (a === b) return 0;
      let x3 = a.length;
      let y = b.length;
      for (let i2 = 0, len = Math.min(x3, y); i2 < len; ++i2) {
        if (a[i2] !== b[i2]) {
          x3 = a[i2];
          y = b[i2];
          break;
        }
      }
      if (x3 < y) return -1;
      if (y < x3) return 1;
      return 0;
    };
    Buffer3.isEncoding = function isEncoding(encoding) {
      switch (String(encoding).toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "latin1":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return true;
        default:
          return false;
      }
    };
    Buffer3.concat = function concat(list, length) {
      if (!Array.isArray(list)) {
        throw new TypeError('"list" argument must be an Array of Buffers');
      }
      if (list.length === 0) {
        return Buffer3.alloc(0);
      }
      let i2;
      if (length === void 0) {
        length = 0;
        for (i2 = 0; i2 < list.length; ++i2) {
          length += list[i2].length;
        }
      }
      const buffer = Buffer3.allocUnsafe(length);
      let pos = 0;
      for (i2 = 0; i2 < list.length; ++i2) {
        let buf = list[i2];
        if (isInstance(buf, Uint8Array)) {
          if (pos + buf.length > buffer.length) {
            if (!Buffer3.isBuffer(buf)) buf = Buffer3.from(buf);
            buf.copy(buffer, pos);
          } else {
            Uint8Array.prototype.set.call(
              buffer,
              buf,
              pos
            );
          }
        } else if (!Buffer3.isBuffer(buf)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        } else {
          buf.copy(buffer, pos);
        }
        pos += buf.length;
      }
      return buffer;
    };
    function byteLength(string, encoding) {
      if (Buffer3.isBuffer(string)) {
        return string.length;
      }
      if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
        return string.byteLength;
      }
      if (typeof string !== "string") {
        throw new TypeError(
          'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
        );
      }
      const len = string.length;
      const mustMatch = arguments.length > 2 && arguments[2] === true;
      if (!mustMatch && len === 0) return 0;
      let loweredCase = false;
      for (; ; ) {
        switch (encoding) {
          case "ascii":
          case "latin1":
          case "binary":
            return len;
          case "utf8":
          case "utf-8":
            return utf8ToBytes(string).length;
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return len * 2;
          case "hex":
            return len >>> 1;
          case "base64":
            return base64ToBytes(string).length;
          default:
            if (loweredCase) {
              return mustMatch ? -1 : utf8ToBytes(string).length;
            }
            encoding = ("" + encoding).toLowerCase();
            loweredCase = true;
        }
      }
    }
    Buffer3.byteLength = byteLength;
    function slowToString(encoding, start, end) {
      let loweredCase = false;
      if (start === void 0 || start < 0) {
        start = 0;
      }
      if (start > this.length) {
        return "";
      }
      if (end === void 0 || end > this.length) {
        end = this.length;
      }
      if (end <= 0) {
        return "";
      }
      end >>>= 0;
      start >>>= 0;
      if (end <= start) {
        return "";
      }
      if (!encoding) encoding = "utf8";
      while (true) {
        switch (encoding) {
          case "hex":
            return hexSlice(this, start, end);
          case "utf8":
          case "utf-8":
            return utf8Slice(this, start, end);
          case "ascii":
            return asciiSlice(this, start, end);
          case "latin1":
          case "binary":
            return latin1Slice(this, start, end);
          case "base64":
            return base64Slice(this, start, end);
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return utf16leSlice(this, start, end);
          default:
            if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
            encoding = (encoding + "").toLowerCase();
            loweredCase = true;
        }
      }
    }
    Buffer3.prototype._isBuffer = true;
    function swap(b, n, m) {
      const i2 = b[n];
      b[n] = b[m];
      b[m] = i2;
    }
    Buffer3.prototype.swap16 = function swap16() {
      const len = this.length;
      if (len % 2 !== 0) {
        throw new RangeError("Buffer size must be a multiple of 16-bits");
      }
      for (let i2 = 0; i2 < len; i2 += 2) {
        swap(this, i2, i2 + 1);
      }
      return this;
    };
    Buffer3.prototype.swap32 = function swap32() {
      const len = this.length;
      if (len % 4 !== 0) {
        throw new RangeError("Buffer size must be a multiple of 32-bits");
      }
      for (let i2 = 0; i2 < len; i2 += 4) {
        swap(this, i2, i2 + 3);
        swap(this, i2 + 1, i2 + 2);
      }
      return this;
    };
    Buffer3.prototype.swap64 = function swap64() {
      const len = this.length;
      if (len % 8 !== 0) {
        throw new RangeError("Buffer size must be a multiple of 64-bits");
      }
      for (let i2 = 0; i2 < len; i2 += 8) {
        swap(this, i2, i2 + 7);
        swap(this, i2 + 1, i2 + 6);
        swap(this, i2 + 2, i2 + 5);
        swap(this, i2 + 3, i2 + 4);
      }
      return this;
    };
    Buffer3.prototype.toString = function toString() {
      const length = this.length;
      if (length === 0) return "";
      if (arguments.length === 0) return utf8Slice(this, 0, length);
      return slowToString.apply(this, arguments);
    };
    Buffer3.prototype.toLocaleString = Buffer3.prototype.toString;
    Buffer3.prototype.equals = function equals(b) {
      if (!Buffer3.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
      if (this === b) return true;
      return Buffer3.compare(this, b) === 0;
    };
    Buffer3.prototype.inspect = function inspect() {
      let str2 = "";
      const max = exports.INSPECT_MAX_BYTES;
      str2 = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
      if (this.length > max) str2 += " ... ";
      return "<Buffer " + str2 + ">";
    };
    if (customInspectSymbol) {
      Buffer3.prototype[customInspectSymbol] = Buffer3.prototype.inspect;
    }
    Buffer3.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
      if (isInstance(target, Uint8Array)) {
        target = Buffer3.from(target, target.offset, target.byteLength);
      }
      if (!Buffer3.isBuffer(target)) {
        throw new TypeError(
          'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
        );
      }
      if (start === void 0) {
        start = 0;
      }
      if (end === void 0) {
        end = target ? target.length : 0;
      }
      if (thisStart === void 0) {
        thisStart = 0;
      }
      if (thisEnd === void 0) {
        thisEnd = this.length;
      }
      if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
        throw new RangeError("out of range index");
      }
      if (thisStart >= thisEnd && start >= end) {
        return 0;
      }
      if (thisStart >= thisEnd) {
        return -1;
      }
      if (start >= end) {
        return 1;
      }
      start >>>= 0;
      end >>>= 0;
      thisStart >>>= 0;
      thisEnd >>>= 0;
      if (this === target) return 0;
      let x3 = thisEnd - thisStart;
      let y = end - start;
      const len = Math.min(x3, y);
      const thisCopy = this.slice(thisStart, thisEnd);
      const targetCopy = target.slice(start, end);
      for (let i2 = 0; i2 < len; ++i2) {
        if (thisCopy[i2] !== targetCopy[i2]) {
          x3 = thisCopy[i2];
          y = targetCopy[i2];
          break;
        }
      }
      if (x3 < y) return -1;
      if (y < x3) return 1;
      return 0;
    };
    function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
      if (buffer.length === 0) return -1;
      if (typeof byteOffset === "string") {
        encoding = byteOffset;
        byteOffset = 0;
      } else if (byteOffset > 2147483647) {
        byteOffset = 2147483647;
      } else if (byteOffset < -2147483648) {
        byteOffset = -2147483648;
      }
      byteOffset = +byteOffset;
      if (numberIsNaN(byteOffset)) {
        byteOffset = dir ? 0 : buffer.length - 1;
      }
      if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
      if (byteOffset >= buffer.length) {
        if (dir) return -1;
        else byteOffset = buffer.length - 1;
      } else if (byteOffset < 0) {
        if (dir) byteOffset = 0;
        else return -1;
      }
      if (typeof val === "string") {
        val = Buffer3.from(val, encoding);
      }
      if (Buffer3.isBuffer(val)) {
        if (val.length === 0) {
          return -1;
        }
        return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
      } else if (typeof val === "number") {
        val = val & 255;
        if (typeof Uint8Array.prototype.indexOf === "function") {
          if (dir) {
            return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
          } else {
            return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
          }
        }
        return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
      }
      throw new TypeError("val must be string, number or Buffer");
    }
    function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
      let indexSize = 1;
      let arrLength = arr.length;
      let valLength = val.length;
      if (encoding !== void 0) {
        encoding = String(encoding).toLowerCase();
        if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
          if (arr.length < 2 || val.length < 2) {
            return -1;
          }
          indexSize = 2;
          arrLength /= 2;
          valLength /= 2;
          byteOffset /= 2;
        }
      }
      function read2(buf, i3) {
        if (indexSize === 1) {
          return buf[i3];
        } else {
          return buf.readUInt16BE(i3 * indexSize);
        }
      }
      let i2;
      if (dir) {
        let foundIndex = -1;
        for (i2 = byteOffset; i2 < arrLength; i2++) {
          if (read2(arr, i2) === read2(val, foundIndex === -1 ? 0 : i2 - foundIndex)) {
            if (foundIndex === -1) foundIndex = i2;
            if (i2 - foundIndex + 1 === valLength) return foundIndex * indexSize;
          } else {
            if (foundIndex !== -1) i2 -= i2 - foundIndex;
            foundIndex = -1;
          }
        }
      } else {
        if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
        for (i2 = byteOffset; i2 >= 0; i2--) {
          let found = true;
          for (let j = 0; j < valLength; j++) {
            if (read2(arr, i2 + j) !== read2(val, j)) {
              found = false;
              break;
            }
          }
          if (found) return i2;
        }
      }
      return -1;
    }
    Buffer3.prototype.includes = function includes(val, byteOffset, encoding) {
      return this.indexOf(val, byteOffset, encoding) !== -1;
    };
    Buffer3.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
      return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
    };
    Buffer3.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
      return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
    };
    function hexWrite(buf, string, offset, length) {
      offset = Number(offset) || 0;
      const remaining = buf.length - offset;
      if (!length) {
        length = remaining;
      } else {
        length = Number(length);
        if (length > remaining) {
          length = remaining;
        }
      }
      const strLen = string.length;
      if (length > strLen / 2) {
        length = strLen / 2;
      }
      let i2;
      for (i2 = 0; i2 < length; ++i2) {
        const parsed = parseInt(string.substr(i2 * 2, 2), 16);
        if (numberIsNaN(parsed)) return i2;
        buf[offset + i2] = parsed;
      }
      return i2;
    }
    function utf8Write(buf, string, offset, length) {
      return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
    }
    function asciiWrite(buf, string, offset, length) {
      return blitBuffer(asciiToBytes(string), buf, offset, length);
    }
    function base64Write(buf, string, offset, length) {
      return blitBuffer(base64ToBytes(string), buf, offset, length);
    }
    function ucs2Write(buf, string, offset, length) {
      return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
    }
    Buffer3.prototype.write = function write(string, offset, length, encoding) {
      if (offset === void 0) {
        encoding = "utf8";
        length = this.length;
        offset = 0;
      } else if (length === void 0 && typeof offset === "string") {
        encoding = offset;
        length = this.length;
        offset = 0;
      } else if (isFinite(offset)) {
        offset = offset >>> 0;
        if (isFinite(length)) {
          length = length >>> 0;
          if (encoding === void 0) encoding = "utf8";
        } else {
          encoding = length;
          length = void 0;
        }
      } else {
        throw new Error(
          "Buffer.write(string, encoding, offset[, length]) is no longer supported"
        );
      }
      const remaining = this.length - offset;
      if (length === void 0 || length > remaining) length = remaining;
      if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
        throw new RangeError("Attempt to write outside buffer bounds");
      }
      if (!encoding) encoding = "utf8";
      let loweredCase = false;
      for (; ; ) {
        switch (encoding) {
          case "hex":
            return hexWrite(this, string, offset, length);
          case "utf8":
          case "utf-8":
            return utf8Write(this, string, offset, length);
          case "ascii":
          case "latin1":
          case "binary":
            return asciiWrite(this, string, offset, length);
          case "base64":
            return base64Write(this, string, offset, length);
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return ucs2Write(this, string, offset, length);
          default:
            if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
            encoding = ("" + encoding).toLowerCase();
            loweredCase = true;
        }
      }
    };
    Buffer3.prototype.toJSON = function toJSON() {
      return {
        type: "Buffer",
        data: Array.prototype.slice.call(this._arr || this, 0)
      };
    };
    function base64Slice(buf, start, end) {
      if (start === 0 && end === buf.length) {
        return base64.fromByteArray(buf);
      } else {
        return base64.fromByteArray(buf.slice(start, end));
      }
    }
    function utf8Slice(buf, start, end) {
      end = Math.min(buf.length, end);
      const res = [];
      let i2 = start;
      while (i2 < end) {
        const firstByte = buf[i2];
        let codePoint = null;
        let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
        if (i2 + bytesPerSequence <= end) {
          let secondByte, thirdByte, fourthByte, tempCodePoint;
          switch (bytesPerSequence) {
            case 1:
              if (firstByte < 128) {
                codePoint = firstByte;
              }
              break;
            case 2:
              secondByte = buf[i2 + 1];
              if ((secondByte & 192) === 128) {
                tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                if (tempCodePoint > 127) {
                  codePoint = tempCodePoint;
                }
              }
              break;
            case 3:
              secondByte = buf[i2 + 1];
              thirdByte = buf[i2 + 2];
              if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                  codePoint = tempCodePoint;
                }
              }
              break;
            case 4:
              secondByte = buf[i2 + 1];
              thirdByte = buf[i2 + 2];
              fourthByte = buf[i2 + 3];
              if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                  codePoint = tempCodePoint;
                }
              }
          }
        }
        if (codePoint === null) {
          codePoint = 65533;
          bytesPerSequence = 1;
        } else if (codePoint > 65535) {
          codePoint -= 65536;
          res.push(codePoint >>> 10 & 1023 | 55296);
          codePoint = 56320 | codePoint & 1023;
        }
        res.push(codePoint);
        i2 += bytesPerSequence;
      }
      return decodeCodePointsArray(res);
    }
    var MAX_ARGUMENTS_LENGTH = 4096;
    function decodeCodePointsArray(codePoints) {
      const len = codePoints.length;
      if (len <= MAX_ARGUMENTS_LENGTH) {
        return String.fromCharCode.apply(String, codePoints);
      }
      let res = "";
      let i2 = 0;
      while (i2 < len) {
        res += String.fromCharCode.apply(
          String,
          codePoints.slice(i2, i2 += MAX_ARGUMENTS_LENGTH)
        );
      }
      return res;
    }
    function asciiSlice(buf, start, end) {
      let ret = "";
      end = Math.min(buf.length, end);
      for (let i2 = start; i2 < end; ++i2) {
        ret += String.fromCharCode(buf[i2] & 127);
      }
      return ret;
    }
    function latin1Slice(buf, start, end) {
      let ret = "";
      end = Math.min(buf.length, end);
      for (let i2 = start; i2 < end; ++i2) {
        ret += String.fromCharCode(buf[i2]);
      }
      return ret;
    }
    function hexSlice(buf, start, end) {
      const len = buf.length;
      if (!start || start < 0) start = 0;
      if (!end || end < 0 || end > len) end = len;
      let out = "";
      for (let i2 = start; i2 < end; ++i2) {
        out += hexSliceLookupTable[buf[i2]];
      }
      return out;
    }
    function utf16leSlice(buf, start, end) {
      const bytes = buf.slice(start, end);
      let res = "";
      for (let i2 = 0; i2 < bytes.length - 1; i2 += 2) {
        res += String.fromCharCode(bytes[i2] + bytes[i2 + 1] * 256);
      }
      return res;
    }
    Buffer3.prototype.slice = function slice(start, end) {
      const len = this.length;
      start = ~~start;
      end = end === void 0 ? len : ~~end;
      if (start < 0) {
        start += len;
        if (start < 0) start = 0;
      } else if (start > len) {
        start = len;
      }
      if (end < 0) {
        end += len;
        if (end < 0) end = 0;
      } else if (end > len) {
        end = len;
      }
      if (end < start) end = start;
      const newBuf = this.subarray(start, end);
      Object.setPrototypeOf(newBuf, Buffer3.prototype);
      return newBuf;
    };
    function checkOffset(offset, ext, length) {
      if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
      if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
    }
    Buffer3.prototype.readUintLE = Buffer3.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) checkOffset(offset, byteLength2, this.length);
      let val = this[offset];
      let mul = 1;
      let i2 = 0;
      while (++i2 < byteLength2 && (mul *= 256)) {
        val += this[offset + i2] * mul;
      }
      return val;
    };
    Buffer3.prototype.readUintBE = Buffer3.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) {
        checkOffset(offset, byteLength2, this.length);
      }
      let val = this[offset + --byteLength2];
      let mul = 1;
      while (byteLength2 > 0 && (mul *= 256)) {
        val += this[offset + --byteLength2] * mul;
      }
      return val;
    };
    Buffer3.prototype.readUint8 = Buffer3.prototype.readUInt8 = function readUInt8(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 1, this.length);
      return this[offset];
    };
    Buffer3.prototype.readUint16LE = Buffer3.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 2, this.length);
      return this[offset] | this[offset + 1] << 8;
    };
    Buffer3.prototype.readUint16BE = Buffer3.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 2, this.length);
      return this[offset] << 8 | this[offset + 1];
    };
    Buffer3.prototype.readUint32LE = Buffer3.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
    };
    Buffer3.prototype.readUint32BE = Buffer3.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
    };
    Buffer3.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
      offset = offset >>> 0;
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === void 0 || last === void 0) {
        boundsError(offset, this.length - 8);
      }
      const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
      const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
      return BigInt(lo) + (BigInt(hi) << BigInt(32));
    });
    Buffer3.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
      offset = offset >>> 0;
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === void 0 || last === void 0) {
        boundsError(offset, this.length - 8);
      }
      const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
      const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
      return (BigInt(hi) << BigInt(32)) + BigInt(lo);
    });
    Buffer3.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) checkOffset(offset, byteLength2, this.length);
      let val = this[offset];
      let mul = 1;
      let i2 = 0;
      while (++i2 < byteLength2 && (mul *= 256)) {
        val += this[offset + i2] * mul;
      }
      mul *= 128;
      if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
      return val;
    };
    Buffer3.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) checkOffset(offset, byteLength2, this.length);
      let i2 = byteLength2;
      let mul = 1;
      let val = this[offset + --i2];
      while (i2 > 0 && (mul *= 256)) {
        val += this[offset + --i2] * mul;
      }
      mul *= 128;
      if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
      return val;
    };
    Buffer3.prototype.readInt8 = function readInt8(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 1, this.length);
      if (!(this[offset] & 128)) return this[offset];
      return (255 - this[offset] + 1) * -1;
    };
    Buffer3.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 2, this.length);
      const val = this[offset] | this[offset + 1] << 8;
      return val & 32768 ? val | 4294901760 : val;
    };
    Buffer3.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 2, this.length);
      const val = this[offset + 1] | this[offset] << 8;
      return val & 32768 ? val | 4294901760 : val;
    };
    Buffer3.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
    };
    Buffer3.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
    };
    Buffer3.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
      offset = offset >>> 0;
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === void 0 || last === void 0) {
        boundsError(offset, this.length - 8);
      }
      const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
      return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
    });
    Buffer3.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
      offset = offset >>> 0;
      validateNumber(offset, "offset");
      const first = this[offset];
      const last = this[offset + 7];
      if (first === void 0 || last === void 0) {
        boundsError(offset, this.length - 8);
      }
      const val = (first << 24) + // Overflow
      this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
      return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
    });
    Buffer3.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return ieee754.read(this, offset, true, 23, 4);
    };
    Buffer3.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 4, this.length);
      return ieee754.read(this, offset, false, 23, 4);
    };
    Buffer3.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 8, this.length);
      return ieee754.read(this, offset, true, 52, 8);
    };
    Buffer3.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
      offset = offset >>> 0;
      if (!noAssert) checkOffset(offset, 8, this.length);
      return ieee754.read(this, offset, false, 52, 8);
    };
    function checkInt(buf, value, offset, ext, max, min) {
      if (!Buffer3.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
      if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
      if (offset + ext > buf.length) throw new RangeError("Index out of range");
    }
    Buffer3.prototype.writeUintLE = Buffer3.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
      value = +value;
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) {
        const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
        checkInt(this, value, offset, byteLength2, maxBytes, 0);
      }
      let mul = 1;
      let i2 = 0;
      this[offset] = value & 255;
      while (++i2 < byteLength2 && (mul *= 256)) {
        this[offset + i2] = value / mul & 255;
      }
      return offset + byteLength2;
    };
    Buffer3.prototype.writeUintBE = Buffer3.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
      value = +value;
      offset = offset >>> 0;
      byteLength2 = byteLength2 >>> 0;
      if (!noAssert) {
        const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
        checkInt(this, value, offset, byteLength2, maxBytes, 0);
      }
      let i2 = byteLength2 - 1;
      let mul = 1;
      this[offset + i2] = value & 255;
      while (--i2 >= 0 && (mul *= 256)) {
        this[offset + i2] = value / mul & 255;
      }
      return offset + byteLength2;
    };
    Buffer3.prototype.writeUint8 = Buffer3.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
      this[offset] = value & 255;
      return offset + 1;
    };
    Buffer3.prototype.writeUint16LE = Buffer3.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
      this[offset] = value & 255;
      this[offset + 1] = value >>> 8;
      return offset + 2;
    };
    Buffer3.prototype.writeUint16BE = Buffer3.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
      this[offset] = value >>> 8;
      this[offset + 1] = value & 255;
      return offset + 2;
    };
    Buffer3.prototype.writeUint32LE = Buffer3.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
      this[offset + 3] = value >>> 24;
      this[offset + 2] = value >>> 16;
      this[offset + 1] = value >>> 8;
      this[offset] = value & 255;
      return offset + 4;
    };
    Buffer3.prototype.writeUint32BE = Buffer3.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
      this[offset] = value >>> 24;
      this[offset + 1] = value >>> 16;
      this[offset + 2] = value >>> 8;
      this[offset + 3] = value & 255;
      return offset + 4;
    };
    function wrtBigUInt64LE(buf, value, offset, min, max) {
      checkIntBI(value, min, max, buf, offset, 7);
      let lo = Number(value & BigInt(4294967295));
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      lo = lo >> 8;
      buf[offset++] = lo;
      let hi = Number(value >> BigInt(32) & BigInt(4294967295));
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      hi = hi >> 8;
      buf[offset++] = hi;
      return offset;
    }
    function wrtBigUInt64BE(buf, value, offset, min, max) {
      checkIntBI(value, min, max, buf, offset, 7);
      let lo = Number(value & BigInt(4294967295));
      buf[offset + 7] = lo;
      lo = lo >> 8;
      buf[offset + 6] = lo;
      lo = lo >> 8;
      buf[offset + 5] = lo;
      lo = lo >> 8;
      buf[offset + 4] = lo;
      let hi = Number(value >> BigInt(32) & BigInt(4294967295));
      buf[offset + 3] = hi;
      hi = hi >> 8;
      buf[offset + 2] = hi;
      hi = hi >> 8;
      buf[offset + 1] = hi;
      hi = hi >> 8;
      buf[offset] = hi;
      return offset + 8;
    }
    Buffer3.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
      return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
    });
    Buffer3.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
      return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
    });
    Buffer3.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) {
        const limit = Math.pow(2, 8 * byteLength2 - 1);
        checkInt(this, value, offset, byteLength2, limit - 1, -limit);
      }
      let i2 = 0;
      let mul = 1;
      let sub = 0;
      this[offset] = value & 255;
      while (++i2 < byteLength2 && (mul *= 256)) {
        if (value < 0 && sub === 0 && this[offset + i2 - 1] !== 0) {
          sub = 1;
        }
        this[offset + i2] = (value / mul >> 0) - sub & 255;
      }
      return offset + byteLength2;
    };
    Buffer3.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) {
        const limit = Math.pow(2, 8 * byteLength2 - 1);
        checkInt(this, value, offset, byteLength2, limit - 1, -limit);
      }
      let i2 = byteLength2 - 1;
      let mul = 1;
      let sub = 0;
      this[offset + i2] = value & 255;
      while (--i2 >= 0 && (mul *= 256)) {
        if (value < 0 && sub === 0 && this[offset + i2 + 1] !== 0) {
          sub = 1;
        }
        this[offset + i2] = (value / mul >> 0) - sub & 255;
      }
      return offset + byteLength2;
    };
    Buffer3.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
      if (value < 0) value = 255 + value + 1;
      this[offset] = value & 255;
      return offset + 1;
    };
    Buffer3.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
      this[offset] = value & 255;
      this[offset + 1] = value >>> 8;
      return offset + 2;
    };
    Buffer3.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
      this[offset] = value >>> 8;
      this[offset + 1] = value & 255;
      return offset + 2;
    };
    Buffer3.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
      this[offset] = value & 255;
      this[offset + 1] = value >>> 8;
      this[offset + 2] = value >>> 16;
      this[offset + 3] = value >>> 24;
      return offset + 4;
    };
    Buffer3.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
      if (value < 0) value = 4294967295 + value + 1;
      this[offset] = value >>> 24;
      this[offset + 1] = value >>> 16;
      this[offset + 2] = value >>> 8;
      this[offset + 3] = value & 255;
      return offset + 4;
    };
    Buffer3.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
      return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    });
    Buffer3.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
      return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    });
    function checkIEEE754(buf, value, offset, ext, max, min) {
      if (offset + ext > buf.length) throw new RangeError("Index out of range");
      if (offset < 0) throw new RangeError("Index out of range");
    }
    function writeFloat(buf, value, offset, littleEndian, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) {
        checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
      }
      ieee754.write(buf, value, offset, littleEndian, 23, 4);
      return offset + 4;
    }
    Buffer3.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
      return writeFloat(this, value, offset, true, noAssert);
    };
    Buffer3.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
      return writeFloat(this, value, offset, false, noAssert);
    };
    function writeDouble(buf, value, offset, littleEndian, noAssert) {
      value = +value;
      offset = offset >>> 0;
      if (!noAssert) {
        checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
      }
      ieee754.write(buf, value, offset, littleEndian, 52, 8);
      return offset + 8;
    }
    Buffer3.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
      return writeDouble(this, value, offset, true, noAssert);
    };
    Buffer3.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
      return writeDouble(this, value, offset, false, noAssert);
    };
    Buffer3.prototype.copy = function copy(target, targetStart, start, end) {
      if (!Buffer3.isBuffer(target)) throw new TypeError("argument should be a Buffer");
      if (!start) start = 0;
      if (!end && end !== 0) end = this.length;
      if (targetStart >= target.length) targetStart = target.length;
      if (!targetStart) targetStart = 0;
      if (end > 0 && end < start) end = start;
      if (end === start) return 0;
      if (target.length === 0 || this.length === 0) return 0;
      if (targetStart < 0) {
        throw new RangeError("targetStart out of bounds");
      }
      if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
      if (end < 0) throw new RangeError("sourceEnd out of bounds");
      if (end > this.length) end = this.length;
      if (target.length - targetStart < end - start) {
        end = target.length - targetStart + start;
      }
      const len = end - start;
      if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
        this.copyWithin(targetStart, start, end);
      } else {
        Uint8Array.prototype.set.call(
          target,
          this.subarray(start, end),
          targetStart
        );
      }
      return len;
    };
    Buffer3.prototype.fill = function fill2(val, start, end, encoding) {
      if (typeof val === "string") {
        if (typeof start === "string") {
          encoding = start;
          start = 0;
          end = this.length;
        } else if (typeof end === "string") {
          encoding = end;
          end = this.length;
        }
        if (encoding !== void 0 && typeof encoding !== "string") {
          throw new TypeError("encoding must be a string");
        }
        if (typeof encoding === "string" && !Buffer3.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        if (val.length === 1) {
          const code2 = val.charCodeAt(0);
          if (encoding === "utf8" && code2 < 128 || encoding === "latin1") {
            val = code2;
          }
        }
      } else if (typeof val === "number") {
        val = val & 255;
      } else if (typeof val === "boolean") {
        val = Number(val);
      }
      if (start < 0 || this.length < start || this.length < end) {
        throw new RangeError("Out of range index");
      }
      if (end <= start) {
        return this;
      }
      start = start >>> 0;
      end = end === void 0 ? this.length : end >>> 0;
      if (!val) val = 0;
      let i2;
      if (typeof val === "number") {
        for (i2 = start; i2 < end; ++i2) {
          this[i2] = val;
        }
      } else {
        const bytes = Buffer3.isBuffer(val) ? val : Buffer3.from(val, encoding);
        const len = bytes.length;
        if (len === 0) {
          throw new TypeError('The value "' + val + '" is invalid for argument "value"');
        }
        for (i2 = 0; i2 < end - start; ++i2) {
          this[i2 + start] = bytes[i2 % len];
        }
      }
      return this;
    };
    var errors = {};
    function E(sym, getMessage, Base) {
      errors[sym] = class NodeError extends Base {
        constructor() {
          super();
          Object.defineProperty(this, "message", {
            value: getMessage.apply(this, arguments),
            writable: true,
            configurable: true
          });
          this.name = `${this.name} [${sym}]`;
          this.stack;
          delete this.name;
        }
        get code() {
          return sym;
        }
        set code(value) {
          Object.defineProperty(this, "code", {
            configurable: true,
            enumerable: true,
            value,
            writable: true
          });
        }
        toString() {
          return `${this.name} [${sym}]: ${this.message}`;
        }
      };
    }
    E(
      "ERR_BUFFER_OUT_OF_BOUNDS",
      function(name) {
        if (name) {
          return `${name} is outside of buffer bounds`;
        }
        return "Attempt to access memory outside buffer bounds";
      },
      RangeError
    );
    E(
      "ERR_INVALID_ARG_TYPE",
      function(name, actual) {
        return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
      },
      TypeError
    );
    E(
      "ERR_OUT_OF_RANGE",
      function(str2, range, input) {
        let msg = `The value of "${str2}" is out of range.`;
        let received = input;
        if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
          received = addNumericalSeparator(String(input));
        } else if (typeof input === "bigint") {
          received = String(input);
          if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
            received = addNumericalSeparator(received);
          }
          received += "n";
        }
        msg += ` It must be ${range}. Received ${received}`;
        return msg;
      },
      RangeError
    );
    function addNumericalSeparator(val) {
      let res = "";
      let i2 = val.length;
      const start = val[0] === "-" ? 1 : 0;
      for (; i2 >= start + 4; i2 -= 3) {
        res = `_${val.slice(i2 - 3, i2)}${res}`;
      }
      return `${val.slice(0, i2)}${res}`;
    }
    function checkBounds(buf, offset, byteLength2) {
      validateNumber(offset, "offset");
      if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
        boundsError(offset, buf.length - (byteLength2 + 1));
      }
    }
    function checkIntBI(value, min, max, buf, offset, byteLength2) {
      if (value > max || value < min) {
        const n = typeof min === "bigint" ? "n" : "";
        let range;
        if (byteLength2 > 3) {
          if (min === 0 || min === BigInt(0)) {
            range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
          } else {
            range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
          }
        } else {
          range = `>= ${min}${n} and <= ${max}${n}`;
        }
        throw new errors.ERR_OUT_OF_RANGE("value", range, value);
      }
      checkBounds(buf, offset, byteLength2);
    }
    function validateNumber(value, name) {
      if (typeof value !== "number") {
        throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
      }
    }
    function boundsError(value, length, type) {
      if (Math.floor(value) !== value) {
        validateNumber(value, type);
        throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
      }
      if (length < 0) {
        throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
      }
      throw new errors.ERR_OUT_OF_RANGE(
        type || "offset",
        `>= ${type ? 1 : 0} and <= ${length}`,
        value
      );
    }
    var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
    function base64clean(str2) {
      str2 = str2.split("=")[0];
      str2 = str2.trim().replace(INVALID_BASE64_RE, "");
      if (str2.length < 2) return "";
      while (str2.length % 4 !== 0) {
        str2 = str2 + "=";
      }
      return str2;
    }
    function utf8ToBytes(string, units) {
      units = units || Infinity;
      let codePoint;
      const length = string.length;
      let leadSurrogate = null;
      const bytes = [];
      for (let i2 = 0; i2 < length; ++i2) {
        codePoint = string.charCodeAt(i2);
        if (codePoint > 55295 && codePoint < 57344) {
          if (!leadSurrogate) {
            if (codePoint > 56319) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              continue;
            } else if (i2 + 1 === length) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              continue;
            }
            leadSurrogate = codePoint;
            continue;
          }
          if (codePoint < 56320) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
            leadSurrogate = codePoint;
            continue;
          }
          codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
        } else if (leadSurrogate) {
          if ((units -= 3) > -1) bytes.push(239, 191, 189);
        }
        leadSurrogate = null;
        if (codePoint < 128) {
          if ((units -= 1) < 0) break;
          bytes.push(codePoint);
        } else if (codePoint < 2048) {
          if ((units -= 2) < 0) break;
          bytes.push(
            codePoint >> 6 | 192,
            codePoint & 63 | 128
          );
        } else if (codePoint < 65536) {
          if ((units -= 3) < 0) break;
          bytes.push(
            codePoint >> 12 | 224,
            codePoint >> 6 & 63 | 128,
            codePoint & 63 | 128
          );
        } else if (codePoint < 1114112) {
          if ((units -= 4) < 0) break;
          bytes.push(
            codePoint >> 18 | 240,
            codePoint >> 12 & 63 | 128,
            codePoint >> 6 & 63 | 128,
            codePoint & 63 | 128
          );
        } else {
          throw new Error("Invalid code point");
        }
      }
      return bytes;
    }
    function asciiToBytes(str2) {
      const byteArray = [];
      for (let i2 = 0; i2 < str2.length; ++i2) {
        byteArray.push(str2.charCodeAt(i2) & 255);
      }
      return byteArray;
    }
    function utf16leToBytes(str2, units) {
      let c, hi, lo;
      const byteArray = [];
      for (let i2 = 0; i2 < str2.length; ++i2) {
        if ((units -= 2) < 0) break;
        c = str2.charCodeAt(i2);
        hi = c >> 8;
        lo = c % 256;
        byteArray.push(lo);
        byteArray.push(hi);
      }
      return byteArray;
    }
    function base64ToBytes(str2) {
      return base64.toByteArray(base64clean(str2));
    }
    function blitBuffer(src, dst, offset, length) {
      let i2;
      for (i2 = 0; i2 < length; ++i2) {
        if (i2 + offset >= dst.length || i2 >= src.length) break;
        dst[i2 + offset] = src[i2];
      }
      return i2;
    }
    function isInstance(obj, type) {
      return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
    }
    function numberIsNaN(obj) {
      return obj !== obj;
    }
    var hexSliceLookupTable = (function() {
      const alphabet = "0123456789abcdef";
      const table = new Array(256);
      for (let i2 = 0; i2 < 16; ++i2) {
        const i16 = i2 * 16;
        for (let j = 0; j < 16; ++j) {
          table[i16 + j] = alphabet[i2] + alphabet[j];
        }
      }
      return table;
    })();
    function defineBigIntMethod(fn) {
      return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
    }
    function BufferBigIntNotDefined() {
      throw new Error("BigInt not supported");
    }
  }
});

// offline/polyfills.mjs
var import_buffer;
var init_polyfills = __esm({
  "offline/polyfills.mjs"() {
    import_buffer = __toESM(require_buffer(), 1);
  }
});

// ../.tools/offline-build/node_modules/sql.js/dist/sql-wasm-browser.js
var require_sql_wasm_browser = __commonJS({
  "../.tools/offline-build/node_modules/sql.js/dist/sql-wasm-browser.js"(exports, module) {
    init_polyfills();
    var initSqlJsPromise = void 0;
    var initSqlJs2 = function(moduleConfig) {
      if (initSqlJsPromise) {
        return initSqlJsPromise;
      }
      initSqlJsPromise = new Promise(function(resolveModule, reject) {
        var _a2, _b2;
        var Module = typeof moduleConfig !== "undefined" ? moduleConfig : {};
        var originalOnAbortFunction = Module["onAbort"];
        Module["onAbort"] = function(errorThatCausedAbort) {
          reject(new Error(errorThatCausedAbort));
          if (originalOnAbortFunction) {
            originalOnAbortFunction(errorThatCausedAbort);
          }
        };
        Module["postRun"] = Module["postRun"] || [];
        Module["postRun"].push(function() {
          resolveModule(Module);
        });
        module = void 0;
        var k;
        k || (k = typeof Module !== "undefined" ? Module : {});
        var aa = !!globalThis.window, ba = !!globalThis.WorkerGlobalScope;
        k.onRuntimeInitialized = function() {
          function a(f, h) {
            mb(f, h instanceof Error ? h.message : String(h), -1);
          }
          function b(f, h) {
            switch (typeof h) {
              case "boolean":
                ic(f, h ? 1 : 0);
                break;
              case "number":
                jc(f, h);
                break;
              case "string":
                kc(f, h, l(h), -1);
                break;
              case "object":
                if (h === null) nb(f);
                else if (h.length != null) {
                  var p = ca(h.length);
                  v.set(h, p);
                  lc2(f, p, h.length, -1);
                  da(p);
                } else mb(f, "Wrong API use : tried to return a value of an unknown type (" + h + ").", -1);
                break;
              default:
                nb(f);
            }
          }
          function d(f, h) {
            for (var p = [], r = 0; r < f; r += 1) {
              var u = y(
                h + 4 * r,
                "i32"
              ), w = mc(u);
              if (w === 1 || w === 2) u = nc(u);
              else if (w === 3) w = ob(u), u = oc(u), u = A(u, w, true);
              else if (w === 4) {
                w = u;
                u = ob(w);
                w = pc(w);
                for (var x3 = new Uint8Array(u), G = 0; G < u; G += 1) x3[G] = v[w + G];
                u = x3;
              } else u = null;
              p.push(u);
            }
            return p;
          }
          function c(f, h) {
            this.Va = f;
            this.db = h;
            this.Ta = 1;
            this.Eb = [];
          }
          function e(f, h) {
            this.db = h;
            this.tb = ea(f);
            if (this.tb === null) throw Error("Unable to allocate memory for the SQL string");
            this.zb = this.tb;
            this.fb = this.Kb = null;
          }
          function g(f) {
            this.filename = "dbfile_" + (4294967295 * Math.random() >>> 0);
            f != null && fa(
              this.filename,
              f
            );
            this.handleError(F(this.filename, q));
            this.db = y(q, "i32");
            z && qc(this.db);
            this.Bb = {};
            this.ab = /* @__PURE__ */ new Map();
          }
          function m(f, h) {
            return f.replace(/[A-Z]/g, function(p) {
              return p.toLowerCase();
            }) + ":" + h;
          }
          function t(f) {
            f.forEach(ja);
          }
          var z = k.useOldExtensionFunctions !== false, q = ka(4), n = k.cwrap, F = n("sqlite3_open", "number", ["string", "number"]), S = n("sqlite3_close_v2", "number", ["number"]), Oa = n("sqlite3_backup_init", "number", ["number", "string", "number", "string"]), ma = n("sqlite3_backup_step", "number", ["number", "number"]), na = n(
            "sqlite3_backup_finish",
            "number",
            ["number"]
          ), ha = n("sqlite3_exec", "number", ["number", "number", "number", "number", "number"]), za = n("sqlite3_changes", "number", ["number"]), N = n("sqlite3_sql", "string", ["number"]), rc = n("sqlite3_normalized_sql", "string", ["number"]), Pa = n("sqlite3_prepare_v2", "number", ["number", "number", "number", "number", "number"]), sc = n("sqlite3_bind_text", "number", ["number", "number", "number", "number", "number"]), qb = n("sqlite3_bind_blob", "number", ["number", "number", "number", "number", "number"]), tc = n(
            "sqlite3_bind_double",
            "number",
            ["number", "number", "number"]
          ), uc = n("sqlite3_bind_int", "number", ["number", "number", "number"]), vc = n("sqlite3_bind_parameter_index", "number", ["number", "string"]), wc = n("sqlite3_step", "number", ["number"]), ia = n("sqlite3_errmsg", "string", ["number"]), xc = n("sqlite3_column_count", "number", ["number"]), yc = n("sqlite3_data_count", "number", ["number"]), zc = n("sqlite3_column_double", "number", ["number", "number"]), Ac = n("sqlite3_column_text", "number", ["number", "number"]), Bc = n("sqlite3_column_blob", "number", [
            "number",
            "number"
          ]), rb = n("sqlite3_column_bytes", "number", ["number", "number"]), Cc = n("sqlite3_column_type", "number", ["number", "number"]), Dc = n("sqlite3_column_name", "string", ["number", "number"]), Ec = n("sqlite3_reset", "number", ["number"]), Fc = n("sqlite3_clear_bindings", "number", ["number"]), Gc = n("sqlite3_finalize", "number", ["number"]), sb = n("sqlite3_create_function_v2", "number", "number string number number number number number number number".split(" ")), mc = n("sqlite3_value_type", "number", ["number"]), ob = n(
            "sqlite3_value_bytes",
            "number",
            ["number"]
          ), oc = n("sqlite3_value_text", "number", ["number"]), pc = n("sqlite3_value_blob", "number", ["number"]), nc = n("sqlite3_value_double", "number", ["number"]), jc = n("sqlite3_result_double", "", ["number", "number"]), nb = n("sqlite3_result_null", "", ["number"]), kc = n("sqlite3_result_text", "", ["number", "string", "number", "number"]), lc2 = n("sqlite3_result_blob", "", ["number", "number", "number", "number"]), ic = n("sqlite3_result_int", "", ["number", "number"]), mb = n("sqlite3_result_error", "", ["number", "string", "number"]), tb = n("sqlite3_aggregate_context", "number", ["number", "number"]), qc = n("RegisterExtensionFunctions", "number", ["number"]), ub = n("sqlite3_update_hook", "number", ["number", "number", "number"]);
          c.prototype.bind = function(f) {
            if (!this.Va) throw "Statement closed";
            this.reset();
            return Array.isArray(f) ? this.bc(f) : f != null && typeof f === "object" ? this.cc(f) : true;
          };
          c.prototype.step = function() {
            if (!this.Va) throw "Statement closed";
            this.Ta = 1;
            var f = wc(this.Va);
            switch (f) {
              case 100:
                return true;
              case 101:
                return false;
              default:
                throw this.db.handleError(f);
            }
          };
          c.prototype.Ub = function(f) {
            f == null && (f = this.Ta, this.Ta += 1);
            return zc(this.Va, f);
          };
          c.prototype.oc = function(f) {
            f == null && (f = this.Ta, this.Ta += 1);
            if (typeof BigInt !== "function") throw Error("BigInt is not supported");
            return BigInt(this.Vb(f));
          };
          c.prototype.Vb = function(f) {
            f == null && (f = this.Ta, this.Ta += 1);
            var h = Ac(this.Va, f);
            f = rb(this.Va, f);
            return A(h, f, true);
          };
          c.prototype.getBlob = function(f) {
            f == null && (f = this.Ta, this.Ta += 1);
            var h = rb(this.Va, f);
            f = Bc(this.Va, f);
            for (var p = new Uint8Array(h), r = 0; r < h; r += 1) p[r] = v[f + r];
            return p;
          };
          c.prototype.get = function(f, h) {
            h = h || {};
            f != null && this.bind(f) && this.step();
            f = [];
            for (var p = yc(this.Va), r = 0; r < p; r += 1) switch (Cc(this.Va, r)) {
              case 1:
                var u = h.useBigInt ? this.oc(r) : this.Ub(r);
                f.push(u);
                break;
              case 2:
                f.push(this.Ub(r));
                break;
              case 3:
                f.push(this.Vb(r));
                break;
              case 4:
                f.push(this.getBlob(r));
                break;
              default:
                f.push(null);
            }
            return f;
          };
          c.prototype.Ib = function() {
            for (var f = [], h = xc(this.Va), p = 0; p < h; p += 1) f.push(Dc(this.Va, p));
            return f;
          };
          c.prototype.Tb = function(f, h) {
            var p = this.get(f, h);
            f = this.Ib();
            return Object.fromEntries(f.map(function(r, u) {
              return [r, p[u]];
            }));
          };
          c.prototype.tc = function() {
            return N(this.Va);
          };
          c.prototype.qc = function() {
            return rc(this.Va);
          };
          c.prototype.run = function(f) {
            f != null && this.bind(f);
            this.step();
            return this.reset();
          };
          c.prototype.Pb = function(f, h) {
            h == null && (h = this.Ta, this.Ta += 1);
            var p = ea(f);
            this.Eb.push(p);
            this.db.handleError(sc(this.Va, h, p, l(f), 0));
          };
          c.prototype.ac = function(f, h) {
            h == null && (h = this.Ta, this.Ta += 1);
            var p = ca(f.length);
            v.set(f, p);
            this.Eb.push(p);
            this.db.handleError(qb(
              this.Va,
              h,
              p,
              f.length,
              0
            ));
          };
          c.prototype.Ob = function(f, h) {
            h == null && (h = this.Ta, this.Ta += 1);
            this.db.handleError((f === (f | 0) ? uc : tc)(this.Va, h, f));
          };
          c.prototype.dc = function(f) {
            f == null && (f = this.Ta, this.Ta += 1);
            qb(this.Va, f, 0, 0, 0);
          };
          c.prototype.Qb = function(f, h) {
            h == null && (h = this.Ta, this.Ta += 1);
            switch (typeof f) {
              case "string":
                this.Pb(f, h);
                return;
              case "number":
                this.Ob(f, h);
                return;
              case "bigint":
                this.Pb(f.toString(), h);
                return;
              case "boolean":
                this.Ob(f + 0, h);
                return;
              case "object":
                if (f === null) {
                  this.dc(h);
                  return;
                }
                if (f.length != null) {
                  this.ac(
                    f,
                    h
                  );
                  return;
                }
            }
            throw "Wrong API use : tried to bind a value of an unknown type (" + f + ").";
          };
          c.prototype.cc = function(f) {
            var h = this;
            Object.keys(f).forEach(function(p) {
              var r = vc(h.Va, p);
              r !== 0 && h.Qb(f[p], r);
            });
            return true;
          };
          c.prototype.bc = function(f) {
            for (var h = 0; h < f.length; h += 1) this.Qb(f[h], h + 1);
            return true;
          };
          c.prototype.reset = function() {
            this.Hb();
            return Fc(this.Va) === 0 && Ec(this.Va) === 0;
          };
          c.prototype.Hb = function() {
            for (var f; (f = this.Eb.pop()) !== void 0; ) da(f);
          };
          c.prototype.jb = function() {
            this.Hb();
            var f = Gc(this.Va) === 0;
            delete this.db.Bb[this.Va];
            this.Va = 0;
            return f;
          };
          e.prototype.next = function() {
            if (this.tb === null) return { done: true };
            this.fb !== null && (this.fb.jb(), this.fb = null);
            if (!this.db.db) throw this.ub(), Error("Database closed");
            var f = la(), h = ka(4);
            oa(q);
            oa(h);
            try {
              this.db.handleError(Pa(this.db.db, this.zb, -1, q, h));
              this.zb = y(h, "i32");
              var p = y(q, "i32");
              if (p === 0) return this.ub(), { done: true };
              this.fb = new c(p, this.db);
              this.db.Bb[p] = this.fb;
              return { value: this.fb, done: false };
            } catch (r) {
              throw this.Kb = A(this.zb), this.ub(), r;
            } finally {
              pa(f);
            }
          };
          e.prototype.ub = function() {
            da(this.tb);
            this.tb = null;
          };
          e.prototype["return"] = function() {
            this.fb !== null && (this.fb.jb(), this.fb = null);
            this.ub();
            return { done: true };
          };
          e.prototype.rc = function() {
            return this.Kb !== null ? this.Kb : A(this.zb);
          };
          typeof Symbol === "function" && typeof Symbol.iterator === "symbol" && (e.prototype[Symbol.iterator] = function() {
            return this;
          });
          g.prototype.run = function(f, h) {
            if (!this.db) throw "Database closed";
            if (h) {
              f = this.Lb(f, h);
              try {
                f.step();
              } finally {
                f.jb();
              }
            } else {
              f = ea(f);
              try {
                this.handleError(ha(this.db, f, 0, 0, q));
              } finally {
                da(f);
              }
            }
            return this;
          };
          g.prototype.exec = function(f, h, p) {
            if (!this.db) throw "Database closed";
            var r = la(), u = null, w = null, x3 = null;
            try {
              x3 = w = ea(f);
              var G = ka(4);
              for (f = []; y(x3, "i8") !== 0; ) {
                oa(q);
                oa(G);
                this.handleError(Pa(this.db, x3, -1, q, G));
                var T = y(q, "i32");
                x3 = y(G, "i32");
                if (T !== 0) {
                  var D = null;
                  u = new c(T, this);
                  for (h != null && u.bind(h); u.step(); ) D === null && (D = { columns: u.Ib(), values: [] }, f.push(D)), D.values.push(u.get(null, p));
                  u.jb();
                }
              }
              return f;
            } catch (K) {
              throw u && u.jb(), K;
            } finally {
              w && da(w), pa(r);
            }
          };
          g.prototype.lc = function(f, h, p, r, u) {
            typeof h === "function" && (r = p, p = h, h = void 0);
            f = this.Lb(f, h);
            try {
              for (; f.step(); ) p(f.Tb(null, u));
            } finally {
              f.jb();
            }
            if (typeof r === "function") return r();
          };
          g.prototype.Lb = function(f, h) {
            f = ea(f);
            try {
              oa(q), this.handleError(Pa(this.db, f, -1, q, 0));
            } finally {
              da(f);
            }
            f = y(q, "i32");
            if (f === 0) throw "Nothing to prepare";
            var p = new c(f, this);
            h != null && p.bind(h);
            return this.Bb[f] = p;
          };
          g.prototype.wc = function(f) {
            return new e(f, this);
          };
          g.prototype.nc = function() {
            if (!this.db) throw Error("Database closed");
            var f = this.filename + "_export";
            fa(f, []);
            var h = 0, p = 0;
            try {
              var r = B(f).node, u = null, w = r.Qa.write;
              r.Qa = Object.create(r.Qa);
              r.Qa.write = function(T, D, K, V, U) {
                if (u === null) return w(T, D, K, V, U);
                r.Ua.set(D.subarray(K, K + V), U);
                r.Wa = Math.max(r.Wa, U + V);
                return V;
              };
              var x3 = F(f, q);
              h = y(q, "i32");
              if (x3 !== 0) throw Error(ia(h));
              p = Oa(h, "main", this.db, "main");
              if (p === 0) throw Error(ia(h));
              x3 = ma(p, 0);
              if (x3 === 0) {
                var G = this.exec("PRAGMA main.page_count; PRAGMA main.page_size");
                u = new Uint8Array(G[0].values[0][0] * G[1].values[0][0]);
                r.Ua = u;
                x3 = ma(p, -1);
              }
              if (x3 === 5 || x3 === 6) throw Error("Unable to export: SQLite is busy or locked. Finish active write transactions before exporting.");
              if (x3 !== 101) throw Error(ia(h));
              x3 = na(p);
              p = 0;
              if (x3 !== 0) throw Error(ia(h));
              x3 = S(h);
              if (x3 !== 0) throw Error(ia(h));
              h = 0;
              u = new Uint8Array(r.Ua.buffer, r.Ua.byteOffset, r.Wa);
              u.length > 0 && (u[18] = 1, u[19] = 1);
              return u;
            } finally {
              p !== 0 && na(p), h !== 0 && S(h), qa("/" + f);
            }
          };
          g.prototype.close = function() {
            this.db !== null && (Object.values(this.Bb).forEach(function(f) {
              f.jb();
            }), this.ab.forEach(t), this.ab.clear(), this.lb && (ja(this.lb), this.lb = void 0), this.handleError(S(this.db)), qa("/" + this.filename), this.db = null);
          };
          g.prototype.handleError = function(f) {
            if (f === 0) return null;
            f = ia(this.db);
            throw Error(f);
          };
          g.prototype.sc = function() {
            return za(this.db);
          };
          g.prototype.jc = function(f, h) {
            var p = m(f, h.length);
            this.ab.has(p) && (t(this.ab.get(p)), this.ab.delete(p));
            var r = ra(function(u, w, x3) {
              w = d(w, x3);
              try {
                var G = h.apply(null, w);
              } catch (T) {
                a(u, T);
                return;
              }
              b(u, G);
            }, "viii");
            this.ab.set(p, [r]);
            this.handleError(sb(this.db, f, h.length, 1, 0, r, 0, 0, 0));
            return this;
          };
          g.prototype.hc = function(f, h) {
            function p(D) {
              x3.has(D) || x3.set(D, r());
              return x3.get(D);
            }
            var r = h.init || function() {
              return null;
            }, u = h.finalize || function(D) {
              return D;
            }, w = h.step;
            if (!w) throw "An aggregate function must have a step function in " + f;
            var x3 = /* @__PURE__ */ new Map();
            h = m(f, w.length - 1);
            this.ab.has(h) && (t(this.ab.get(h)), this.ab.delete(h));
            var G = ra(function(D, K, V) {
              var U = tb(D, 1), Ra = p(U);
              K = d(K, V);
              Ra = [Ra].concat(K);
              try {
                x3.set(U, w.apply(null, Ra));
              } catch (Hc) {
                x3.delete(U), a(D, Hc);
              }
            }, "viii"), T = ra(function(D) {
              var K = tb(D, 1);
              try {
                var V = u(p(K));
              } catch (U) {
                x3.delete(K);
                a(D, U);
                return;
              }
              b(D, V);
              x3.delete(K);
            }, "vi");
            this.ab.set(h, [G, T]);
            this.handleError(sb(
              this.db,
              f,
              w.length - 1,
              1,
              0,
              0,
              G,
              T,
              0
            ));
            return this;
          };
          g.prototype.Dc = function(f) {
            this.lb && (ub(this.db, 0, 0), ja(this.lb), this.lb = void 0);
            if (!f) return this;
            this.lb = ra(function(h, p, r, u, w) {
              switch (p) {
                case 18:
                  h = "insert";
                  break;
                case 23:
                  h = "update";
                  break;
                case 9:
                  h = "delete";
                  break;
                default:
                  throw "unknown operationCode in updateHook callback: " + p;
              }
              r = A(r);
              u = A(u);
              if (w > Number.MAX_SAFE_INTEGER) throw "rowId too big to fit inside a Number";
              f(h, r, u, Number(w));
            }, "viiiij");
            ub(this.db, this.lb, 0);
            return this;
          };
          c.prototype.bind = c.prototype.bind;
          c.prototype.step = c.prototype.step;
          c.prototype.get = c.prototype.get;
          c.prototype.getColumnNames = c.prototype.Ib;
          c.prototype.getAsObject = c.prototype.Tb;
          c.prototype.getSQL = c.prototype.tc;
          c.prototype.getNormalizedSQL = c.prototype.qc;
          c.prototype.run = c.prototype.run;
          c.prototype.reset = c.prototype.reset;
          c.prototype.freemem = c.prototype.Hb;
          c.prototype.free = c.prototype.jb;
          e.prototype.next = e.prototype.next;
          e.prototype.getRemainingSQL = e.prototype.rc;
          g.prototype.run = g.prototype.run;
          g.prototype.exec = g.prototype.exec;
          g.prototype.each = g.prototype.lc;
          g.prototype.prepare = g.prototype.Lb;
          g.prototype.iterateStatements = g.prototype.wc;
          g.prototype["export"] = g.prototype.nc;
          g.prototype.close = g.prototype.close;
          g.prototype.handleError = g.prototype.handleError;
          g.prototype.getRowsModified = g.prototype.sc;
          g.prototype.create_function = g.prototype.jc;
          g.prototype.create_aggregate = g.prototype.hc;
          g.prototype.updateHook = g.prototype.Dc;
          k.Database = g;
        };
        var sa = "./this.program", ta = (_b2 = (_a2 = globalThis.document) == null ? void 0 : _a2.currentScript) == null ? void 0 : _b2.src;
        ba && (ta = self.location.href);
        var ua = "", va, wa;
        if (aa || ba) {
          try {
            ua = new URL(".", ta).href;
          } catch {
          }
          ba && (wa = (a) => {
            var b = new XMLHttpRequest();
            b.open("GET", a, false);
            b.responseType = "arraybuffer";
            b.send(null);
            return new Uint8Array(b.response);
          });
          va = async (a) => {
            a = await fetch(a, { credentials: "same-origin" });
            if (a.ok) return a.arrayBuffer();
            throw Error(a.status + " : " + a.url);
          };
        }
        var xa = console.log.bind(console), C = console.error.bind(console), ya, Aa = false, Ba;
        function Ca() {
          var _a3;
          if (!((_a3 = v == null ? void 0 : v.buffer) == null ? void 0 : _a3.resizable)) {
            var a = Da.buffer;
            v = new Int8Array(a);
            Ea = new Int16Array(a);
            E = new Uint8Array(a);
            H = new Int32Array(a);
            I = new Uint32Array(a);
            Fa = new Float32Array(a);
            Ga = new Float64Array(a);
            J = new BigInt64Array(a);
          }
        }
        function Ha() {
          var a = k.preRun;
          a && (typeof a === "function" && (a = [a]), Ia.push(...a));
          for (a = Ia; a.length > 0; ) a.shift()(k);
        }
        function Ja() {
          var a = k.postRun;
          a && (typeof a === "function" && (a = [a]), Ka.push(...a));
          for (a = Ka; a.length > 0; ) a.shift()(k);
        }
        function La(a) {
          var _a3;
          (_a3 = k.onAbort) == null ? void 0 : _a3.call(k, a);
          a = `Aborted(${a})`;
          C(a);
          Aa = true;
          throw new WebAssembly.RuntimeError(a + ". Build with -sASSERTIONS for more info.");
        }
        var Ma;
        async function Na(a) {
          if (!ya) try {
            return await va(a);
          } catch {
          }
          if (a == Ma && ya) a = new Uint8Array(ya);
          else if (wa) a = wa(a);
          else throw "both async and sync fetching of the wasm failed";
          return a;
        }
        async function Qa(a, b) {
          try {
            var d = await Na(a);
            return await WebAssembly.instantiate(d, b);
          } catch (c) {
            C(`failed to asynchronously prepare wasm: ${c}`), La(c);
          }
        }
        async function Sa(a) {
          var b = Ma;
          if (!ya) try {
            var d = fetch(b, { credentials: "same-origin" });
            return await WebAssembly.instantiateStreaming(d, a);
          } catch (c) {
            C(`wasm streaming compile failed: ${c}`), C("falling back to ArrayBuffer instantiation");
          }
          return Qa(b, a);
        }
        class Ta {
          name = "ExitStatus";
          constructor(a) {
            this.message = `Program terminated with exit(${a})`;
            this.status = a;
          }
        }
        var v, Ka = [], Ia = [], Ua = true, E, Va = new TextDecoder(), Wa = (a, b, d, c) => {
          d = b + d;
          if (c) return d;
          for (; a[b] && !(b >= d); ) ++b;
          return b;
        }, A = (a, b, d) => a ? Va.decode(E.subarray(a, Wa(E, a, b, d))) : "", Xa = (a, b) => {
          for (var d = 0, c = a.length - 1; c >= 0; c--) {
            var e = a[c];
            e === "." ? a.splice(c, 1) : e === ".." ? (a.splice(c, 1), d++) : d && (a.splice(c, 1), d--);
          }
          if (b) for (; d; d--) a.unshift("..");
          return a;
        }, Ya = (a) => {
          var b = a.charAt(0) === "/", d = a.slice(-1) === "/";
          (a = Xa(a.split("/").filter((c) => !!c), !b).join("/")) || b || (a = ".");
          a && d && (a += "/");
          return (b ? "/" : "") + a;
        }, Za = (a) => {
          var b = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/.exec(a).slice(1);
          a = b[0];
          b = b[1];
          if (!a && !b) return ".";
          b && (b = b.slice(0, -1));
          return a + b;
        }, $a = (a) => a && a.match(/([^\/]+|\/)\/*$/)[1], ab = (...a) => {
          for (var b = "", d = false, c = a.length - 1; c >= -1 && !d; c--) {
            d = c >= 0 ? a[c] : "/";
            if (typeof d !== "string") throw new TypeError("Arguments to path.resolve must be strings");
            if (!d) return "";
            b = d + "/" + b;
            d = d.charAt(0) === "/";
          }
          b = Xa(b.split("/").filter((e) => !!e), !d).join("/");
          return (d ? "/" : "") + b || ".";
        }, l = (a) => {
          for (var b = 0, d = 0; d < a.length; ++d) {
            var c = a.codePointAt(d);
            c <= 127 ? b++ : c <= 2047 ? b += 2 : c <= 65535 ? b += 3 : (b += 4, d++);
          }
          return b;
        }, L = (a, b, d, c) => {
          if (!(c > 0)) return 0;
          var e = d;
          c = d + c - 1;
          for (var g = 0; g < a.length; ++g) {
            var m = a.codePointAt(g);
            if (m <= 127) {
              if (d >= c) break;
              b[d++] = m;
            } else if (m <= 2047) {
              if (d + 1 >= c) break;
              b[d++] = 192 | m >> 6;
              b[d++] = 128 | m & 63;
            } else if (m <= 65535) {
              if (d + 2 >= c) break;
              b[d++] = 224 | m >> 12;
              b[d++] = 128 | m >> 6 & 63;
              b[d++] = 128 | m & 63;
            } else {
              if (d + 3 >= c) break;
              b[d++] = 240 | m >> 18;
              b[d++] = 128 | m >> 12 & 63;
              b[d++] = 128 | m >> 6 & 63;
              b[d++] = 128 | m & 63;
              g++;
            }
          }
          b[d] = 0;
          return d - e;
        }, bb = (a) => {
          var b = Array(l(a) + 1);
          a = L(a, b, 0, b.length);
          b.length = a;
          return b;
        }, cb = (a, b) => {
          var d = 0;
          a && (d |= 365);
          b && (d |= 146);
          return d;
        }, M = { cb: null, hb() {
          return M.createNode(null, "/", 16895, 0);
        }, createNode(a, b, d, c) {
          if ((d & 61440) === 24576 || (d & 61440) === 4096) throw new O(63);
          M.cb || (M.cb = { dir: { node: { $a: M.Ra.$a, eb: M.Ra.eb, rb: M.Ra.rb, wb: M.Ra.wb, Zb: M.Ra.Zb, Db: M.Ra.Db, Ab: M.Ra.Ab, Nb: M.Ra.Nb, Cb: M.Ra.Cb }, stream: { bb: M.Qa.bb } }, file: { node: { $a: M.Ra.$a, eb: M.Ra.eb }, stream: { bb: M.Qa.bb, read: M.Qa.read, write: M.Qa.write, xb: M.Qa.xb, yb: M.Qa.yb } }, link: { node: { $a: M.Ra.$a, eb: M.Ra.eb, kb: M.Ra.kb }, stream: {} }, Rb: { node: { $a: M.Ra.$a, eb: M.Ra.eb }, stream: db } });
          d = eb(a, b, d, c);
          P(d.mode) ? (d.Ra = M.cb.dir.node, d.Qa = M.cb.dir.stream, d.Ua = {}) : (d.mode & 61440) === 32768 ? (d.Ra = M.cb.file.node, d.Qa = M.cb.file.stream, d.Wa = 0, d.Ua = M.mc ?? (M.mc = new Uint8Array(0))) : (d.mode & 61440) === 40960 ? (d.Ra = M.cb.link.node, d.Qa = M.cb.link.stream) : (d.mode & 61440) === 8192 && (d.Ra = M.cb.Rb.node, d.Qa = M.cb.Rb.stream);
          d.gb = d.Ya = d.Xa = Date.now();
          a && (a.Ua[b] = d, a.gb = a.Ya = a.Xa = d.gb);
          return d;
        }, Ra: { $a(a) {
          var b = {};
          b.kc = (a.mode & 61440) === 8192 ? a.id : 1;
          b.vc = a.id;
          b.mode = a.mode;
          b.yc = 1;
          b.uid = 0;
          b.uc = 0;
          b.sb = a.sb;
          P(a.mode) ? b.size = 4096 : (a.mode & 61440) === 32768 ? b.size = a.Wa : (a.mode & 61440) === 40960 ? b.size = a.link.length : b.size = 0;
          b.gb = new Date(a.gb);
          b.Ya = new Date(a.Ya);
          b.Xa = new Date(a.Xa);
          b.ec = 4096;
          b.fc = Math.ceil(b.size / b.ec);
          return b;
        }, eb(a, b) {
          for (var d of ["mode", "atime", "mtime", "ctime"]) b[d] != null && (a[d] = b[d]);
          b.size !== void 0 && (b = b.size, a.Wa != b && (d = a.Ua, a.Ua = new Uint8Array(b), a.Ua.set(d.subarray(0, Math.min(b, a.Wa))), a.Wa = b));
        }, rb() {
          M.Fb || (M.Fb = new O(44), M.Fb.stack = "<generic error, no stack>");
          throw M.Fb;
        }, wb(a, b, d, c) {
          return M.createNode(
            a,
            b,
            d,
            c
          );
        }, Zb(a, b, d) {
          try {
            var c = fb(b, d);
          } catch (g) {
          }
          if (c && P(a.mode)) for (var e in c.Ua) throw new O(55);
          delete a.parent.Ua[a.name];
          b.Ua[d] = a;
          a.name = d;
          b.Xa = b.Ya = a.parent.Xa = a.parent.Ya = Date.now();
        }, Db(a, b) {
          delete a.Ua[b];
          a.Xa = a.Ya = Date.now();
        }, Ab(a, b) {
          var d = fb(a, b), c;
          for (c in d.Ua) throw new O(55);
          delete a.Ua[b];
          a.Xa = a.Ya = Date.now();
        }, Nb(a) {
          return [".", "..", ...Object.keys(a.Ua)];
        }, Cb(a, b, d) {
          a = M.createNode(a, b, 41471, 0);
          a.link = d;
          return a;
        }, kb(a) {
          if ((a.mode & 61440) !== 40960) throw new O(28);
          return a.link;
        } }, Qa: { read(a, b, d, c, e) {
          if (e >= a.node.Wa) return 0;
          c = Math.min(a.node.Wa - e, c);
          b.set(a.node.Ua.subarray(e, e + c), d);
          return c;
        }, write(a, b, d, c, e, g) {
          b.buffer === v.buffer && (g = false);
          if (!c) return 0;
          a = a.node;
          a.Ya = a.Xa = Date.now();
          if (g) a.Ua = b.subarray(d, d + c), a.Wa = c;
          else if (a.Wa || e) {
            g = e + c;
            var m = a.Ua.length;
            m >= g || (g = Math.max(g, m * (m < 1048576 ? 2 : 1.125) >>> 0), m && (g = Math.max(g, 256)), m = a.Ua.subarray(0, a.Wa), a.Ua = new Uint8Array(g), a.Ua.set(m));
            a.Ua.set(b.subarray(d, d + c), e);
            a.Wa = Math.max(a.Wa, e + c);
          } else a.Ua = b.slice(d, d + c), a.Wa = c;
          return c;
        }, bb(a, b, d) {
          d === 1 ? b += a.position : d === 2 && (a.node.mode & 61440) === 32768 && (b += a.node.Wa);
          if (b < 0) throw new O(28);
          return b;
        }, xb(a, b, d, c, e) {
          if ((a.node.mode & 61440) !== 32768) throw new O(43);
          a = a.node.Ua;
          if (e & 2 || a.buffer !== v.buffer) {
            e = true;
            c = Math.ceil(b / 65536) * 65536;
            var g = gb(65536, c);
            g && E.fill(0, g, g + c);
            c = g;
            if (!c) throw new O(48);
            if (a) {
              if (d > 0 || d + b < a.length) a = a.subarray ? a.subarray(d, d + b) : a.slice(d, d + b);
              v.set(a, c);
            }
          } else e = false, c = a.byteOffset;
          return { Bc: c, $b: e };
        }, yb(a, b, d, c) {
          M.Qa.write(a, b, 0, c, d, false);
          return 0;
        } } }, hb = [], ib = (a) => {
          var b = Wa(a, 0);
          return Va.decode(a.buffer ? a.subarray(0, b) : new Uint8Array(a.slice(0, b)));
        }, jb = [];
        function kb(a, b) {
          jb[a] = { input: [], output: [], pb: b };
          lb(a, pb);
        }
        var pb = { open(a) {
          var b = jb[a.node.sb];
          if (!b) throw new O(43);
          a.Za = b;
          a.seekable = false;
        }, close(a) {
          a.Za.pb.qb(a.Za);
        }, qb(a) {
          a.Za.pb.qb(a.Za);
        }, read(a, b, d, c) {
          if (!a.Za || !a.Za.pb.Wb) throw new O(60);
          for (var e = 0, g = 0; g < c; g++) {
            try {
              var m = a.Za.pb.Wb(a.Za);
            } catch (t) {
              throw new O(29);
            }
            if (m === void 0 && !e) throw new O(6);
            if (m === null || m === void 0) break;
            e++;
            b[d + g] = m;
            if (m === 10) break;
          }
          e && (a.node.gb = Date.now());
          return e;
        }, write(a, b, d, c) {
          if (!a.Za || !a.Za.pb.Mb) throw new O(60);
          try {
            for (var e = 0; e < c; e++) a.Za.pb.Mb(a.Za, b[d + e]);
          } catch (g) {
            throw new O(29);
          }
          c && (a.node.Ya = a.node.Xa = Date.now());
          return e;
        } }, vb = { Wb() {
          var _a3;
          a: {
            if (!hb.length) {
              var a = null;
              ((_a3 = globalThis.window) == null ? void 0 : _a3.prompt) && (a = window.prompt("Input: "), a !== null && (a += "\n"));
              if (!a) {
                a = null;
                break a;
              }
              hb = bb(a);
            }
            a = hb.shift();
          }
          return a;
        }, Mb(a, b) {
          b === null || b === 10 ? (xa(ib(a.output)), a.output = []) : b != 0 && a.output.push(b);
        }, qb(a) {
          var _a3;
          ((_a3 = a.output) == null ? void 0 : _a3.length) > 0 && (xa(ib(a.output)), a.output = []);
        }, Kc() {
          return { Gc: 25856, Ic: 5, Fc: 191, Hc: 35387, Ec: [3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] };
        }, Lc() {
          return 0;
        }, Mc() {
          return [
            24,
            80
          ];
        } }, wb = { Mb(a, b) {
          b === null || b === 10 ? (C(ib(a.output)), a.output = []) : b != 0 && a.output.push(b);
        }, qb(a) {
          var _a3;
          ((_a3 = a.output) == null ? void 0 : _a3.length) > 0 && (C(ib(a.output)), a.output = []);
        } }, xb = () => (a) => (crypto.getRandomValues(a), 0), yb = (a) => (yb = xb())(a), zb = null, Ab = {}, Bb = [], Cb = 1, Q = [], Db = false, Eb = true, Fb = {}, O = class {
          name = "ErrnoError";
          constructor(a) {
            this.Sa = a;
          }
        }, Gb = class {
          shared = {};
          node = null;
          get flags() {
            return this.shared.flags;
          }
          set flags(a) {
            this.shared.flags = a;
          }
          get position() {
            return this.shared.position;
          }
          set position(a) {
            this.shared.position = a;
          }
        }, Hb = class {
          Ra = {};
          Qa = {};
          nb = null;
          constructor(a, b, d, c) {
            a || (a = this);
            this.parent = a;
            this.hb = a.hb;
            this.id = Cb++;
            this.name = b;
            this.mode = d;
            this.sb = c;
            this.gb = this.Ya = this.Xa = Date.now();
          }
          get read() {
            return (this.mode & 365) === 365;
          }
          set read(a) {
            a ? this.mode |= 365 : this.mode &= -366;
          }
          get write() {
            return (this.mode & 146) === 146;
          }
          set write(a) {
            a ? this.mode |= 146 : this.mode &= -147;
          }
          Ac() {
          }
        };
        function B(a, b = {}) {
          if (!a) throw new O(44);
          b.Gb ?? (b.Gb = true);
          a.charAt(0) === "/" || (a = "//" + a);
          var d = 0;
          a: for (; d < 40; d++) {
            a = a.split("/").filter((t) => !!t);
            for (var c = zb, e = "/", g = 0; g < a.length; g++) {
              var m = g === a.length - 1;
              if (m && b.parent) break;
              if (a[g] !== ".") if (a[g] === "..") if (e = Za(e), c === c.parent) {
                a = e + "/" + a.slice(g + 1).join("/");
                d--;
                continue a;
              } else c = c.parent;
              else {
                e = Ya(e + "/" + a[g]);
                try {
                  c = fb(c, a[g]);
                } catch (t) {
                  if ((t == null ? void 0 : t.Sa) === 44 && m && b.zc) return { path: e };
                  throw t;
                }
                !c.nb || m && !b.Gb || (c = c.nb.root);
                if ((c.mode & 61440) === 40960 && (!m || b.mb)) {
                  if (!c.Ra.kb) throw new O(52);
                  c = c.Ra.kb(c);
                  c.charAt(0) === "/" || (c = Za(e) + "/" + c);
                  a = c + "/" + a.slice(g + 1).join("/");
                  continue a;
                }
              }
            }
            return { path: e, node: c };
          }
          throw new O(32);
        }
        function Ib(a) {
          for (var b; ; ) {
            if (a === a.parent) return a = a.hb.Yb, b ? a[a.length - 1] !== "/" ? `${a}/${b}` : a + b : a;
            b = b ? `${a.name}/${b}` : a.name;
            a = a.parent;
          }
        }
        function Jb(a, b) {
          for (var d = 0, c = 0; c < b.length; c++) d = (d << 5) - d + b.charCodeAt(c) | 0;
          return (a + d >>> 0) % Q.length;
        }
        function Kb(a) {
          var b = Jb(a.parent.id, a.name);
          if (Q[b] === a) Q[b] = a.ob;
          else for (b = Q[b]; b; ) {
            if (b.ob === a) {
              b.ob = a.ob;
              break;
            }
            b = b.ob;
          }
        }
        function fb(a, b) {
          var d = P(a.mode) ? (d = Lb(a, "x")) ? d : a.Ra.rb ? 0 : 2 : 54;
          if (d) throw new O(d);
          for (d = Q[Jb(a.id, b)]; d; d = d.ob) {
            var c = d.name;
            if (d.parent.id === a.id && c === b) return d;
          }
          return a.Ra.rb(a, b);
        }
        function eb(a, b, d, c) {
          a = new Hb(a, b, d, c);
          b = Jb(a.parent.id, a.name);
          a.ob = Q[b];
          return Q[b] = a;
        }
        function P(a) {
          return (a & 61440) === 16384;
        }
        function Lb(a, b) {
          return Eb ? 0 : b.includes("r") && !(a.mode & 292) || b.includes("w") && !(a.mode & 146) || b.includes("x") && !(a.mode & 73) ? 2 : 0;
        }
        function Mb(a, b) {
          if (!P(a.mode)) return 54;
          try {
            return fb(a, b), 20;
          } catch (d) {
          }
          return Lb(a, "wx");
        }
        function Nb(a, b, d) {
          try {
            var c = fb(a, b);
          } catch (e) {
            return e.Sa;
          }
          if (a = Lb(a, "wx")) return a;
          if (d) {
            if (!P(c.mode)) return 54;
            if (c === c.parent || Ib(c) === "/") return 10;
          } else if (P(c.mode)) return 31;
          return 0;
        }
        function Ob(a) {
          if (!a) throw new O(63);
          return a;
        }
        function R(a) {
          a = Bb[a];
          if (!a) throw new O(8);
          return a;
        }
        function Pb(a, b = -1) {
          a = Object.assign(new Gb(), a);
          if (b == -1) a: {
            for (b = 0; b <= 4096; b++) if (!Bb[b]) break a;
            throw new O(33);
          }
          a.ib = b;
          return Bb[b] = a;
        }
        function Qb(a, b = -1) {
          var _a3, _b3;
          a = Pb(a, b);
          (_b3 = (_a3 = a.Qa) == null ? void 0 : _a3.Jc) == null ? void 0 : _b3.call(_a3, a);
          return a;
        }
        function Rb(a, b, d) {
          var c = a == null ? void 0 : a.Qa.eb;
          a = c ? a : b;
          c ?? (c = b.Ra.eb);
          Ob(c);
          try {
            c(a, d);
          } catch (e) {
            if (e instanceof RangeError) throw new O(22);
            throw e;
          }
        }
        var db = { open(a) {
          var _a3, _b3;
          a.Qa = Ab[a.node.sb].Qa;
          (_b3 = (_a3 = a.Qa).open) == null ? void 0 : _b3.call(_a3, a);
        }, bb() {
          throw new O(70);
        } };
        function lb(a, b) {
          Ab[a] = { Qa: b };
        }
        function Sb(a, b) {
          var d = b === "/";
          if (d && zb) throw new O(10);
          if (!d && b) {
            var c = B(b, { Gb: false });
            b = c.path;
            c = c.node;
            if (c.nb) throw new O(10);
            if (!P(c.mode)) throw new O(54);
          }
          b = { type: a, Nc: {}, Yb: b, xc: [] };
          a = a.hb(b);
          a.hb = b;
          b.root = a;
          d ? zb = a : c && (c.nb = b, c.hb && c.hb.xc.push(b));
        }
        function Tb(a, b, d) {
          var c = B(a, { parent: true }).node;
          a = $a(a);
          if (!a) throw new O(28);
          if (a === "." || a === "..") throw new O(20);
          var e = Mb(c, a);
          if (e) throw new O(e);
          if (!c.Ra.wb) throw new O(63);
          return c.Ra.wb(c, a, b, d);
        }
        function Ub(a, b = 438) {
          return Tb(a, b & 4095 | 32768, 0);
        }
        function W(a, b = 511) {
          return Tb(a, b & 1023 | 16384, 0);
        }
        function Vb(a, b, d) {
          typeof d === "undefined" && (d = b, b = 438);
          Tb(a, b | 8192, d);
        }
        function Wb(a, b) {
          if (!ab(a)) throw new O(44);
          var d = B(b, { parent: true }).node;
          if (!d) throw new O(44);
          b = $a(b);
          var c = Mb(d, b);
          if (c) throw new O(c);
          if (!d.Ra.Cb) throw new O(63);
          d.Ra.Cb(d, b, a);
        }
        function Xb(a) {
          var b = B(a, { parent: true }).node;
          a = $a(a);
          var d = fb(b, a), c = Nb(b, a, true);
          if (c) throw new O(c);
          if (!b.Ra.Ab) throw new O(63);
          if (d.nb) throw new O(10);
          b.Ra.Ab(b, a);
          Kb(d);
        }
        function qa(a) {
          var b = B(a, { parent: true }).node;
          if (!b) throw new O(44);
          a = $a(a);
          var d = fb(b, a), c = Nb(b, a, false);
          if (c) throw new O(c);
          if (!b.Ra.Db) throw new O(63);
          if (d.nb) throw new O(10);
          b.Ra.Db(b, a);
          Kb(d);
        }
        function Yb(a, b = false) {
          a = B(a, { mb: !b }).node;
          return Ob(a.Ra.$a)(a);
        }
        function Zb(a, b, d) {
          Rb(a, b, { mode: d & 4095 | b.mode & -4096, Xa: Date.now(), Sb: false });
        }
        function $b(a, b) {
          a = typeof a === "string" ? B(a, { mb: true }).node : a;
          Zb(null, a, b);
        }
        function ac(a, b, d) {
          if (P(b.mode)) throw new O(31);
          if ((b.mode & 61440) !== 32768) throw new O(28);
          var c = Lb(b, "w");
          if (c) throw new O(c);
          Rb(a, b, { size: d, timestamp: Date.now() });
        }
        function bc(a, b, d, c = false) {
          a = B(a, { mb: !c });
          Rb(null, a.node, { gb: b, Ya: d, Sb: c });
        }
        function cc(a, b, d = 438) {
          if (a === "") throw new O(44);
          if (typeof b === "string") {
            var c = { r: 0, "r+": 2, w: 577, "w+": 578, a: 1089, "a+": 1090 }[b];
            if (typeof c === "undefined") throw Error(`Unknown file open mode: ${b}`);
            b = c;
          }
          d = b & 64 ? d & 4095 | 32768 : 0;
          if (typeof a === "object") c = a;
          else {
            var e = a.endsWith("/");
            a = B(a, { mb: !(b & 131072), zc: true });
            c = a.node;
            a = a.path;
          }
          var g = false;
          if (b & 64) if (c) {
            if (b & 128) throw new O(20);
          } else {
            if (e) throw new O(31);
            c = Tb(a, d | 511, 0);
            g = true;
          }
          if (!c) throw new O(44);
          (c.mode & 61440) === 8192 && (b &= -513);
          if (b & 65536 && !P(c.mode)) throw new O(54);
          if (!g && (c ? (c.mode & 61440) === 40960 ? e = 32 : (e = ["r", "w", "rw"][b & 3], b & 512 && (e += "w"), e = P(c.mode) && (e !== "r" || b & 576) ? 31 : Lb(c, e)) : e = 44, e)) throw new O(e);
          b & 512 && !g && (e = c, e = typeof e === "string" ? B(e, { mb: true }).node : e, ac(null, e, 0));
          b &= -131713;
          e = Pb({ node: c, path: Ib(c), flags: b, seekable: true, position: 0, Qa: c.Qa, Cc: [], error: false });
          e.Qa.open && e.Qa.open(e);
          g && $b(c, d & 511);
          !k.logReadFiles || b & 1 || a in Fb || (Fb[a] = 1, C(`read file: ${a}`));
          return e;
        }
        function dc(a) {
          var _a3;
          if (a.ib === null) throw new O(8);
          a.Jb && (a.Jb = null);
          (_a3 = a.node) == null ? void 0 : _a3.Ac();
          try {
            a.Qa.close && a.Qa.close(a);
          } catch (b) {
            throw b;
          } finally {
            Bb[a.ib] = null;
          }
          a.ib = null;
        }
        function ec2(a, b, d) {
          if (a.ib === null) throw new O(8);
          if (!a.seekable || !a.Qa.bb) throw new O(70);
          if (d != 0 && d != 1 && d != 2) throw new O(28);
          a.position = a.Qa.bb(a, b, d);
          a.Cc = [];
        }
        function fc(a, b, d, c, e) {
          if (c < 0 || e < 0) throw new O(28);
          if (a.ib === null) throw new O(8);
          if ((a.flags & 2097155) === 0) throw new O(8);
          if (P(a.node.mode)) throw new O(31);
          if (!a.Qa.write) throw new O(28);
          a.seekable && a.flags & 1024 && ec2(a, 0, 2);
          var g = typeof e !== "undefined";
          if (!g) e = a.position;
          else if (!a.seekable) throw new O(70);
          b = a.Qa.write(a, b, d, c, e, void 0);
          g || (a.position += b);
          return b;
        }
        function hc() {
          var a, b, d;
          Db = true;
          a ?? (a = k.stdin);
          b ?? (b = k.stdout);
          d ?? (d = k.stderr);
          a ? X("stdin", a) : Wb("/dev/tty", "/dev/stdin");
          b ? X("stdout", null, b) : Wb("/dev/tty", "/dev/stdout");
          d ? X("stderr", null, d) : Wb("/dev/tty1", "/dev/stderr");
          cc("/dev/stdin", 0);
          cc("/dev/stdout", 1);
          cc("/dev/stderr", 1);
        }
        function fa(a, b) {
          var d = "/", c = a;
          d && (d = typeof d === "string" ? d : Ib(d), c = a ? Ya(d + "/" + a) : d);
          a = cb(true, true);
          c = Ub(c, a);
          b && (typeof b === "string" && (b = bb(b)), b.subarray || (b = new Uint8Array(b)), $b(c, a | 146), d = cc(c, 577), fc(d, b, 0, b.length, 0), dc(d), $b(c, a));
        }
        function X(a, b, d) {
          a = Ya("/dev/" + a);
          var c = cb(!!b, !!d);
          X.Xb ?? (X.Xb = 64);
          var e = X.Xb++ << 8 | 0;
          lb(e, { open(g) {
            g.seekable = false;
          }, close() {
            var _a3;
            ((_a3 = d == null ? void 0 : d.buffer) == null ? void 0 : _a3.length) && d(10);
          }, read(g, m, t, z) {
            for (var q = 0, n = 0; n < z; n++) {
              try {
                var F = b();
              } catch (S) {
                throw new O(29);
              }
              if (F === void 0 && !q) throw new O(6);
              if (F === null || F === void 0) break;
              q++;
              m[t + n] = F;
            }
            q && (g.node.gb = Date.now());
            return q;
          }, write(g, m, t, z) {
            for (var q = 0; q < z; q++) try {
              d(m[t + q]);
            } catch (n) {
              throw new O(29);
            }
            z && (g.node.Ya = g.node.Xa = Date.now());
            return q;
          } });
          Vb(a, c, e);
        }
        var Y = {}, H, J, I;
        function Ic(a, b, d = false) {
          if (b.charAt(0) === "/") return b;
          a = a === -100 ? "/" : R(a).path;
          if (b.length == 0) {
            if (!d) throw new O(44);
            return a;
          }
          return a + "/" + b;
        }
        function Jc(a, b) {
          I[a >> 2] = b.kc;
          I[a + 4 >> 2] = b.mode;
          I[a + 8 >> 2] = b.yc;
          I[a + 12 >> 2] = b.uid;
          I[a + 16 >> 2] = b.uc;
          I[a + 20 >> 2] = b.sb;
          J[a + 24 >> 3] = BigInt(b.size);
          H[a + 32 >> 2] = 4096;
          H[a + 36 >> 2] = b.fc;
          var d = b.gb.getTime(), c = b.Ya.getTime(), e = b.Xa.getTime();
          J[a + 40 >> 3] = BigInt(Math.floor(d / 1e3));
          I[a + 48 >> 2] = d % 1e3 * 1e3 * 1e3;
          J[a + 56 >> 3] = BigInt(Math.floor(c / 1e3));
          I[a + 64 >> 2] = c % 1e3 * 1e3 * 1e3;
          J[a + 72 >> 3] = BigInt(Math.floor(e / 1e3));
          I[a + 80 >> 2] = e % 1e3 * 1e3 * 1e3;
          J[a + 88 >> 3] = BigInt(b.vc);
          return 0;
        }
        var Kc = void 0, Ea, Lc = () => {
          var a = H[+Kc >> 2];
          Kc += 4;
          return a;
        }, Mc = 0, Nc = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], Oc = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], Pc = (a) => {
          if (!(a instanceof Ta || a == "unwind")) throw a;
        }, Qc = (a) => {
          var _a3;
          Ba = a;
          Ua || Mc > 0 || ((_a3 = k.onExit) == null ? void 0 : _a3.call(k, a), Aa = true);
          throw new Ta(a);
        }, Rc = {}, Sc = {}, Uc = () => {
          var _a3;
          if (!Tc) {
            var a = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: (((_a3 = globalThis.navigator) == null ? void 0 : _a3.language) ?? "C").replace("-", "_") + ".UTF-8", _: sa }, b;
            for (b in Sc) Sc[b] === void 0 ? delete a[b] : a[b] = Sc[b];
            var d = [];
            for (b in a) d.push(`${b}=${a[b]}`);
            Tc = d;
          }
          return Tc;
        }, Tc, Fa, Ga;
        function oa(a) {
          var b = "i32";
          b.endsWith("*") && (b = "*");
          switch (b) {
            case "i1":
              v[a] = 0;
              break;
            case "i8":
              v[a] = 0;
              break;
            case "i16":
              Ea[a >> 1] = 0;
              break;
            case "i32":
              H[a >> 2] = 0;
              break;
            case "i64":
              J[a >> 3] = BigInt(0);
              break;
            case "float":
              Fa[a >> 2] = 0;
              break;
            case "double":
              Ga[a >> 3] = 0;
              break;
            case "*":
              I[a >> 2] = 0;
              break;
            default:
              La(`invalid type for setValue: ${b}`);
          }
        }
        function y(a, b = "i8") {
          b.endsWith("*") && (b = "*");
          switch (b) {
            case "i1":
              return v[a];
            case "i8":
              return v[a];
            case "i16":
              return Ea[a >> 1];
            case "i32":
              return H[a >> 2];
            case "i64":
              return J[a >> 3];
            case "float":
              return Fa[a >> 2];
            case "double":
              return Ga[a >> 3];
            case "*":
              return I[a >> 2];
            default:
              La(`invalid type for getValue: ${b}`);
          }
        }
        var Vc = (a, b, d, c) => {
          var e = { string: (q) => {
            var n = 0;
            if (q !== null && q !== void 0 && q !== 0) {
              n = l(q) + 1;
              var F = ka(n);
              L(q, E, F, n);
              n = F;
            }
            return n;
          }, array: (q) => {
            var n = ka(q.length);
            v.set(q, n);
            return n;
          } };
          a = k["_" + a];
          var g = [], m = 0;
          if (c) for (var t = 0; t < c.length; t++) {
            var z = e[d[t]];
            z ? (m || (m = la()), g[t] = z(c[t])) : g[t] = c[t];
          }
          d = a(...g);
          return d = (function(q) {
            m && pa(m);
            return b === "string" ? A(q) : b === "boolean" ? !!q : q;
          })(d);
        }, ea = (a) => {
          var b = l(a) + 1, d = ca(b);
          d && L(a, E, d, b);
          return d;
        }, Wc = [], Xc, ja = (a) => {
          Xc.delete(Z.get(a));
          Z.set(a, null);
          Wc.push(a);
        }, Yc = (a) => {
          var b = a.length;
          return [b % 128 | 128, b >> 7, ...a];
        }, Zc = { i: 127, p: 127, j: 126, f: 125, d: 124, e: 111 }, $c = (a) => Yc(Array.from(a, (b) => Zc[b])), ra = (a, b) => {
          if (!Xc) {
            Xc = /* @__PURE__ */ new WeakMap();
            var d = Z.length;
            if (Xc) for (var c = 0; c < 0 + d; c++) {
              var e = Z.get(c);
              e && Xc.set(e, c);
            }
          }
          if (d = Xc.get(a) || 0) return d;
          d = Wc.length ? Wc.pop() : Z.grow(1);
          try {
            Z.set(d, a);
          } catch (g) {
            if (!(g instanceof TypeError)) throw g;
            b = Uint8Array.of(0, 97, 115, 109, 1, 0, 0, 0, 1, ...Yc([1, 96, ...$c(b.slice(1)), ...$c(b[0] === "v" ? "" : b[0])]), 2, 7, 1, 1, 101, 1, 102, 0, 0, 7, 5, 1, 1, 102, 0, 0);
            b = new WebAssembly.Module(b);
            b = new WebAssembly.Instance(
              b,
              { e: { f: a } }
            ).exports.f;
            Z.set(d, b);
          }
          Xc.set(a, d);
          return d;
        };
        Q.length = 4096;
        Sb(M, "/");
        W("/tmp");
        W("/home");
        W("/home/web_user");
        (function() {
          W("/dev");
          lb(259, { read: () => 0, write: (c, e, g, m) => m, bb: () => 0 });
          Vb("/dev/null", 259);
          kb(1280, vb);
          kb(1536, wb);
          Vb("/dev/tty", 1280);
          Vb("/dev/tty1", 1536);
          var a = new Uint8Array(1024), b = 0, d = () => {
            b || (yb(a), b = a.byteLength);
            return a[--b];
          };
          X("random", d);
          X("urandom", d);
          W("/dev/shm");
          W("/dev/shm/tmp");
        })();
        (function() {
          W("/proc");
          var a = W("/proc/self");
          W("/proc/self/fd");
          Sb({ hb() {
            var b = eb(a, "fd", 16895, 73);
            b.Qa = { bb: M.Qa.bb };
            b.Ra = { rb(d, c) {
              d = +c;
              var e = R(d);
              d = { parent: null, hb: { Yb: "fake" }, Ra: { kb: () => e.path }, id: d + 1 };
              return d.parent = d;
            }, Nb() {
              return Array.from(Bb.entries()).filter(([, d]) => d).map(([d]) => d.toString());
            } };
            return b;
          } }, "/proc/self/fd");
        })();
        k.noExitRuntime && (Ua = k.noExitRuntime);
        k.print && (xa = k.print);
        k.printErr && (C = k.printErr);
        k.wasmBinary && (ya = k.wasmBinary);
        k.thisProgram && (sa = k.thisProgram);
        var ad = k.preInit;
        if (ad) for (typeof ad === "function" && (k.preInit = ad = [ad]); ad.length > 0; ) ad.shift()();
        k.stackSave = () => la();
        k.stackRestore = (a) => pa(a);
        k.stackAlloc = (a) => ka(a);
        k.cwrap = (a, b, d, c) => {
          var e = !d || d.every((g) => g === "number" || g === "boolean");
          return b !== "string" && e && !c ? k["_" + a] : (...g) => Vc(a, b, d, g);
        };
        k.addFunction = ra;
        k.removeFunction = ja;
        k.UTF8ToString = A;
        k.lengthBytesUTF8 = l;
        k.stringToNewUTF8 = ea;
        k.writeArrayToMemory = (a, b) => {
          v.set(a, b);
        };
        var ca, da, gb, bd, pa, ka, la, Da, Z, cd = {
          a: (a, b, d, c) => La(`Assertion failed: ${A(a)}, at: ` + [b ? A(b) : "unknown filename", d, c ? A(c) : "unknown function"]),
          i: function(a, b) {
            try {
              return a = A(a), $b(a, b), 0;
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return -d.Sa;
            }
          },
          D: function(a, b, d) {
            try {
              b = A(b);
              b = Ic(a, b);
              if (d & -8) return -28;
              var c = B(b, { mb: true }).node;
              if (!c) return -44;
              a = "";
              d & 4 && (a += "r");
              d & 2 && (a += "w");
              d & 1 && (a += "x");
              return a && Lb(c, a) ? -2 : 0;
            } catch (e) {
              if (typeof Y === "undefined" || e.name !== "ErrnoError") throw e;
              return -e.Sa;
            }
          },
          j: function(a, b) {
            try {
              var d = R(a);
              Zb(d, d.node, b);
              return 0;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return -c.Sa;
            }
          },
          h: function(a) {
            try {
              var b = R(a);
              Rb(b, b.node, { timestamp: Date.now(), Sb: false });
              return 0;
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return -d.Sa;
            }
          },
          b: function(a, b, d) {
            Kc = d;
            try {
              var c = R(a);
              switch (b) {
                case 0:
                  var e = Lc();
                  if (e < 0) break;
                  for (; Bb[e]; ) e++;
                  return Qb(c, e).ib;
                case 1:
                case 2:
                  return 0;
                case 3:
                  return c.flags;
                case 4:
                  return e = Lc(), c.flags = c.flags & -289793 | e & 289792, 0;
                case 12:
                  return e = Lc(), Ea[e + 0 >> 1] = 2, 0;
                case 13:
                case 14:
                  return 0;
              }
              return -28;
            } catch (g) {
              if (typeof Y === "undefined" || g.name !== "ErrnoError") throw g;
              return -g.Sa;
            }
          },
          g: function(a, b) {
            try {
              var d = R(a), c = d.node, e = d.Qa.$a;
              a = e ? d : c;
              e ?? (e = c.Ra.$a);
              Ob(e);
              var g = e(a);
              return Jc(b, g);
            } catch (m) {
              if (typeof Y === "undefined" || m.name !== "ErrnoError") throw m;
              return -m.Sa;
            }
          },
          J: function(a, b) {
            b = b < -9007199254740992 || b > 9007199254740992 ? NaN : Number(b);
            try {
              if (isNaN(b)) return -22;
              var d = R(a);
              if (b < 0 || (d.flags & 2097155) === 0) throw new O(28);
              ac(
                d,
                d.node,
                b
              );
              return 0;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return -c.Sa;
            }
          },
          I: function(a, b) {
            try {
              if (!b) return -28;
              var d = l("/") + 1;
              if (b < d) return -68;
              L("/", E, a, b);
              return d;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return -c.Sa;
            }
          },
          F: () => 0,
          M: function(a, b) {
            try {
              return a = A(a), Jc(b, Yb(a, true));
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return -d.Sa;
            }
          },
          C: function(a, b, d) {
            try {
              return b = A(b), b = Ic(a, b), W(b, d & -19), 0;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return -c.Sa;
            }
          },
          L: function(a, b, d, c) {
            try {
              b = A(b);
              var e = c & 256;
              b = Ic(a, b, c & 4096);
              return Jc(d, e ? Yb(b, true) : Yb(b));
            } catch (g) {
              if (typeof Y === "undefined" || g.name !== "ErrnoError") throw g;
              return -g.Sa;
            }
          },
          x: function(a, b, d, c) {
            Kc = c;
            try {
              b = A(b);
              b = Ic(a, b);
              var e = c ? Lc() : 0;
              d & 64 && (e &= -19);
              return cc(b, d, e).ib;
            } catch (g) {
              if (typeof Y === "undefined" || g.name !== "ErrnoError") throw g;
              return -g.Sa;
            }
          },
          s: function(a, b, d, c) {
            try {
              b = A(b);
              b = Ic(a, b);
              if (c <= 0) return -28;
              var e = B(b).node;
              if (!e) throw new O(44);
              if (!e.Ra.kb) throw new O(28);
              var g = e.Ra.kb(e);
              var m = Math.min(c, l(g)), t = v[d + m];
              L(g, E, d, c + 1);
              v[d + m] = t;
              return m;
            } catch (z) {
              if (typeof Y === "undefined" || z.name !== "ErrnoError") throw z;
              return -z.Sa;
            }
          },
          r: function(a) {
            try {
              return a = A(a), Xb(a), 0;
            } catch (b) {
              if (typeof Y === "undefined" || b.name !== "ErrnoError") throw b;
              return -b.Sa;
            }
          },
          N: function(a, b) {
            try {
              return a = A(a), Jc(b, Yb(a));
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return -d.Sa;
            }
          },
          o: function(a, b, d) {
            try {
              b = A(b);
              b = Ic(a, b);
              if (d) if (d === 512) Xb(b);
              else return -28;
              else qa(b);
              return 0;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return -c.Sa;
            }
          },
          n: function(a, b, d, c) {
            try {
              c &= 256;
              b = A(b);
              b = Ic(a, b, true);
              var e = Date.now();
              if (d) {
                let t2 = function(z) {
                  var q = H[z + 8 >> 2];
                  return q == 1073741823 ? e : q == 1073741822 ? null : (I[z >> 2] + H[z + 4 >> 2] * 4294967296) * 1e3 + Math.floor(q / 1e6);
                };
                var t = t2;
                var g = t2(d);
                var m = t2(d + 16);
              } else m = g = e;
              (m ?? g) !== null && bc(b, g, m, c);
              return 0;
            } catch (t2) {
              if (typeof Y === "undefined" || t2.name !== "ErrnoError") throw t2;
              return -t2.Sa;
            }
          },
          w: () => La(""),
          v: () => {
            Ua = false;
            Mc = 0;
          },
          A: function(a, b) {
            a = a < -9007199254740992 || a > 9007199254740992 ? NaN : Number(a);
            a = new Date(a * 1e3);
            if (isNaN(a.getTime())) return 1;
            H[b >> 2] = a.getSeconds();
            H[b + 4 >> 2] = a.getMinutes();
            H[b + 8 >> 2] = a.getHours();
            H[b + 12 >> 2] = a.getDate();
            H[b + 16 >> 2] = a.getMonth();
            H[b + 20 >> 2] = a.getFullYear() - 1900;
            H[b + 24 >> 2] = a.getDay();
            var d = a.getFullYear();
            H[b + 28 >> 2] = (d % 4 !== 0 || d % 100 === 0 && d % 400 !== 0 ? Oc : Nc)[a.getMonth()] + a.getDate() - 1 | 0;
            H[b + 36 >> 2] = -(a.getTimezoneOffset() * 60);
            d = new Date(a.getFullYear(), 6, 1).getTimezoneOffset();
            var c = new Date(a.getFullYear(), 0, 1).getTimezoneOffset();
            H[b + 32 >> 2] = (d != c && a.getTimezoneOffset() == Math.min(c, d)) | 0;
            return 0;
          },
          y: function(a, b, d, c, e, g, m) {
            e = e < -9007199254740992 || e > 9007199254740992 ? NaN : Number(e);
            try {
              var t = R(c);
              if (b & 2 && !(d & 2) && (t.flags & 2097155) !== 2) throw new O(2);
              if ((t.flags & 2097155) === 1) throw new O(2);
              if (!t.Qa.xb) throw new O(43);
              if (!a) throw new O(28);
              var z = t.Qa.xb(t, a, e, b, d);
              var q = z.Bc;
              H[g >> 2] = z.$b;
              I[m >> 2] = q;
              return 0;
            } catch (n) {
              if (typeof Y === "undefined" || n.name !== "ErrnoError") throw n;
              return -n.Sa;
            }
          },
          z: function(a, b, d, c, e, g) {
            g = g < -9007199254740992 || g > 9007199254740992 ? NaN : Number(g);
            try {
              var m = R(e);
              if (d & 2) {
                if ((m.node.mode & 61440) !== 32768) throw new O(43);
                c & 2 || m.Qa.yb && m.Qa.yb(m, E.subarray(a, a + b), g, b, c);
              }
            } catch (t) {
              if (typeof Y === "undefined" || t.name !== "ErrnoError") throw t;
              return -t.Sa;
            }
          },
          k: (a, b) => {
            Rc[a] && (clearTimeout(Rc[a].id), delete Rc[a]);
            if (!b) return 0;
            var d = setTimeout(() => {
              delete Rc[a];
              var c = [a, performance.now()], e = bd;
              if (!Aa) try {
                e(...c);
              } catch (g) {
                Pc(g);
              } finally {
                if (!(Ua || Mc > 0)) try {
                  Ba = c = Ba, Qc(c);
                } catch (g) {
                  Pc(g);
                }
              }
            }, b);
            Rc[a] = { id: d, Oc: b };
            return 0;
          },
          B: (a, b, d, c) => {
            var e = (/* @__PURE__ */ new Date()).getFullYear(), g = new Date(e, 0, 1).getTimezoneOffset();
            e = new Date(e, 6, 1).getTimezoneOffset();
            I[a >> 2] = Math.max(g, e) * 60;
            H[b >> 2] = Number(g != e);
            b = (m) => {
              var t = Math.abs(m);
              return `UTC${m >= 0 ? "-" : "+"}${String(Math.floor(t / 60)).padStart(2, "0")}${String(t % 60).padStart(2, "0")}`;
            };
            a = b(g);
            b = b(e);
            e < g ? (L(a, E, d, 17), L(b, E, c, 17)) : (L(a, E, c, 17), L(b, E, d, 17));
          },
          d: () => Date.now(),
          p: () => 2147483648,
          c: () => performance.now(),
          l: (a) => {
            var b = E.length;
            a >>>= 0;
            if (a > 2147483648) return false;
            for (var d = 1; d <= 4; d *= 2) {
              var c = b * (1 + 0.2 / d);
              c = Math.min(c, a + 100663296);
              a: {
                c = (Math.min(2147483648, Math.ceil(Math.max(a, c) / 65536) * 65536) - Da.buffer.byteLength + 65535) / 65536 | 0;
                try {
                  Da.grow(c);
                  Ca();
                  var e = 1;
                  break a;
                } catch (g) {
                }
                e = void 0;
              }
              if (e) return true;
            }
            return false;
          },
          G: (a, b) => {
            var d = 0, c = 0, e;
            for (e of Uc()) {
              var g = b + d;
              I[a + c >> 2] = g;
              d += L(e, E, g, Infinity) + 1;
              c += 4;
            }
            return 0;
          },
          H: (a, b) => {
            var d = Uc();
            I[a >> 2] = d.length;
            a = 0;
            for (var c of d) a += l(c) + 1;
            I[b >> 2] = a;
            return 0;
          },
          e: function(a) {
            try {
              var b = R(a);
              dc(b);
              return 0;
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return d.Sa;
            }
          },
          m: function(a, b) {
            try {
              var d = R(a);
              v[b] = d.Za ? 2 : P(d.mode) ? 3 : (d.mode & 61440) === 40960 ? 7 : 4;
              Ea[b + 2 >> 1] = 0;
              J[b + 8 >> 3] = BigInt(0);
              J[b + 16 >> 3] = BigInt(0);
              return 0;
            } catch (c) {
              if (typeof Y === "undefined" || c.name !== "ErrnoError") throw c;
              return c.Sa;
            }
          },
          t: function(a, b, d, c) {
            try {
              a: {
                var e = R(a);
                a = b;
                for (var g, m = b = 0; m < d; m++) {
                  var t = I[a >> 2], z = I[a + 4 >> 2];
                  a += 8;
                  try {
                    var q = e, n = t, F = z, S = g, Oa = v;
                    if (F < 0 || S < 0) throw new O(28);
                    if (q.ib === null) throw new O(8);
                    if ((q.flags & 2097155) === 1) throw new O(8);
                    if (P(q.node.mode)) throw new O(31);
                    if (!q.Qa.read) throw new O(28);
                    var ma = typeof S !== "undefined";
                    if (!ma) S = q.position;
                    else if (!q.seekable) throw new O(70);
                    var na = q.Qa.read(q, Oa, n, F, S);
                    ma || (q.position += na);
                    var ha = na;
                  } catch (N) {
                    if (b > 0 && N instanceof O && (N.Sa == 6 || N.Sa == 6)) break;
                    throw N;
                  }
                  if (ha < 0) {
                    var za = -1;
                    break a;
                  }
                  b += ha;
                  if (ha < z) break;
                  typeof g !== "undefined" && (g += ha);
                }
                za = b;
              }
              I[c >> 2] = za;
              return 0;
            } catch (N) {
              if (typeof Y === "undefined" || N.name !== "ErrnoError") throw N;
              return N.Sa;
            }
          },
          E: function(a, b, d, c) {
            b = b < -9007199254740992 || b > 9007199254740992 ? NaN : Number(b);
            try {
              if (isNaN(b)) return 22;
              var e = R(a);
              ec2(e, b, d);
              J[c >> 3] = BigInt(e.position);
              e.Jb && !b && d === 0 && (e.Jb = null);
              return 0;
            } catch (g) {
              if (typeof Y === "undefined" || g.name !== "ErrnoError") throw g;
              return g.Sa;
            }
          },
          K: function(a) {
            var _a3, _b3;
            try {
              var b = R(a);
              return (_b3 = (_a3 = b.Qa) == null ? void 0 : _a3.qb) == null ? void 0 : _b3.call(_a3, b);
            } catch (d) {
              if (typeof Y === "undefined" || d.name !== "ErrnoError") throw d;
              return d.Sa;
            }
          },
          q: function(a, b, d, c) {
            try {
              var e = R(a);
              a = b;
              if (d == 1) var g = fc(e, v, I[a >> 2], I[a + 4 >> 2]);
              else {
                for (var m = b = 0, t = a; m < d; m++, t += 8) b += I[t + 4 >> 2];
                var z = new Uint8Array(b);
                for (m = t = 0; m < d; m++, a += 8) {
                  var q = I[a >> 2], n = I[a + 4 >> 2];
                  z.set(
                    E.subarray(q, q + n),
                    t
                  );
                  t += n;
                }
                g = fc(e, z, 0, b);
              }
              I[c >> 2] = g;
              return 0;
            } catch (F) {
              if (typeof Y === "undefined" || F.name !== "ErrnoError") throw F;
              return F.Sa;
            }
          },
          u: Qc,
          f: function(a) {
            console.warn("sql.js: legacy function " + A(a) + "() is deprecated and will be disabled by default in the next major version. Initialize with useOldExtensionFunctions: false to use native SQLite functions. See https://github.com/sql-js/sql.js/pull/647");
          }
        };
        async function dd() {
          var _a3;
          Ha();
          var a = k.setStatus;
          a && (a("Running..."), await new Promise((b) => setTimeout(b, 1)), setTimeout(a, 1, ""));
          Aa || (k.noFSInit || Db || hc(), ed.P(), Eb = false, (_a3 = k.onRuntimeInitialized) == null ? void 0 : _a3.call(k), Ja());
        }
        var ed;
        (async function() {
          function a(c) {
            c = ed = c.exports;
            k._sqlite3_free = c.R;
            k._sqlite3_value_text = c.S;
            k._sqlite3_prepare_v2 = c.T;
            k._sqlite3_step = c.U;
            k._sqlite3_reset = c.V;
            k._sqlite3_exec = c.W;
            k._sqlite3_finalize = c.X;
            k._sqlite3_column_name = c.Y;
            k._sqlite3_column_text = c.Z;
            k._sqlite3_column_type = c._;
            k._sqlite3_errmsg = c.$;
            k._sqlite3_backup_init = c.aa;
            k._sqlite3_backup_step = c.ba;
            k._sqlite3_backup_finish = c.ca;
            k._sqlite3_clear_bindings = c.da;
            k._sqlite3_value_blob = c.ea;
            k._sqlite3_value_bytes = c.fa;
            k._sqlite3_value_double = c.ga;
            k._sqlite3_value_int = c.ha;
            k._sqlite3_value_type = c.ia;
            k._sqlite3_result_blob = c.ja;
            k._sqlite3_result_double = c.ka;
            k._sqlite3_result_error = c.la;
            k._sqlite3_result_int = c.ma;
            k._sqlite3_result_int64 = c.na;
            k._sqlite3_result_null = c.oa;
            k._sqlite3_result_text = c.pa;
            k._sqlite3_aggregate_context = c.qa;
            k._sqlite3_column_count = c.ra;
            k._sqlite3_data_count = c.sa;
            k._sqlite3_column_blob = c.ta;
            k._sqlite3_column_bytes = c.ua;
            k._sqlite3_column_double = c.va;
            k._sqlite3_bind_blob = c.wa;
            k._sqlite3_bind_double = c.xa;
            k._sqlite3_bind_int = c.ya;
            k._sqlite3_bind_text = c.za;
            k._sqlite3_bind_parameter_index = c.Aa;
            k._sqlite3_sql = c.Ba;
            k._sqlite3_normalized_sql = c.Ca;
            k._sqlite3_changes = c.Da;
            k._sqlite3_close_v2 = c.Ea;
            k._sqlite3_create_function_v2 = c.Fa;
            k._sqlite3_update_hook = c.Ga;
            k._sqlite3_open = c.Ha;
            ca = k._malloc = c.Ia;
            da = k._free = c.Ja;
            k._RegisterExtensionFunctions = c.Ka;
            gb = c.La;
            bd = c.Ma;
            pa = c.Na;
            ka = c.Oa;
            la = c.Pa;
            Da = c.O;
            Z = c.Q;
            Ca();
            return ed;
          }
          var b = { a: cd }, d = k.instantiateWasm;
          if (d) return new Promise((c) => {
            d(b, (e) => c(a(e)));
          });
          Ma ?? (Ma = k.locateFile ? k.locateFile(
            "sql-wasm-browser.wasm",
            ua
          ) : ua + "sql-wasm-browser.wasm");
          return (function(c) {
            return a(c.instance);
          })(await Sa(b));
        })().then(() => dd());
        return Module;
      });
      return initSqlJsPromise;
    };
    if (typeof exports === "object" && typeof module === "object") {
      module.exports = initSqlJs2;
      module.exports.default = initSqlJs2;
    } else if (typeof define === "function" && define["amd"]) {
      define([], function() {
        return initSqlJs2;
      });
    } else if (typeof exports === "object") {
      exports["Module"] = initSqlJs2;
    }
  }
});

// offline/client.mjs
init_polyfills();

// offline/database.mjs
init_polyfills();
var import_sql = __toESM(require_sql_wasm_browser(), 1);

// lib/label-normalization.mjs
init_polyfills();

// public/hs-code.js
init_polyfills();
function hsCode(value) {
  const raw = String(value ?? "").trim().toUpperCase(), prefix = raw.split(/[-‐‑–—]/, 1)[0].trim();
  if (/^[A-Z0-9]{10}[A-Z]{2,3}$/.test(prefix)) return prefix;
  const match = /^([A-Z0-9]{10}[A-Z]{3}|[A-Z0-9]{10}[A-Z]{2})(?![A-Z])/.exec(raw);
  return match ? match[1] : raw;
}

// lib/label-normalization.mjs
function normalizeLabelHistory(db) {
  if (!db.prepare("SELECT 1 FROM sqlite_master WHERE name='scans'").get() || !db.prepare("PRAGMA table_info(scans)").all().some((c) => c.name === "raw_barcode")) return;
  const rows = db.prepare("SELECT id,barcode FROM scans WHERE mode='Label' AND raw_barcode IS NULL").all();
  if (!rows.length) return;
  db.exec("SAVEPOINT label_codes");
  try {
    const update = db.prepare("UPDATE scans SET barcode=?,raw_barcode=? WHERE id=?");
    for (const row of rows) update.run(hsCode(row.barcode), row.barcode, row.id);
    db.exec("RELEASE SAVEPOINT label_codes");
  } catch (e) {
    db.exec("ROLLBACK TO SAVEPOINT label_codes; RELEASE SAVEPOINT label_codes");
    throw e;
  }
}

// offline/database.mjs
var engine;
async function openDeviceDatabase(bytes) {
  engine ?? (engine = (0, import_sql.default)({ locateFile: (name) => "/offline/" + name }));
  const SQL = await engine, raw = new SQL.Database(new Uint8Array(bytes));
  raw.run("PRAGMA foreign_keys=ON");
  const convert = (row) => Object.fromEntries(Object.entries(row).map(([key, value]) => [key, value instanceof Uint8Array ? import_buffer.Buffer.from(value) : value]));
  const database = { raw, exec: (sql) => raw.run(sql), close: () => raw.close(), prepare(sql) {
    return {
      all(...args) {
        const stmt = raw.prepare(sql);
        try {
          stmt.bind(args.map((v) => v === void 0 ? null : v));
          const rows = [];
          while (stmt.step()) rows.push(convert(stmt.getAsObject()));
          return rows;
        } finally {
          stmt.free();
        }
      },
      get(...args) {
        const stmt = raw.prepare(sql);
        try {
          stmt.bind(args.map((v) => v === void 0 ? null : v));
          return stmt.step() ? convert(stmt.getAsObject()) : void 0;
        } finally {
          stmt.free();
        }
      },
      run(...args) {
        var _a2;
        raw.run(sql, args.map((v) => v === void 0 ? null : v));
        return { changes: raw.getRowsModified(), lastInsertRowid: ((_a2 = raw.exec("SELECT last_insert_rowid() id")[0]) == null ? void 0 : _a2.values[0][0]) ?? 0 };
      }
    };
  } };
  normalizeLabelHistory(database);
  return database;
}

// offline/storage.mjs
init_polyfills();
var opening;
function storage() {
  return opening ?? (opening = new Promise((resolve, reject) => {
    const request = indexedDB.open("work-area-offline-v1", 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const name of ["meta", "base"]) if (!db.objectStoreNames.contains(name)) db.createObjectStore(name);
      const ops = db.objectStoreNames.contains("ops") ? request.transaction.objectStore("ops") : db.createObjectStore("ops", { keyPath: "seq", autoIncrement: true });
      if (!ops.indexNames.contains("id")) ops.createIndex("id", "id", { unique: true });
      if (!db.objectStoreNames.contains("canceled")) db.createObjectStore("canceled", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  }));
}
async function read(store, key) {
  const db = await storage();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readonly"), request = key === void 0 ? tx.objectStore(store).getAll() : tx.objectStore(store).get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function change(stores, callback) {
  const db = await storage();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(stores, "readwrite");
    let result;
    try {
      result = callback(tx);
    } catch (error2) {
      tx.abort();
      reject(error2);
      return;
    }
    tx.oncomplete = () => resolve(result == null ? void 0 : result.result);
    tx.onerror = () => reject(tx.error || Error("Kh\xF4ng l\u01B0u \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u \u0111i\u1EC7n tho\u1EA1i."));
    tx.onabort = () => reject(tx.error || Error("H\u1EBFt dung l\u01B0\u1EE3ng ho\u1EB7c l\u01B0u d\u1EEF li\u1EC7u b\u1ECB h\u1EE7y."));
  });
}
async function addOperation(op) {
  const db = await storage();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("ops", "readwrite"), request = tx.objectStore("ops").add(op);
    let seq;
    request.onsuccess = () => seq = request.result;
    tx.oncomplete = () => resolve(seq);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || Error("Kh\xF4ng \u0111\u1EE7 b\u1ED9 nh\u1EDB \u0111\u1EC3 l\u01B0u l\u01B0\u1EE3t n\xE0y."));
  });
}

// lib/offline-business.mjs
init_polyfills();

// lib/heatsink-data.mjs
init_polyfills();

// offline/transaction.mjs
init_polyfills();
var sequence = 0;
function transaction(db, fn) {
  const name = "device_tx_" + ++sequence;
  db.exec("SAVEPOINT " + name);
  try {
    const result = fn();
    db.exec("RELEASE SAVEPOINT " + name);
    return result;
  } catch (error2) {
    db.exec("ROLLBACK TO SAVEPOINT " + name + "; RELEASE SAVEPOINT " + name);
    throw error2;
  }
}

// lib/heatsink-data.mjs
function initHeatsink(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS heatsink_batches(id INTEGER PRIMARY KEY,name TEXT NOT NULL,sheets TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS heatsink_groups(id INTEGER PRIMARY KEY,batch_id INTEGER NOT NULL REFERENCES heatsink_batches(id),sub_code TEXT NOT NULL,heatsink_code TEXT NOT NULL,model TEXT NOT NULL,sheet TEXT NOT NULL,source_row INTEGER NOT NULL,parts TEXT NOT NULL,images TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS heatsink_batch ON heatsink_groups(batch_id);
CREATE TABLE IF NOT EXISTS heatsink_images(id TEXT PRIMARY KEY,mime TEXT NOT NULL,bytes BLOB NOT NULL);`);
}
function listHeatsink(db, { q = "", model = "", code: code2 = "", offset = 0 } = {}) {
  const batch = db.prepare("SELECT * FROM heatsink_batches ORDER BY id DESC LIMIT 1").get();
  if (!batch) return { batch: null, groups: [], models: [], total: 0, next: null };
  batch.sheets = JSON.parse(batch.sheets);
  q = String(q).trim().toUpperCase().slice(0, 200);
  model = String(model).slice(0, 200);
  code2 = String(code2).trim().slice(0, 200);
  offset = Math.max(0, Math.min(1e5, Math.floor(Number(offset) || 0)));
  const where = "batch_id=? AND (?='' OR sub_code=?) AND (?='' OR model=?) AND (?='' OR instr(upper(sub_code),?)>0 OR instr(upper(heatsink_code),?)>0 OR instr(upper(model),?)>0 OR instr(upper(parts),?)>0)", args = [batch.id, code2, code2, model, model, q, q, q, q, q];
  const total = db.prepare("SELECT count(*) n FROM heatsink_groups WHERE " + where).get(...args).n;
  const groups = db.prepare("SELECT * FROM heatsink_groups WHERE " + where + " ORDER BY id LIMIT 30 OFFSET ?").all(...args, offset).map((g) => ({ ...g, parts: JSON.parse(g.parts), images: JSON.parse(g.images) }));
  const code_count = db.prepare("SELECT count(DISTINCT CASE WHEN sub_code='' THEN '#'||id ELSE sub_code END) n FROM heatsink_groups WHERE " + where).get(...args).n;
  return { batch, groups, total, code_count, next: offset + groups.length < total ? offset + groups.length : null, models: db.prepare("SELECT DISTINCT model FROM heatsink_groups WHERE batch_id=? ORDER BY model").all(batch.id).map((r) => r.model) };
}

// lib/ckd.mjs
init_polyfills();

// lib/xlsx-read.mjs
init_polyfills();

// offline/zlib.mjs
init_polyfills();

// ../.tools/offline-build/node_modules/fflate/esm/browser.js
init_polyfills();
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start += 1 << eb[i2 - 1];
  }
  var r = new i32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flm = /* @__PURE__ */ hMap(flt, 9, 0);
var fdm = /* @__PURE__ */ hMap(fdt, 5, 0);
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var wbits = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >> 8;
  d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
  var t = [];
  for (var i2 = 0; i2 < d.length; ++i2) {
    if (d[i2])
      t.push({ s: i2, f: d[i2] });
  }
  var s = t.length;
  var t2 = t.slice();
  if (!s)
    return { t: et, l: 0 };
  if (s == 1) {
    var v = new u8(t[0].s + 1);
    v[t[0].s] = 1;
    return { t: v, l: 1 };
  }
  t.sort(function(a, b) {
    return a.f - b.f;
  });
  t.push({ s: -1, f: 25001 });
  var l = t[0], r = t[1], i0 = 0, i1 = 1, i22 = 2;
  t[0] = { s: -1, f: l.f + r.f, l, r };
  while (i1 != s - 1) {
    l = t[t[i0].f < t[i22].f ? i0++ : i22++];
    r = t[i0 != i1 && t[i0].f < t[i22].f ? i0++ : i22++];
    t[i1++] = { s: -1, f: l.f + r.f, l, r };
  }
  var maxSym = t2[0].s;
  for (var i2 = 1; i2 < s; ++i2) {
    if (t2[i2].s > maxSym)
      maxSym = t2[i2].s;
  }
  var tr = new u16(maxSym + 1);
  var mbt = ln(t[i1 - 1], tr, 0);
  if (mbt > mb) {
    var i2 = 0, dt = 0;
    var lft = mbt - mb, cst = 1 << lft;
    t2.sort(function(a, b) {
      return tr[b.s] - tr[a.s] || a.f - b.f;
    });
    for (; i2 < s; ++i2) {
      var i2_1 = t2[i2].s;
      if (tr[i2_1] > mb) {
        dt += cst - (1 << mbt - tr[i2_1]);
        tr[i2_1] = mb;
      } else
        break;
    }
    dt >>= lft;
    while (dt > 0) {
      var i2_2 = t2[i2].s;
      if (tr[i2_2] < mb)
        dt -= 1 << mb - tr[i2_2]++ - 1;
      else
        ++i2;
    }
    for (; i2 >= 0 && dt; --i2) {
      var i2_3 = t2[i2].s;
      if (tr[i2_3] == mb) {
        --tr[i2_3];
        ++dt;
      }
    }
    mbt = mb;
  }
  return { t: new u8(tr), l: mbt };
};
var ln = function(n, l, d) {
  return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
  var s = c.length;
  while (s && !c[--s])
    ;
  var cl = new u16(++s);
  var cli = 0, cln = c[0], cls = 1;
  var w = function(v) {
    cl[cli++] = v;
  };
  for (var i2 = 1; i2 <= s; ++i2) {
    if (c[i2] == cln && i2 != s)
      ++cls;
    else {
      if (!cln && cls > 2) {
        for (; cls > 138; cls -= 138)
          w(32754);
        if (cls > 2) {
          w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
          cls = 0;
        }
      } else if (cls > 3) {
        w(cln), --cls;
        for (; cls > 6; cls -= 6)
          w(8304);
        if (cls > 2)
          w(cls - 3 << 5 | 8208), cls = 0;
      }
      while (cls--)
        w(cln);
      cls = 1;
      cln = c[i2];
    }
  }
  return { c: cl.subarray(0, cli), n: s };
};
var clen = function(cf, cl) {
  var l = 0;
  for (var i2 = 0; i2 < cl.length; ++i2)
    l += cf[i2] * cl[i2];
  return l;
};
var wfblk = function(out, pos, dat) {
  var s = dat.length;
  var o = shft(pos + 2);
  out[o] = s & 255;
  out[o + 1] = s >> 8;
  out[o + 2] = out[o] ^ 255;
  out[o + 3] = out[o + 1] ^ 255;
  for (var i2 = 0; i2 < s; ++i2)
    out[o + i2 + 4] = dat[i2];
  return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
  wbits(out, p++, final);
  ++lf[256];
  var _a2 = hTree(lf, 15), dlt = _a2.t, mlb = _a2.l;
  var _b2 = hTree(df, 15), ddt = _b2.t, mdb = _b2.l;
  var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
  var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
  var lcfreq = new u16(19);
  for (var i2 = 0; i2 < lclt.length; ++i2)
    ++lcfreq[lclt[i2] & 31];
  for (var i2 = 0; i2 < lcdt.length; ++i2)
    ++lcfreq[lcdt[i2] & 31];
  var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
  var nlcc = 19;
  for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
    ;
  var flen = bl + 5 << 3;
  var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
  var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
  if (bs >= 0 && flen <= ftlen && flen <= dtlen)
    return wfblk(out, p, dat.subarray(bs, bs + bl));
  var lm, ll, dm, dl;
  wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
  if (dtlen < ftlen) {
    lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
    var llm = hMap(lct, mlcb, 0);
    wbits(out, p, nlc - 257);
    wbits(out, p + 5, ndc - 1);
    wbits(out, p + 10, nlcc - 4);
    p += 14;
    for (var i2 = 0; i2 < nlcc; ++i2)
      wbits(out, p + 3 * i2, lct[clim[i2]]);
    p += 3 * nlcc;
    var lcts = [lclt, lcdt];
    for (var it = 0; it < 2; ++it) {
      var clct = lcts[it];
      for (var i2 = 0; i2 < clct.length; ++i2) {
        var len = clct[i2] & 31;
        wbits(out, p, llm[len]), p += lct[len];
        if (len > 15)
          wbits(out, p, clct[i2] >> 5 & 127), p += clct[i2] >> 12;
      }
    }
  } else {
    lm = flm, ll = flt, dm = fdm, dl = fdt;
  }
  for (var i2 = 0; i2 < li; ++i2) {
    var sym = syms[i2];
    if (sym > 255) {
      var len = sym >> 18 & 31;
      wbits16(out, p, lm[len + 257]), p += ll[len + 257];
      if (len > 7)
        wbits(out, p, sym >> 23 & 31), p += fleb[len];
      var dst = sym & 31;
      wbits16(out, p, dm[dst]), p += dl[dst];
      if (dst > 3)
        wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
    } else {
      wbits16(out, p, lm[sym]), p += ll[sym];
    }
  }
  wbits16(out, p, lm[256]);
  return p + ll[256];
};
var deo = /* @__PURE__ */ new i32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
var et = /* @__PURE__ */ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
  var s = st.z || dat.length;
  var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
  var w = o.subarray(pre, o.length - post);
  var lst = st.l;
  var pos = (st.r || 0) & 7;
  if (lvl) {
    if (pos)
      w[0] = st.r >> 3;
    var opt = deo[lvl - 1];
    var n = opt >> 13, c = opt & 8191;
    var msk_1 = (1 << plvl) - 1;
    var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
    var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
    var hsh = function(i3) {
      return (dat[i3] ^ dat[i3 + 1] << bs1_1 ^ dat[i3 + 2] << bs2_1) & msk_1;
    };
    var syms = new i32(25e3);
    var lf = new u16(288), df = new u16(32);
    var lc_1 = 0, eb = 0, i2 = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
    for (; i2 + 2 < s; ++i2) {
      var hv = hsh(i2);
      var imod = i2 & 32767, pimod = head[hv];
      prev[imod] = pimod;
      head[hv] = imod;
      if (wi <= i2) {
        var rem = s - i2;
        if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
          pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i2 - bs, pos);
          li = lc_1 = eb = 0, bs = i2;
          for (var j = 0; j < 286; ++j)
            lf[j] = 0;
          for (var j = 0; j < 30; ++j)
            df[j] = 0;
        }
        var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
        if (rem > 2 && hv == hsh(i2 - dif)) {
          var maxn = Math.min(n, rem) - 1;
          var maxd = Math.min(32767, i2);
          var ml = Math.min(258, rem);
          while (dif <= maxd && --ch_1 && imod != pimod) {
            if (dat[i2 + l] == dat[i2 + l - dif]) {
              var nl = 0;
              for (; nl < ml && dat[i2 + nl] == dat[i2 + nl - dif]; ++nl)
                ;
              if (nl > l) {
                l = nl, d = dif;
                if (nl > maxn)
                  break;
                var mmd = Math.min(dif, nl - 2);
                var md = 0;
                for (var j = 0; j < mmd; ++j) {
                  var ti = i2 - dif + j & 32767;
                  var pti = prev[ti];
                  var cd = ti - pti & 32767;
                  if (cd > md)
                    md = cd, pimod = ti;
                }
              }
            }
            imod = pimod, pimod = prev[imod];
            dif += imod - pimod & 32767;
          }
        }
        if (d) {
          syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
          var lin = revfl[l] & 31, din = revfd[d] & 31;
          eb += fleb[lin] + fdeb[din];
          ++lf[257 + lin];
          ++df[din];
          wi = i2 + l;
          ++lc_1;
        } else {
          syms[li++] = dat[i2];
          ++lf[dat[i2]];
        }
      }
    }
    for (i2 = Math.max(i2, wi); i2 < s; ++i2) {
      syms[li++] = dat[i2];
      ++lf[dat[i2]];
    }
    pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i2 - bs, pos);
    if (!lst) {
      st.r = pos & 7 | w[pos / 8 | 0] << 3;
      pos -= 7;
      st.h = head, st.p = prev, st.i = i2, st.w = wi;
    }
  } else {
    for (var i2 = st.w || 0; i2 < s + lst; i2 += 65535) {
      var e = i2 + 65535;
      if (e >= s) {
        w[pos / 8 | 0] = lst;
        e = s;
      }
      pos = wfblk(w, pos + 1, dat.subarray(i2, e));
    }
    st.i = s;
  }
  return slc(o, 0, pre + shft(pos) + post);
};
var crct = /* @__PURE__ */ (function() {
  var t = new Int32Array(256);
  for (var i2 = 0; i2 < 256; ++i2) {
    var c = i2, k = 9;
    while (--k)
      c = (c & 1 && -306674912) ^ c >>> 1;
    t[i2] = c;
  }
  return t;
})();
var crc = function() {
  var c = -1;
  return {
    p: function(d) {
      var cr = c;
      for (var i2 = 0; i2 < d.length; ++i2)
        cr = crct[cr & 255 ^ d[i2]] ^ cr >>> 8;
      c = cr;
    },
    d: function() {
      return ~c;
    }
  };
};
var dopt = function(dat, opt, pre, post, st) {
  if (!st) {
    st = { l: 1 };
    if (opt.dictionary) {
      var dict = opt.dictionary.subarray(-32768);
      var newDat = new u8(dict.length + dat.length);
      newDat.set(dict);
      newDat.set(dat, dict.length);
      dat = newDat;
      st.w = dict.length;
    }
  }
  return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
  var o = {};
  for (var k in a)
    o[k] = a[k];
  for (var k in b)
    o[k] = b[k];
  return o;
};
var wbytes = function(d, b, v) {
  for (; v; ++b)
    d[b] = v, v >>>= 8;
};
function deflateSync(data, opts) {
  return dopt(data, opts || {}, 0, 0);
}
var fltn = function(d, p, t, o) {
  for (var k in d) {
    var val = d[k], n = p + k, op = o;
    if (Array.isArray(val))
      op = mrg(o, val[1]), val = val[0];
    if (ArrayBuffer.isView(val))
      t[n] = [val, op];
    else {
      t[n += "/"] = [new u8(0), op];
      fltn(val, n, t, o);
    }
  }
};
var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
function strToU8(str2, latin1) {
  if (latin1) {
    var ar_1 = new u8(str2.length);
    for (var i2 = 0; i2 < str2.length; ++i2)
      ar_1[i2] = str2.charCodeAt(i2);
    return ar_1;
  }
  if (te)
    return te.encode(str2);
  var l = str2.length;
  var ar = new u8(str2.length + (str2.length >> 1));
  var ai = 0;
  var w = function(v) {
    ar[ai++] = v;
  };
  for (var i2 = 0; i2 < l; ++i2) {
    if (ai + 5 > ar.length) {
      var n = new u8(ai + 8 + (l - i2 << 1));
      n.set(ar);
      ar = n;
    }
    var c = str2.charCodeAt(i2);
    if (c < 128 || latin1)
      w(c);
    else if (c < 2048)
      w(192 | c >> 6), w(128 | c & 63);
    else if (c > 55295 && c < 57344)
      c = 65536 + (c & 1023 << 10) | str2.charCodeAt(++i2) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
    else
      w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
  }
  return slc(ar, 0, ai);
}
var exfl = function(ex) {
  var le = 0;
  if (ex) {
    for (var k in ex) {
      var l = ex[k].length;
      if (l > 65535)
        err(9);
      le += l + 4;
    }
  }
  return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
  var fl2 = fn.length, ex = f.extra, col = co && co.length;
  var exl = exfl(ex);
  wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
  if (ce != null)
    d[b++] = 20, d[b++] = f.os;
  d[b] = 20, b += 2;
  d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
  d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
  var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
  if (y < 0 || y > 119)
    err(10);
  wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
  if (c != -1) {
    wbytes(d, b, f.crc);
    wbytes(d, b + 4, c < 0 ? -c - 2 : c);
    wbytes(d, b + 8, f.size);
  }
  wbytes(d, b + 12, fl2);
  wbytes(d, b + 14, exl), b += 16;
  if (ce != null) {
    wbytes(d, b, col);
    wbytes(d, b + 6, f.attrs);
    wbytes(d, b + 10, ce), b += 14;
  }
  d.set(fn, b);
  b += fl2;
  if (exl) {
    for (var k in ex) {
      var exf = ex[k], l = exf.length;
      wbytes(d, b, +k);
      wbytes(d, b + 2, l);
      d.set(exf, b + 4), b += 4 + l;
    }
  }
  if (col)
    d.set(co, b), b += col;
  return b;
};
var wzf = function(o, b, c, d, e) {
  wbytes(o, b, 101010256);
  wbytes(o, b + 8, c);
  wbytes(o, b + 10, c);
  wbytes(o, b + 12, d);
  wbytes(o, b + 16, e);
};
function zipSync(data, opts) {
  if (!opts)
    opts = {};
  var r = {};
  var files = [];
  fltn(data, "", r, opts);
  var o = 0;
  var tot = 0;
  for (var fn in r) {
    var _a2 = r[fn], file = _a2[0], p = _a2[1];
    var compression = p.level == 0 ? 0 : 8;
    var f = strToU8(fn), s = f.length;
    var com = p.comment, m = com && strToU8(com), ms = m && m.length;
    var exl = exfl(p.extra);
    if (s > 65535)
      err(11);
    var d = compression ? deflateSync(file, p) : file, l = d.length;
    var c = crc();
    c.p(file);
    files.push(mrg(p, {
      size: file.length,
      crc: c.d(),
      c: d,
      f,
      m,
      u: s != fn.length || m && com.length != ms,
      o,
      compression
    }));
    o += 30 + s + exl + l;
    tot += 76 + 2 * (s + exl) + (ms || 0) + l;
  }
  var out = new u8(tot + 22), oe = o, cdl = tot - o;
  for (var i2 = 0; i2 < files.length; ++i2) {
    var f = files[i2];
    wzh(out, f.o, f, f.f, f.u, f.c.length);
    var badd = 30 + f.f.length + exfl(f.extra);
    out.set(f.c, f.o + badd);
    wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
  }
  wzf(out, o, files.length, cdl, oe);
  return out;
}

// lib/ckd.mjs
var normalize = (v) => String(v ?? "").trim().toUpperCase();
var tokens = (v) => normalize(v).split(/\s*[/;,\n]\s*/).filter(Boolean);
var quantity = (v) => {
  const n = Number(String(v ?? "").replace(/,/g, ""));
  return Number.isSafeInteger(n) && n > 0 && n <= 1e9 ? n : null;
};
function makerMatches(a, b) {
  const words = (v) => normalize(v).normalize("NFKD").replace(new RegExp("\\p{M}", "gu"), "").replace(/[^\p{L}\p{N}]+/gu, " ").split(/\s+/).filter((w) => w.length >= 2 && !["CO", "LTD", "LIMITED", "INC", "CORP", "CORPORATION", "COMPANY", "THE"].includes(w));
  const parts = (v) => String(v ?? "").split(/[/;,]/).map((x3) => words(x3).join("")).filter((x3) => x3.length >= 2);
  return parts(a).some((x3) => parts(b).some((y) => x3.includes(y) || y.includes(x3))) || words(a).some((x3) => words(b).includes(x3) && x3.length >= 3);
}
function checkCkd(db, b) {
  var _a2;
  const workbook = Number(b.workbook_id), source = db.prepare("SELECT * FROM ckd_workbooks WHERE id=?").get(workbook);
  if (!Number.isSafeInteger(workbook) || !source || source.kind === "models") throw Error("Ch\u1ECDn \u0111\u01A1n h\xE0ng SO tr\u01B0\u1EDBc khi qu\xE9t.");
  const modelWorkbook = b.model_workbook_id === void 0 || b.model_workbook_id === null ? workbook : Number(b.model_workbook_id);
  if (!Number.isSafeInteger(modelWorkbook) || modelWorkbook < 1 || !db.prepare("SELECT 1 FROM ckd_models WHERE workbook_id=? LIMIT 1").get(modelWorkbook)) throw Error("Ch\u1ECDn CKD model list \u0111\xE3 nh\u1EADp tr\u01B0\u1EDBc khi qu\xE9t.");
  const raw = normalize(b.samsung), itemCode = normalize(b.item_code);
  if (!raw || !itemCode || raw.length > 500 || itemCode.length > 500) throw Error("C\u1EA7n qu\xE9t \u0111\u1EE7 m\xE3 Samsung v\xE0 ITEM code, t\u1ED1i \u0111a 500 k\xFD t\u1EF1.");
  const all = db.prepare("SELECT DISTINCT samsung FROM ckd_models WHERE workbook_id=?").all(modelWorkbook);
  const code2 = all.map((r) => r.samsung).sort((a, b2) => b2.length - a.length).find((c) => raw === c || raw.startsWith(c) && /^(?:BN|AH|\d)/.test(raw.slice(c.length))) || raw;
  const models = db.prepare("SELECT * FROM ckd_models WHERE workbook_id=? AND samsung=?").all(modelWorkbook, code2);
  const model = models.find((m) => tokens(m.items).includes(itemCode));
  const orders = db.prepare("SELECT * FROM ckd_orders WHERE workbook_id=? AND samsung=?").all(workbook, code2);
  const eligible = orders.filter((o) => tokens(o.selling_code).includes(itemCode));
  const inventory = db.prepare("SELECT DISTINCT maker,vendor FROM mm_inventory WHERE item_code=? ORDER BY maker,vendor").all(itemCode);
  const legacy = db.prepare("SELECT item_code,maker,vendor FROM materials WHERE item_code=? COLLATE NOCASE").get(itemCode);
  const mm = inventory.length ? inventory : legacy ? [legacy] : [];
  const candidates = [...new Set(mm.map((m) => {
    var _a3;
    return (_a3 = m.maker) == null ? void 0 : _a3.trim();
  }).filter(Boolean))];
  const sellingMaker = candidates.find((m) => eligible.some((o) => makerMatches(m, o.so_maker))) || candidates.join(" / ");
  const match = eligible.find((o) => makerMatches(sellingMaker, o.so_maker));
  const errors = [];
  if (!models.length) errors.push("M\xE3 Samsung kh\xF4ng c\xF3 trong CKD model list.");
  else if (!model) errors.push("ITEM v\u1EEBa qu\xE9t kh\xF4ng kh\u1EDBp HS Code c\u1EE7a m\xE3 Samsung trong model list.");
  if (!orders.length) errors.push("M\xE3 Samsung kh\xF4ng c\xF3 trong SO \u0111ang ch\u1ECDn.");
  else if (!eligible.length) errors.push("ITEM kh\xF4ng thu\u1ED9c Selling Code c\u1EA7n b\xE1n c\u1EE7a SO.");
  if (!mm.length) errors.push("ITEM ch\u01B0a c\xF3 trong MM.");
  else if (!sellingMaker) errors.push("ITEM trong MM ch\u01B0a c\xF3 Maker.");
  else if (eligible.length && !match) errors.push("Maker b\xE1n t\u1EEB MM kh\xF4ng kh\u1EDBp SO Maker.");
  const expected_codes = { items: [...new Set(models.flatMap((m) => tokens(m.items)))], selling_items: [...new Set(orders.flatMap((o) => tokens(o.selling_code)))], samsung: errors.length ? [...new Set(db.prepare("SELECT samsung,items FROM ckd_models WHERE workbook_id=?").all(modelWorkbook).filter((m) => tokens(m.items).includes(itemCode)).map((m) => m.samsung))] : [] };
  const chosen = model || models[0] || null, order = match || eligible[0] || orders[0] || null;
  const sellingVendor = ((_a2 = mm.find((m) => {
    var _a3;
    return ((_a3 = m.maker) == null ? void 0 : _a3.trim()) === sellingMaker;
  })) == null ? void 0 : _a2.vendor) || (order == null ? void 0 : order.vendor) || "";
  const qty2 = b.qty !== void 0 && String(b.qty).trim() !== "" ? quantity(b.qty) : (chosen == null ? void 0 : chosen.moq) || null;
  if (b.qty !== void 0 && String(b.qty).trim() !== "" && !qty2) throw Error("S\u1ED1 l\u01B0\u1EE3ng box ph\u1EA3i l\xE0 s\u1ED1 nguy\xEAn d\u01B0\u01A1ng, t\u1ED1i \u0111a 1 t\u1EF7.");
  const current = db.prepare("SELECT COUNT(*) boxes,COALESCE(SUM(qty),0) total FROM ckd_checks WHERE workbook_id=? AND samsung=? AND counted=1").get(workbook, code2);
  const target = orders.reduce((sum2, o) => sum2 + o.selling_qty, 0), after = current.total + (qty2 || 0);
  const effective = errors.length ? current.total : after;
  return { expected_codes, model_workbook_id: modelWorkbook, workbook_id: workbook, session_name: String(b.session_name || "").trim().slice(0, 80), samsung: code2, raw_samsung: raw, item_code: itemCode, selling_maker: sellingMaker, selling_vendor: sellingVendor, maker_source: "MM", maker_match: Boolean(match), pass: errors.length === 0, status: errors.length ? "NG" : "PASS", quantity_status: !target ? "Ch\u01B0a c\xF3 SO" : effective > target ? "D\u01B0" : effective === target ? "\u0110\u1EE7" : "Thi\u1EBFu", reason: errors.join(" ") || "Hai m\xE3 kh\u1EDBp; Maker MM ph\xF9 h\u1EE3p SO.", model: chosen, order, orders, target, qty: qty2, needs_qty: !qty2, ...current, after, over: target > 0 && after > target, remaining: Math.max(0, target - current.total) };
}
function ckdOverview(db, workbook) {
  const where = workbook ? "workbook_id=?" : "1=1", args = workbook ? [workbook] : [];
  const checks = db.prepare(`SELECT c.id,c.workbook_id,w.name workbook_name,c.box_ref,c.samsung,c.item_code,c.status,c.qty,c.counted,c.snapshot,c.created_at,u.name scanner,EXISTS(SELECT 1 FROM ckd_check_images i WHERE i.check_id=c.id AND i.slot='samsung') samsung_image,EXISTS(SELECT 1 FROM ckd_check_images i WHERE i.check_id=c.id AND i.slot='item') item_image FROM ckd_checks c JOIN users u ON u.id=c.user_id JOIN ckd_workbooks w ON w.id=c.workbook_id WHERE ${workbook ? "c.workbook_id=?" : "1=1"} ORDER BY c.id DESC`).all(...args).map((r) => ({ ...r, check: JSON.parse(r.snapshot), snapshot: void 0 }));
  const orders = db.prepare(`SELECT o.*,w.name workbook_name FROM ckd_orders o JOIN ckd_workbooks w ON w.id=o.workbook_id WHERE ${workbook ? "o.workbook_id=?" : "1=1"}`).all(...args);
  const grouped = /* @__PURE__ */ new Map();
  for (const o of orders) {
    const key = o.workbook_id + "|" + o.samsung;
    let g = grouped.get(key);
    if (!g) {
      g = { workbook_id: o.workbook_id, workbook_name: o.workbook_name, samsung: o.samsung, target: 0, scans: 0, boxes: 0, ng: 0, total: 0, items: /* @__PURE__ */ new Set(), makers: /* @__PURE__ */ new Set() };
      grouped.set(key, g);
    }
    g.target += o.selling_qty;
    for (const item of tokens(o.selling_code)) g.items.add(item);
    if (o.so_maker) g.makers.add(o.so_maker);
  }
  for (const c of checks) {
    const key = c.workbook_id + "|" + c.samsung;
    let g = grouped.get(key);
    if (!g) {
      g = { workbook_id: c.workbook_id, workbook_name: c.workbook_name, samsung: c.samsung, target: 0, scans: 0, boxes: 0, ng: 0, total: 0, items: /* @__PURE__ */ new Set(), makers: /* @__PURE__ */ new Set() };
      grouped.set(key, g);
    }
    g.scans++;
    if (c.counted) {
      g.boxes++;
      g.total += c.qty;
    } else g.ng++;
  }
  const rows = [...grouped.values()].map((g) => ({ ...g, items: [...g.items], so_makers: [...g.makers], makers: void 0, remaining: Math.max(0, g.target - g.total), quantity_status: !g.target ? "Ngo\xE0i SO" : g.total > g.target ? "D\u01B0" : g.total === g.target ? "\u0110\u1EE7" : "Thi\u1EBFu" }));
  return { checks, summary: rows.filter((g) => g.scans > 0), unsold: rows.filter((g) => g.scans === 0) };
}
function saveCkd(db, b, userId, images = []) {
  if (typeof b.request_id !== "string" || !/^[a-zA-Z0-9-]{16,80}$/.test(b.request_id)) throw Error("M\xE3 y\xEAu c\u1EA7u kh\xF4ng h\u1EE3p l\u1EC7.");
  const box = b.box_ref ? normalize(b.box_ref) : "BOX-" + b.request_id;
  if (box.length > 200) throw Error("M\xE3 l\u01B0\u1EE3t l\u01B0u qu\xE1 d\xE0i.");
  return transaction(db, () => {
    if (db.prepare("SELECT 1 FROM ckd_deleted_requests WHERE request_id=?").get(b.request_id)) throw Error("L\u01B0\u1EE3t qu\xE9t n\xE0y \u0111\xE3 b\u1ECB x\xF3a. H\xE3y qu\xE9t l\u1EA1i \u0111\u1EC3 t\u1EA1o l\u01B0\u1EE3t m\u1EDBi.");
    const old = db.prepare("SELECT id,user_id,snapshot FROM ckd_checks WHERE request_id=?").get(b.request_id);
    if (old) {
      if (old.user_id !== userId) throw Error("M\xE3 y\xEAu c\u1EA7u \u0111\xE3 t\u1ED3n t\u1EA1i.");
      return { id: old.id, duplicate: true, check: JSON.parse(old.snapshot) };
    }
    const check = checkCkd(db, b);
    if (db.prepare("SELECT id FROM ckd_checks WHERE workbook_id=? AND box_ref=?").get(check.workbook_id, box)) throw Error("M\xE3 box \u0111\xE3 \u0111\u01B0\u1EE3c l\u01B0u trong file SO n\xE0y.");
    if (!check.pass && b.accept_ng !== true) throw Error("NG: c\u1EA7n ch\u1ECDn r\xF5 L\u01B0u NG \u0111\u1EC3 l\u01B0u l\u1ECBch s\u1EED.");
    if (check.pass && !check.qty) throw Error("MOQ ch\u01B0a r\xF5. Nh\u1EADp s\u1ED1 l\u01B0\u1EE3ng box th\u1EF1c t\u1EBF.");
    if (check.pass && check.over && b.accept_over !== true) throw Error("V\u01B0\u1EE3t Selling Qty. C\u1EA7n x\xE1c nh\u1EADn c\u1EA3nh b\xE1o v\u01B0\u1EE3t tr\u01B0\u1EDBc khi l\u01B0u.");
    const nextId = db.prepare("SELECT COALESCE(MAX(n),0)+1 id FROM (SELECT MAX(id) n FROM ckd_checks UNION ALL SELECT MAX(check_id) n FROM ckd_deleted_requests)").get().id;
    const saved = db.prepare("INSERT INTO ckd_checks(id,request_id,workbook_id,box_ref,samsung,item_code,status,qty,counted,snapshot,user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)").run(nextId, b.request_id, check.workbook_id, box, check.samsung, check.item_code, check.status, check.qty || 0, check.pass ? 1 : 0, JSON.stringify(check), userId);
    for (const image of images) db.prepare("INSERT INTO ckd_check_images(check_id,slot,mime,image,thumbnail) VALUES (?,?,?,?,?)").run(saved.lastInsertRowid, image.slot, image.mime, image.buffer, image.thumbnail || null);
    return { id: Number(saved.lastInsertRowid), duplicate: false, check };
  });
}
function deleteCkdHistory(db, b, userId) {
  return transaction(db, () => {
    const invalid = (message2, status = 400) => {
      const error2 = new Error(message2);
      error2.status = status;
      throw error2;
    };
    const global = b.scope === "all", workbook = global ? 0 : Number(b.workbook_id);
    if (!global && (!["string", "number"].includes(typeof b.workbook_id) || !Number.isSafeInteger(workbook) || workbook < 1 || !db.prepare("SELECT 1 FROM ckd_workbooks WHERE id=?").get(workbook))) invalid("Ch\u1ECDn SO c\u1EA7n x\xF3a l\u1ECBch s\u1EED.");
    let where = global ? "1=1" : "workbook_id=?", params = global ? [] : [workbook];
    if (b.all === true) {
      if (!Number.isSafeInteger(b.through_id) || b.through_id < 1) invalid("Thi\u1EBFu m\u1ED1c l\u1ECBch s\u1EED c\u1EA7n x\xF3a.");
      where += " AND id<=?";
      params.push(b.through_id);
    } else {
      if (!Array.isArray(b.ids) || !b.ids.length || b.ids.length > 1e3 || b.ids.some((id) => !Number.isSafeInteger(id) || id < 1)) invalid("Ch\u1ECDn t\u1EEB 1 \u0111\u1EBFn 1.000 l\u01B0\u1EE3t CKD.");
      const ids = [...new Set(b.ids)];
      where += " AND id IN (" + ids.map(() => "?").join(",") + ")";
      params.push(...ids);
      if (db.prepare("SELECT COUNT(*) n FROM ckd_checks WHERE " + where).get(...params).n !== ids.length) invalid("L\u1ECBch s\u1EED \u0111\xE3 thay \u0111\u1ED5i ho\u1EB7c c\xF3 l\u01B0\u1EE3t thu\u1ED9c SO kh\xE1c. T\u1EA3i l\u1EA1i r\u1ED3i ch\u1ECDn l\u1EA1i.", 409);
    }
    const rows = db.prepare("SELECT id,request_id,workbook_id FROM ckd_checks WHERE " + where).all(...params), record = db.prepare("INSERT OR IGNORE INTO ckd_deleted_requests(request_id,check_id,workbook_id,user_id) VALUES (?,?,?,?)");
    for (const row of rows) record.run(row.request_id, row.id, row.workbook_id, userId);
    const result = db.prepare("DELETE FROM ckd_checks WHERE " + where).run(...params);
    return { ok: true, deleted: result.changes, workbook_id: workbook };
  });
}

// lib/holding.mjs
init_polyfills();

// lib/formats.mjs
init_polyfills();

// lib/report-layout.mjs
init_polyfills();
var x2 = (v) => String(v ?? "").replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "").replace(/[<>&"']/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[c]);
var columnName = (n) => {
  let result = "";
  for (n++; n; n = Math.floor((n - 1) / 26)) result = String.fromCharCode(65 + (n - 1) % 26) + result;
  return result;
};
var font = (color, bold = false, size = 10) => `<font><sz val="${size}"/><color rgb="FF${color}"/><name val="Aptos"/>${bold ? "<b/>" : ""}</font>`;
var fill = (color) => `<fill><patternFill patternType="solid"><fgColor rgb="FF${color}"/><bgColor indexed="64"/></patternFill></fill>`;
var xf = (fontId, fillId, numFmtId = 0, center = false) => `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="1" xfId="0" applyAlignment="1" applyFill="1" applyFont="1"${numFmtId ? ' applyNumberFormat="1"' : ""}><alignment vertical="center" horizontal="${center ? "center" : numFmtId ? "right" : "left"}" wrapText="1"/></xf>`;
var reportStyles = `<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.#########;[Red](#,##0.#########);0"/><numFmt numFmtId="165" formatCode="dd/mm/yyyy hh:mm"/></numFmts><fonts count="9">${font("263E50")}${font("FFFFFF", true)}${font("FFFFFF", true, 20)}${font("153B54", true, 11)}${font("6B8191", false, 9)}${font("18744C", true)}${font("B33845", true)}${font("946016", true)}${font("236FA1")}</fonts><fills count="9"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>${fill("12364D")}${fill("EAF2F8")}${fill("F4F7FA")}${fill("245571")}${fill("E3F3EA")}${fill("FCE9EB")}${fill("FFF2D9")}</fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top/><bottom style="thin"><color rgb="FFE1E8EF"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="20">${xf(0, 0)}${xf(0, 4)}${xf(0, 4, 164)}${xf(0, 0, 164)}${xf(1, 5, 0, true)}${xf(1, 2)}${xf(2, 2)}${xf(4, 3)}${xf(4, 0)}${xf(3, 3)}${xf(5, 6, 0, true)}${xf(6, 7, 0, true)}${xf(7, 8, 0, true)}${xf(0, 0, 165)}${xf(0, 4, 165)}${xf(8, 0)}${xf(8, 4)}${xf(3, 0)}<xf numFmtId="0" fontId="8" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="bottom" horizontal="center" wrapText="1"/></xf><xf numFmtId="0" fontId="8" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="bottom" horizontal="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
var statusStyle = (value) => /^(PASS|ĐỦ|KHỚP|KHÔNG TRÙNG)$/i.test(String(value)) ? 10 : /^(NG|DƯ|SAI|TRÙNG)$/i.test(String(value)) ? 11 : /^(THIẾU|CHƯA GHI|NGOÀI SO)$/i.test(String(value)) ? 12 : null;
function width(header, rows, col) {
  if (/description|mô tả|ghi chú|spec/i.test(header)) return 44;
  if (/ảnh|image/i.test(header)) return 23;
  if (/thời gian|giờ scan|ngày|date/i.test(header)) return 23;
  if (/samsung|barcode|item|box|phiếu|lô/i.test(header)) return Math.min(30, Math.max(20, header.length + 3));
  if (/số lượng|qty|moq|đã bán|còn thiếu|tổng|lượt|^ng$|^id$|stt/i.test(header)) return Math.min(21, Math.max(12, header.length * 0.75 + 3));
  const length = Math.max(header.length, ...rows.slice(0, 250).map((r) => String(r[col] ?? "").length));
  return Math.min(34, Math.max(17, length + 2));
}
function renderReportSheet(sheet, index, metadata) {
  const source = sheet.rows || [], headers = (source[0] || ["N\u1ED9i dung"]).map((h) => {
    const label = String(h).replace(/Thời gian UTC/g, "Th\u1EDDi gian (GMT+7)").replace(/Giờ scan UTC/g, "Gi\u1EDD scan (GMT+7)");
    return /^(thời gian|giờ scan|giờ nhập|giờ xuất)/i.test(label) && !label.includes("GMT+7") ? label + " (GMT+7)" : label;
  });
  const data = source.slice(1), cols = headers.length, last = columnName(cols - 1), widths = headers.map((h, i2) => width(h, data, i2)), relations = [], links = [];
  const imageCells = new Set((sheet.images || []).map((i2) => i2.row + "|" + i2.col)), imageRows = new Set((sheet.images || []).map((i2) => i2.row));
  const now = metadata.generatedAt || /* @__PURE__ */ new Date(), stamp = new Intl.DateTimeFormat("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", dateStyle: "short", timeStyle: "short" }).format(now);
  const textCell = (ref, value, style) => `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${x2(value)}</t></is></c>`;
  function fullRow(row, value, style, height) {
    return `<row r="${row}" ht="${height}" customHeight="1">${Array.from({ length: cols }, (_, i2) => textCell(columnName(i2) + row, i2 ? "" : value, style)).join("")}</row>`;
  }
  let content = fullRow(1, "HANSOL  /  HEVH  \xB7  WORK AREA", 5, 23) + fullRow(2, metadata.title || "B\xC1O C\xC1O C\xD4NG VI\u1EC6C", 6, 38) + fullRow(3, [sheet.title || sheet.name, metadata.scope].filter(Boolean).join("  \u2022  "), 7, 28) + fullRow(4, `Xu\u1EA5t: ${stamp} (GMT+7)${metadata.exportedBy ? "  |  Ng\u01B0\u1EDDi xu\u1EA5t: " + metadata.exportedBy : ""}`, 8, 22) + fullRow(5, sheet.summary || `${data.length.toLocaleString("vi-VN")} d\xF2ng d\u1EEF li\u1EC7u${metadata.summary ? "  |  " + metadata.summary : ""}`, 9, 28) + `<row r="6" ht="10" customHeight="1"/>`;
  content += `<row r="7" ht="34" customHeight="1">${headers.map((h, i2) => textCell(columnName(i2) + "7", h, 4)).join("")}</row>`;
  data.forEach((row, rowIndex) => {
    const rowNumber = rowIndex + 8, stripe = rowIndex % 2 !== 0;
    let lines = 1;
    const cells = headers.map((header, col) => {
      let value = row[col] ?? "", style = stripe ? 1 : 0, type = typeof value === "number" ? "number" : "text";
      const ref = columnName(col) + rowNumber;
      if (type === "number") {
        if (!Number.isFinite(value)) value = "";
        else style = stripe ? 2 : 3;
      }
      if (/thời gian|giờ scan|ngày|date/i.test(header) && typeof value === "string" && /^\d{4}-\d\d-\d\d(?:[ T]\d\d:\d\d(?::\d\d(?:\.\d+)?)?(?:Z|[+-]\d\d:\d\d)?)?$/.test(value)) {
        const utc = /[Zz]|[+-]\d\d:\d\d$/.test(value) ? value : value.replace(" ", "T") + (value.length === 10 ? "T00:00:00Z" : "Z");
        const time = Date.parse(utc);
        if (Number.isFinite(time)) {
          value = (time + 7 * 36e5) / 864e5 + 25569;
          style = stripe ? 14 : 13;
          type = "number";
        }
      }
      const status = /kết quả|trạng thái|maker khớp|nhãn số lượng|bán đủ/i.test(header) ? statusStyle(value) : null;
      if (status !== null) style = status;
      if (/^maker bán/i.test(header)) {
        const matchIndex = headers.findIndex((h) => /maker khớp/i.test(h));
        if (matchIndex >= 0) style = statusStyle(row[matchIndex]) ?? 12;
      }
      if (metadata.imageLinks && /^ảnh /i.test(header) && typeof value === "string" && /^images\/[\w./-]+$/.test(value) && !value.includes("..")) {
        const id = "rId" + (relations.length + 1);
        relations.push(`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${x2(value)}" TargetMode="External"/>`);
        links.push(`<hyperlink ref="${ref}" r:id="${id}"/>`);
        value = "M\u1EDF \u1EA3nh \xB7 #" + row[0];
        style = stripe ? 16 : 15;
      }
      if (imageCells.has(rowNumber + "|" + col)) style = stripe ? 19 : 18;
      lines = Math.max(lines, Math.ceil(String(value).length / Math.max(8, widths[col] - 2)));
      return type === "number" && typeof value === "number" ? `<c r="${ref}" s="${style}"><v>${value}</v></c>` : textCell(ref, value, style);
    }).join("");
    content += `<row r="${rowNumber}" ht="${Math.min(120, Math.max(imageRows.has(rowNumber) ? 96 : 27, lines * 15 + 8))}" customHeight="1">${cells}</row>`;
  });
  if (!data.length) content += fullRow(8, "Ch\u01B0a c\xF3 d\u1EEF li\u1EC7u trong ph\u1EA1m vi b\xE1o c\xE1o.", 8, 32);
  const end = Math.max(8, data.length + 7), merges = Array.from({ length: 5 }, (_, i2) => cols > 1 ? `<mergeCell ref="A${i2 + 1}:${last}${i2 + 1}"/>` : "").join("") + (!data.length && cols > 1 ? `<mergeCell ref="A8:${last}8"/>` : "");
  const sheetXml = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><tabColor rgb="FF${index === 0 ? "217D70" : "245571"}"/><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:${last}${end}"/><sheetViews><sheetView workbookViewId="0" showGridLines="0" zoomScale="85"><pane xSplit="${cols > 3 ? 2 : 0}" ySplit="7" topLeftCell="${cols > 3 ? "C" : "A"}8" activePane="${cols > 3 ? "bottomRight" : "bottomLeft"}" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="27"/><cols>${widths.map((w, i2) => `<col min="${i2 + 1}" max="${i2 + 1}" width="${w}" customWidth="1"/>`).join("")}</cols><sheetData>${content}</sheetData><autoFilter ref="A7:${last}${Math.max(7, data.length + 7)}"/>${merges ? `<mergeCells count="${5 + (data.length ? 0 : 1)}">${merges}</mergeCells>` : ""}${links.length ? `<hyperlinks>${links.join("")}</hyperlinks>` : ""}<printOptions horizontalCentered="1"/><pageMargins left="0.3" right="0.3" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="${cols > 12 ? 8 : 9}" orientation="landscape" fitToWidth="1" fitToHeight="0"/><headerFooter><oddHeader>&amp;L&amp;9HANSOL \xB7 HEVH&amp;R&amp;9${x2(sheet.title || sheet.name)}</oddHeader><oddFooter>&amp;L&amp;8Work Area \xB7 N\u1ED9i b\u1ED9&amp;R&amp;8Trang &amp;P / &amp;N</oddFooter></headerFooter></worksheet>`;
  return { xml: sheetXml, lastRow: end, lastColumn: last, relations: relations.length ? `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relations.join("")}</Relationships>` : null };
}

// lib/report-images.mjs
init_polyfills();
var esc = (v) => String(v ?? "").replace(/[<>&"']/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[c]);
function dimensions(bytes, mime) {
  if (mime === "image/png" && bytes.length >= 24) return [bytes.readUInt32BE(16), bytes.readUInt32BE(20)];
  if (mime === "image/jpeg") {
    let pos = 2;
    while (pos + 9 < bytes.length) {
      if (bytes[pos++] !== 255) continue;
      const marker = bytes[pos++];
      if (marker === 216 || marker === 217) continue;
      const size = bytes.readUInt16BE(pos);
      if (size < 2) break;
      if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) return [bytes.readUInt16BE(pos + 5), bytes.readUInt16BE(pos + 3)];
      pos += size;
    }
  }
  return [128, 128];
}
function reportDrawings(images, index) {
  const parts = {}, rels = [], pictures = [], types = /* @__PURE__ */ new Map();
  images.forEach((image, i2) => {
    const data = import_buffer.Buffer.from(image.data), ext = image.mime === "image/png" ? "png" : image.mime === "image/webp" ? "webp" : "jpg", name = `report${index + 1}image${i2 + 1}.${ext}`;
    const [w, h] = dimensions(data, image.mime), scale = Math.min(112 / Math.max(1, w), 88 / Math.max(1, h)), width2 = Math.max(1, Math.round(w * scale)), height = Math.max(1, Math.round(h * scale));
    parts["xl/media/" + name] = data;
    types.set(ext, image.mime);
    rels.push(`<Relationship Id="rId${i2 + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${name}"/>`);
    pictures.push(`<xdr:oneCellAnchor><xdr:from><xdr:col>${image.col}</xdr:col><xdr:colOff>${Math.max(8, Math.round((161 - width2) / 2)) * 9525}</xdr:colOff><xdr:row>${image.row - 1}</xdr:row><xdr:rowOff>57150</xdr:rowOff></xdr:from><xdr:ext cx="${width2 * 9525}" cy="${height * 9525}"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="${i2 + 1}" name="Image ${i2 + 1}" descr="${esc(image.alt || "\u1EA2nh \u0111\u1ED1i chi\u1EBFu")}"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId${i2 + 1}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${width2 * 9525}" cy="${height * 9525}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>`);
  });
  parts[`xl/drawings/drawing${index + 1}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${pictures.join("")}</xdr:wsDr>`;
  parts[`xl/drawings/_rels/drawing${index + 1}.xml.rels`] = `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join("")}</Relationships>`;
  return { parts, types };
}

// lib/formats.mjs
var xml = (text2) => String(text2 ?? "").replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "").replace(/[<>&"']/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[c]);
var crcTable = Array.from({ length: 256 }, (_, i2) => {
  for (let j = 0; j < 8; j++) i2 = i2 & 1 ? 3988292384 ^ i2 >>> 1 : i2 >>> 1;
  return i2 >>> 0;
});
function crc32(data) {
  let crc2 = 4294967295;
  for (const b of data) crc2 = crcTable[(crc2 ^ b) & 255] ^ crc2 >>> 8;
  return (crc2 ^ 4294967295) >>> 0;
}
function zip(files) {
  const chunks = [], directory = [];
  let offset = 0;
  for (const [path, source] of Object.entries(files)) {
    const name = import_buffer.Buffer.from(path), data = import_buffer.Buffer.from(source), crc2 = crc32(data);
    const head = import_buffer.Buffer.alloc(30);
    head.writeUInt32LE(67324752);
    head.writeUInt16LE(20, 4);
    head.writeUInt16LE(33, 12);
    head.writeUInt32LE(crc2, 14);
    head.writeUInt32LE(data.length, 18);
    head.writeUInt32LE(data.length, 22);
    head.writeUInt16LE(name.length, 26);
    const entry = import_buffer.Buffer.alloc(46);
    entry.writeUInt32LE(33639248);
    entry.writeUInt16LE(20, 4);
    entry.writeUInt16LE(20, 6);
    entry.writeUInt16LE(33, 14);
    entry.writeUInt32LE(crc2, 16);
    entry.writeUInt32LE(data.length, 20);
    entry.writeUInt32LE(data.length, 24);
    entry.writeUInt16LE(name.length, 28);
    entry.writeUInt32LE(offset, 42);
    chunks.push(head, name, data);
    directory.push(entry, name);
    offset += head.length + name.length + data.length;
  }
  const central = import_buffer.Buffer.concat(directory), end = import_buffer.Buffer.alloc(22), count = Object.keys(files).length;
  end.writeUInt32LE(101010256);
  end.writeUInt16LE(count, 8);
  end.writeUInt16LE(count, 10);
  end.writeUInt32LE(central.length, 12);
  end.writeUInt32LE(offset, 16);
  return import_buffer.Buffer.concat([...chunks, central, end]);
}
function reportWorkbook(sheets, metadata = {}) {
  return excelWorkbook(sheets, { ...metadata, generatedAt: metadata.generatedAt || /* @__PURE__ */ new Date() });
}
function excelWorkbook(sheets, metadata = null) {
  const column = (n) => {
    let r = "";
    for (n++; n; n = Math.floor((n - 1) / 26)) r = String.fromCharCode(65 + (n - 1) % 26) + r;
    return r;
  };
  const parts = {}, printDefinitions = [];
  sheets.forEach((sheet, index) => {
    if (metadata) return;
    const data = sheet.rows.map((row, i2) => `<row r="${i2 + 1}">${row.map((v, j) => typeof v === "number" ? `<c r="${column(j)}${i2 + 1}"><v>${v}</v></c>` : `<c r="${column(j)}${i2 + 1}" t="inlineStr"><is><t xml:space="preserve">${xml(v)}</t></is></c>`).join("")}</row>`).join("");
    parts[`xl/worksheets/sheet${index + 1}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${data}</sheetData></worksheet>`;
  });
  const files = {
    "[Content_Types].xml": '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
    "_rels/.rels": '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    "xl/workbook.xml": '<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Work Area" sheetId="1" r:id="rId1"/></sheets></workbook>',
    "xl/_rels/workbook.xml.rels": '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'
  };
  files["[Content_Types].xml"] = files["[Content_Types].xml"].replace(/<Override PartName="\/xl\/worksheets\/sheet1.xml"[^>]*\/>/, sheets.map((_, i2) => `<Override PartName="/xl/worksheets/sheet${i2 + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join(""));
  files["xl/workbook.xml"] = files["xl/workbook.xml"].replace(/<sheets>.*?<\/sheets>/, `<sheets>${sheets.map((s, i2) => `<sheet name="${xml(s.name.slice(0, 31))}" sheetId="${i2 + 1}" r:id="rId${i2 + 1}"/>`).join("")}</sheets>`);
  files["xl/_rels/workbook.xml.rels"] = files["xl/_rels/workbook.xml.rels"].replace(/<Relationship Id="rId1"[^>]*\/>/, sheets.map((_, i2) => `<Relationship Id="rId${i2 + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i2 + 1}.xml"/>`).join(""));
  delete files["xl/worksheets/sheet1.xml"];
  if (metadata) {
    sheets.forEach((sheet, index) => {
      var _a2;
      const rendered = renderReportSheet(sheet, index, metadata), name = sheet.name.slice(0, 31).replace(/'/g, "''");
      parts[`xl/worksheets/sheet${index + 1}.xml`] = rendered.xml;
      if (rendered.relations) parts[`xl/worksheets/_rels/sheet${index + 1}.xml.rels`] = rendered.relations;
      if ((_a2 = sheet.images) == null ? void 0 : _a2.length) {
        const drawing = reportDrawings(sheet.images, index), relPath = `xl/worksheets/_rels/sheet${index + 1}.xml.rels`;
        Object.assign(parts, drawing.parts);
        const relationship = `<Relationship Id="rIdDrawing" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing${index + 1}.xml"/>`;
        parts[relPath] = (parts[relPath] || '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>').replace("</Relationships>", relationship + "</Relationships>");
        parts[`xl/worksheets/sheet${index + 1}.xml`] = parts[`xl/worksheets/sheet${index + 1}.xml`].replace("</worksheet>", '<drawing r:id="rIdDrawing"/></worksheet>');
        files["[Content_Types].xml"] = files["[Content_Types].xml"].replace("</Types>", `<Override PartName="/xl/drawings/drawing${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>`);
        for (const [ext, type] of drawing.types) if (!files["[Content_Types].xml"].includes(`Extension="${ext}"`)) files["[Content_Types].xml"] = files["[Content_Types].xml"].replace("</Types>", `<Default Extension="${ext}" ContentType="${type}"/></Types>`);
      }
      printDefinitions.push(`<definedName name="_xlnm.Print_Titles" localSheetId="${index}">${xml(`'${name}'!$1:$7`)}</definedName>`, `<definedName name="_xlnm.Print_Area" localSheetId="${index}">${xml(`'${name}'!$A$1:$${rendered.lastColumn}$${rendered.lastRow}`)}</definedName>`);
    });
    parts["xl/styles.xml"] = reportStyles;
    files["[Content_Types].xml"] = files["[Content_Types].xml"].replace("</Types>", '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>');
    files["xl/_rels/workbook.xml.rels"] = files["xl/_rels/workbook.xml.rels"].replace("</Relationships>", `<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    files["_rels/.rels"] = files["_rels/.rels"].replace("</Relationships>", '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>');
    files["xl/workbook.xml"] = files["xl/workbook.xml"].replace("</workbook>", `<definedNames>${printDefinitions.join("")}</definedNames></workbook>`);
    parts["docProps/core.xml"] = `<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xml(metadata.title || "Work Area Report")}</dc:title><dc:creator>${xml(metadata.exportedBy || "Work Area")}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${metadata.generatedAt.toISOString()}</dcterms:created></cp:coreProperties>`;
    parts["docProps/app.xml"] = '<?xml version="1.0" encoding="UTF-8"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Work Area</Application><Company>HANSOL / HEVH</Company></Properties>';
  }
  return zip({ ...files, ...parts });
}

// offline/crypto.mjs
init_polyfills();

// ../.tools/offline-build/node_modules/@noble/hashes/sha2.js
init_polyfills();

// ../.tools/offline-build/node_modules/@noble/hashes/_md.js
init_polyfills();

// ../.tools/offline-build/node_modules/@noble/hashes/_u64.js
init_polyfills();
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
function setU64FromNum(view, byteOffset, n, isLE) {
  const h = fromNumH(n);
  const l = fromNumL(n);
  view.setUint32(byteOffset, isLE ? l : h, isLE);
  view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}

// ../.tools/offline-build/node_modules/@noble/hashes/utils.js
init_polyfills();
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber(n, title = "") {
  if (typeof n !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n);
  if (!Number.isSafeInteger(n) || n < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
  return n;
}
function abytes(value, length, title = "") {
  if (isBytes(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber(length, "length");
  const bytes = isBytes(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message2 = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message2);
  throw new RangeError(message2);
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput(out, instance) {
  abytes(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function clean(...arrays) {
  for (let i2 = 0; i2 < arrays.length; i2++) {
    arrays[i2].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var oidNist = (suffix) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
});

// ../.tools/offline-build/node_modules/@noble/hashes/_md.js
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class {
  blockLen;
  outputLen;
  canXOF = false;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = false;
  length = 0;
  pos = 0;
  destroyed = false;
  constructor(blockLen, outputLen, padOffset, isLE) {
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    let processed = false;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        processed = true;
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
        processed = true;
      }
    }
    this.length += data.length;
    if (processed)
      this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    buffer.fill(0, pos);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      buffer.fill(0);
    }
    setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
    this.process(view, 0);
    this.roundClean();
    const oview = out === buffer ? view : createView(out);
    const len = this.outputLen;
    const outLen = len / 4;
    const state = this.get();
    if (len % 4 || outLen > state.length)
      throw new Error("invalid outputLen");
    for (let i2 = 0; i2 < outLen; i2++)
      oview.setUint32(4 * i2, state[i2], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneIntoMeta(to) {
    const { buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (pos)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// ../.tools/offline-build/node_modules/@noble/hashes/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B = class extends HashMD {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(outputLen, IV) {
    super(64, outputLen, 8, false);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  _cloneInto(to) {
    (to || (to = new this.constructor())).set(...this.get());
    return this._cloneIntoMeta(to);
  }
  process(view, offset) {
    for (let i2 = 0; i2 < 16; i2++, offset += 4)
      SHA256_W[i2] = view.getUint32(offset, false);
    for (let i2 = 16; i2 < 64; i2++) {
      const W15 = SHA256_W[i2 - 15];
      const W2 = SHA256_W[i2 - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i2] = s1 + SHA256_W[i2 - 7] + s0 + SHA256_W[i2 - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i2 = 0; i2 < 64; i2++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i2] + SHA256_W[i2] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.destroyed = true;
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var _SHA256 = class extends SHA2_32B {
  constructor() {
    super(32, SHA256_IV);
  }
};
var sha256 = /* @__PURE__ */ createHasher(
  () => new _SHA256(),
  /* @__PURE__ */ oidNist(1)
);

// offline/crypto.mjs
function createHash(name) {
  if (name !== "sha256") throw Error("Unsupported hash");
  const chunks = [];
  return { update(value) {
    chunks.push(import_buffer.Buffer.from(value));
    return this;
  }, digest(format) {
    const bytes = import_buffer.Buffer.from(sha256(import_buffer.Buffer.concat(chunks)));
    return format ? bytes.toString(format) : bytes;
  } };
}

// lib/holding.mjs
var error = (message2, status = 400) => {
  const e = new Error(message2);
  e.status = status;
  throw e;
};
var str = (v, label, required = true, max = 200) => {
  if (typeof v !== "string" || v.trim().length > max || required && !v.trim()) error(`${label}: c\u1EA7n nh\u1EADp t\u1ED1i \u0111a ${max} k\xFD t\u1EF1.`);
  return v.trim();
};
var code = (v) => str(v, "M\xE3").toUpperCase();
var qty = (v) => {
  if (!["number", "string"].includes(typeof v) || !String(v).trim() || !Number.isFinite(Number(v)) || Number(v) <= 0 || Number(v) > 1e9 || Number(v) !== Number(Number(v).toFixed(6))) error("QTY ph\u1EA3i l\u1EDBn h\u01A1n 0, t\u1ED1i \u0111a 1 t\u1EF7 v\xE0 t\u1ED1i \u0111a 6 ch\u1EEF s\u1ED1 th\u1EADp ph\xE2n.");
  return Number(v);
};
var rid = (v) => {
  if (typeof v !== "string" || !/^[a-zA-Z0-9-]{16,80}$/.test(v)) error("M\xE3 y\xEAu c\u1EA7u kh\xF4ng h\u1EE3p l\u1EC7.");
  return v;
};
var entryColumns = "id,barcode,item_code,item_name,location,initial_qty,remaining_qty,vendor,lot_no,source,batch_id,user_id,created_at,revision";
var snapshot = (row) => Object.fromEntries(["barcode", "item_code", "item_name", "location", "vendor", "lot_no", "source", "initial_qty", "remaining_qty", "revision"].map((k) => [k, row[k] ?? null]));
function event(db, request, entryId, userId, direction, quantity2, balance, reason, response, before = null) {
  const after = snapshot(db.prepare("SELECT " + entryColumns + " FROM holding_entries WHERE id=?").get(entryId));
  db.prepare("INSERT INTO holding_events(request_id,entry_id,user_id,direction,qty,balance,reason,response,snapshot,before_snapshot) VALUES (?,?,?,?,?,?,?,?,?,?)").run(request, entryId, userId, direction, quantity2, balance, reason, JSON.stringify(response), JSON.stringify(after), before ? JSON.stringify(snapshot(before)) : null);
}
function holdingChanges(before, after) {
  if (!before || !after) return "";
  const fields = { barcode: "Barcode", item_code: "ITEM", item_name: "T\xEAn h\xE0ng", location: "Location", remaining_qty: "QTY c\xF2n", vendor: "Vendor", lot_no: "Lot No" };
  return Object.entries(fields).filter(([key]) => before[key] !== after[key]).map(([key, label]) => `${label}: ${before[key] ?? ""} \u2192 ${after[key] ?? ""}`).join("; ");
}
var activeRefs = `SELECT r.*,b.kind,b.name file_name FROM holding_refs r JOIN holding_ref_batches b ON b.id=r.batch_id WHERE b.id IN (SELECT MAX(id) FROM holding_ref_batches GROUP BY kind)`;
function holdingReference(db) {
  return { batches: db.prepare("SELECT * FROM holding_ref_batches WHERE id IN (SELECT MAX(id) FROM holding_ref_batches GROUP BY kind) ORDER BY kind").all(), barcodes: db.prepare(`SELECT DISTINCT barcode FROM (${activeRefs})`).all().map((r) => r.barcode) };
}
function holdingLookup(db, barcode) {
  barcode = code(barcode);
  return { barcode, matches: db.prepare(`SELECT * FROM (${activeRefs}) WHERE barcode=? ORDER BY kind`).all(barcode), existing: db.prepare("SELECT id,location,remaining_qty FROM holding_entries WHERE barcode=? AND remaining_qty>0").get(barcode) || null };
}
function holdingPreferences(db, userId, body) {
  if (body) {
    const previous = holdingPreferences(db, userId);
    const location2 = Object.hasOwn(body, "location") ? str(body.location, "Location", false) : previous.location;
    const auto = Object.hasOwn(body, "auto_save") ? body.auto_save : previous.auto_save;
    if (typeof auto !== "boolean") error("Ch\u1EBF \u0111\u1ED9 t\u1EF1 l\u01B0u kh\xF4ng h\u1EE3p l\u1EC7.");
    db.prepare("INSERT INTO holding_preferences VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET location=excluded.location,auto_save=excluded.auto_save").run(userId, location2, Number(auto));
  }
  const r = db.prepare("SELECT location,auto_save FROM holding_preferences WHERE user_id=?").get(userId);
  return { location: (r == null ? void 0 : r.location) || "", auto_save: r ? Boolean(r.auto_save) : true };
}
var prior = (db, id, userId, direction) => {
  const row = db.prepare("SELECT * FROM holding_events WHERE request_id=?").get(id);
  if (!row) return null;
  if (row.user_id !== userId || row.direction !== direction) error("M\xE3 y\xEAu c\u1EA7u \u0111\xE3 \u0111\u01B0\u1EE3c d\xF9ng cho thao t\xE1c kh\xE1c.", 409);
  return JSON.parse(row.response);
};
function receiveHolding(db, b, userId, image = { mime: null, buffer: null }) {
  return transaction(db, () => {
    const request = rid(b.request_id), previous = prior(db, request, userId, "in");
    if (previous) return { ...previous, duplicate: true };
    const barcode = code(b.barcode), item = code(b.item_code), location2 = str(b.location, "Location").toUpperCase(), quantity2 = qty(b.qty), vendor = str(b.vendor, "Vendor"), lot = str(b.lot_no ?? "", "Lot No", false), name = str(b.item_name ?? "", "T\xEAn h\xE0ng", false);
    if (db.prepare("SELECT id FROM holding_entries WHERE barcode=? AND remaining_qty>0").get(barcode)) error("Barcode \u0111ang c\xF3 trong t\u1EE7 Holding. Ch\u01B0a nh\u1EADp th\xEAm.", 409);
    let source = "Nh\u1EADp tay", batch = null;
    if (b.batch_id != null) {
      if (!Number.isSafeInteger(b.batch_id)) error("Ngu\u1ED3n file kh\xF4ng h\u1EE3p l\u1EC7.");
      const ref = db.prepare(`SELECT * FROM (${activeRefs}) WHERE batch_id=? AND barcode=?`).get(b.batch_id, barcode);
      if (!ref) error("B\u1EA3ng tra \u0111\xE3 thay \u0111\u1ED5i. Qu\xE9t l\u1EA1i m\xE3.", 409);
      source = ref.kind;
      batch = ref.batch_id;
    }
    const id = Number(db.prepare("INSERT INTO holding_entries(barcode,item_code,item_name,location,initial_qty,remaining_qty,vendor,lot_no,source,batch_id,user_id,image_type,image) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)").run(barcode, item, name, location2, quantity2, quantity2, vendor, lot, source, batch, userId, image.mime, image.buffer).lastInsertRowid);
    const response = { id, barcode, balance: quantity2 };
    event(db, request, id, userId, "in", quantity2, quantity2, "Nh\u1EADp Holding", response);
    db.prepare("INSERT INTO holding_preferences(user_id,location) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET location=excluded.location").run(userId, location2);
    return response;
  });
}
function withdrawHolding(db, b, userId) {
  return transaction(db, () => {
    const request = rid(b.request_id), previous = prior(db, request, userId, "out");
    if (previous) return { ...previous, duplicate: true };
    if (!Number.isSafeInteger(b.entry_id)) error("Box kh\xF4ng h\u1EE3p l\u1EC7.");
    const row = db.prepare("SELECT " + entryColumns + " FROM holding_entries WHERE id=?").get(b.entry_id);
    if (!row) error("Kh\xF4ng t\xECm th\u1EA5y box.", 404);
    if (b.expected_revision != null && (!Number.isSafeInteger(b.expected_revision) || b.expected_revision !== row.revision)) error("Box \u0111\xE3 thay \u0111\u1ED5i. T\u1EA3i l\u1EA1i danh s\xE1ch tr\u01B0\u1EDBc khi xu\u1EA5t.", 409);
    const amount = qty(b.qty), reason = str(b.reason, "L\xFD do xu\u1EA5t", true, 500);
    if (amount > row.remaining_qty) error("QTY xu\u1EA5t v\u01B0\u1EE3t t\u1ED3n hi\u1EC7n t\u1EA1i. T\u1EA3i l\u1EA1i \u0111\u1EC3 ki\u1EC3m tra.", 409);
    const balance = Number((row.remaining_qty - amount).toFixed(6));
    db.prepare("UPDATE holding_entries SET remaining_qty=?,revision=revision+1 WHERE id=?").run(balance, row.id);
    const response = { id: row.id, barcode: row.barcode, balance };
    event(db, request, row.id, userId, "out", amount, balance, reason, response, row);
    return response;
  });
}
function editHoldingInside(db, b, userId, groupId = null) {
  const request = rid(b.request_id), previous = prior(db, request, userId, "edit");
  if (previous) return { ...previous, duplicate: true };
  if (!Number.isSafeInteger(b.entry_id)) error("Box kh\xF4ng h\u1EE3p l\u1EC7.");
  const before = db.prepare("SELECT " + entryColumns + " FROM holding_entries WHERE id=?").get(b.entry_id);
  if (!before) error("Kh\xF4ng t\xECm th\u1EA5y box.", 404);
  if (before.remaining_qty <= 0) error("Box \u0111\xE3 xu\u1EA5t h\u1EBFt. Kh\xF4ng s\u1EEDa l\u1ECBch s\u1EED c\u0169.", 409);
  if (!Number.isSafeInteger(b.expected_revision)) error("Thi\u1EBFu phi\xEAn b\u1EA3n d\u1EEF li\u1EC7u. T\u1EA3i l\u1EA1i danh s\xE1ch.");
  if (b.expected_revision !== before.revision) error("Box v\u1EEBa \u0111\u01B0\u1EE3c ng\u01B0\u1EDDi kh\xE1c thay \u0111\u1ED5i. T\u1EA3i l\u1EA1i danh s\xE1ch tr\u01B0\u1EDBc khi s\u1EEDa.", 409);
  const zero = ["number", "string"].includes(typeof b.remaining_qty) && String(b.remaining_qty).trim() !== "" && Number(b.remaining_qty) === 0;
  const after = { ...before, barcode: code(b.barcode), item_code: code(b.item_code), item_name: str(b.item_name ?? "", "T\xEAn h\xE0ng", false), location: str(b.location, "Location").toUpperCase(), remaining_qty: zero ? 0 : qty(b.remaining_qty), vendor: str(b.vendor, "Vendor"), lot_no: str(b.lot_no ?? "", "Lot No", false) };
  const reason = str(b.reason, "L\xFD do s\u1EEDa", true, 500);
  if (!holdingChanges(snapshot(before), snapshot(after))) error("Ch\u01B0a c\xF3 thay \u0111\u1ED5i d\u1EEF li\u1EC7u.");
  if (after.remaining_qty > 0 && db.prepare("SELECT id FROM holding_entries WHERE barcode=? AND remaining_qty>0 AND id<>?").get(after.barcode, before.id)) error("Barcode \u0111ang thu\u1ED9c m\u1ED9t box kh\xE1c trong t\u1EE7.", 409);
  db.prepare("UPDATE holding_entries SET barcode=?,item_code=?,item_name=?,location=?,remaining_qty=?,vendor=?,lot_no=?,revision=revision+1 WHERE id=?").run(after.barcode, after.item_code, after.item_name, after.location, after.remaining_qty, after.vendor, after.lot_no, before.id);
  const response = { id: before.id, barcode: after.barcode, balance: after.remaining_qty, revision: before.revision + 1, ...groupId ? { group_request_id: groupId } : {} };
  event(db, request, before.id, userId, "edit", Number((after.remaining_qty - before.remaining_qty).toFixed(6)), after.remaining_qty, reason, response, before);
  return response;
}
function editHolding(db, b, userId) {
  return transaction(db, () => editHoldingInside(db, b, userId));
}
function editHoldingGroup(db, b, userId) {
  return transaction(db, () => {
    const request = rid(b.request_id), item = code(b.item_code), reason = str(b.reason, "L\xFD do s\u1EEDa", true, 500);
    if (!Array.isArray(b.rows) || !b.rows.length || b.rows.length > 1e3 || b.rows.some((r) => !r || !Number.isSafeInteger(r.id) || r.id < 1 || !Number.isSafeInteger(r.expected_revision) || r.expected_revision < 0)) error("Ch\u1ECDn t\u1EEB 1 \u0111\u1EBFn 1.000 box h\u1EE3p l\u1EC7.");
    const rows = b.rows.map((r) => ({ id: r.id, expected_revision: r.expected_revision })).sort((a, b2) => a.id - b2.id);
    if (new Set(rows.map((r) => r.id)).size !== rows.length) error("Danh s\xE1ch box b\u1ECB tr\xF9ng.");
    if (!b.changes || typeof b.changes !== "object" || Array.isArray(b.changes) || !Object.keys(b.changes).length || Object.keys(b.changes).some((k) => !["item_code", "location"].includes(k))) error("Ch\u1EC9 s\u1EEDa chung ITEM code ho\u1EB7c Location.");
    const changes = {};
    if (Object.hasOwn(b.changes, "item_code")) changes.item_code = code(b.changes.item_code);
    if (Object.hasOwn(b.changes, "location")) changes.location = str(b.changes.location, "Location").toUpperCase();
    const hash = createHash("sha256").update(JSON.stringify({ item, rows, changes, reason })).digest("hex"), old = db.prepare("SELECT * FROM holding_group_edits WHERE request_id=?").get(request);
    if (old) {
      if (old.user_id !== userId || old.request_hash !== hash) error("M\xE3 y\xEAu c\u1EA7u \u0111\xE3 \u0111\u01B0\u1EE3c d\xF9ng cho l\u01B0\u1EE3t s\u1EEDa kh\xE1c.", 409);
      return { ...JSON.parse(old.response), duplicate: true };
    }
    const find = db.prepare("SELECT " + entryColumns + " FROM holding_entries WHERE id=?");
    const entries = rows.map((r) => {
      const entry = find.get(r.id);
      if (!entry || entry.remaining_qty <= 0 || entry.item_code !== item || entry.revision !== r.expected_revision) error("M\u1ED9t box \u0111\xE3 thay \u0111\u1ED5i ho\u1EB7c kh\xF4ng c\xF2n thu\u1ED9c ITEM n\xE0y. T\u1EA3i l\u1EA1i danh s\xE1ch v\xE0 ch\u1ECDn l\u1EA1i.", 409);
      return entry;
    });
    let unchanged = 0;
    const updated = [];
    for (const entry of entries) {
      const after = { ...entry, ...changes };
      if (!holdingChanges(snapshot(entry), snapshot(after))) {
        unchanged++;
        continue;
      }
      const id = createHash("sha256").update("holding-group|" + userId + "|" + request + "|" + entry.id).digest("hex");
      updated.push(editHoldingInside(db, { ...after, entry_id: entry.id, expected_revision: entry.revision, request_id: id, reason }, userId, request));
    }
    const response = { request_id: request, selected: entries.length, updated: updated.length, unchanged, entries: updated };
    db.prepare("INSERT INTO holding_group_edits(request_id,user_id,request_hash,item_code,changes,reason,response) VALUES (?,?,?,?,?,?,?)").run(request, userId, hash, item, JSON.stringify(changes), reason, JSON.stringify(response));
    return response;
  });
}
function filter(query = {}) {
  const q = typeof query.q === "string" ? query.q.trim().slice(0, 200) : "", source = query.source || "", item = query.item ? code(query.item) : "";
  if (source && !["PBA32", "PMD32", "Nh\u1EADp tay"].includes(source)) error("Ngu\u1ED3n kh\xF4ng h\u1EE3p l\u1EC7.");
  return { sql: `(?='' OR instr(lower(e.barcode||' '||e.item_code||' '||e.item_name||' '||e.location||' '||e.vendor),lower(?))>0) AND (?='' OR e.source=?) AND (?='' OR e.item_code=?)`, params: [q, q, source, source, item, item], q, source };
}
function holdingInventory(db, query = {}, all = false) {
  const f = filter(query), offset = Number(query.offset || 0);
  if (!Number.isSafeInteger(offset) || offset < 0) error("Trang kh\xF4ng h\u1EE3p l\u1EC7.");
  const base = `FROM holding_entries e WHERE e.remaining_qty>0 AND ${f.sql}`;
  const totals = db.prepare(`SELECT COUNT(*) boxes,COUNT(DISTINCT e.item_code) items,COALESCE(SUM(e.remaining_qty),0) qty ${base}`).get(...f.params);
  const entries = db.prepare(`SELECT e.id,e.barcode,e.item_code,e.item_name,e.location,e.initial_qty,e.remaining_qty,e.vendor,e.lot_no,e.source,e.created_at,e.revision,u.name scanner,CASE WHEN e.image IS NULL THEN 0 ELSE 1 END has_image FROM holding_entries e JOIN users u ON u.id=e.user_id WHERE e.remaining_qty>0 AND ${f.sql} ORDER BY e.id DESC ${all ? "" : "LIMIT 100 OFFSET ?"}`).all(...f.params, ...all ? [] : [offset]);
  const items = db.prepare(`SELECT e.item_code,MAX(e.item_name) item_name,SUM(e.remaining_qty) qty,COUNT(*) boxes,GROUP_CONCAT(DISTINCT e.location) locations ${base} GROUP BY e.item_code ORDER BY e.item_code`).all(...f.params);
  const sources = db.prepare(`SELECT e.source,COUNT(*) boxes,SUM(e.remaining_qty) qty ${base} GROUP BY e.source`).all(...f.params);
  return { entries, items, sources, totals, next: !all && offset + entries.length < totals.boxes ? offset + entries.length : null, offset };
}
function holdingEvents(db, query = {}, all = false) {
  const f = filter(query), before = Number(query.before || Number.MAX_SAFE_INTEGER);
  if (!Number.isSafeInteger(before) || before < 1) error("M\u1ED1c nh\u1EADt k\xFD kh\xF4ng h\u1EE3p l\u1EC7.");
  const fields = ["barcode", "item_code", "item_name", "location", "vendor", "source"].map((k) => `COALESCE(json_extract(h.snapshot,'$.${k}'),b.${k}) ${k}`).join(",");
  const rows = db.prepare(`SELECT e.* FROM (SELECT h.id,h.entry_id,h.direction,h.qty,h.balance,h.reason,h.created_at,h.snapshot,h.before_snapshot,u.name scanner,${fields} FROM holding_events h JOIN holding_entries b ON b.id=h.entry_id JOIN users u ON u.id=h.user_id) e WHERE e.id<? AND ${f.sql} ORDER BY e.id DESC ${all ? "" : "LIMIT 100"}`).all(before, ...f.params);
  return rows.map(({ snapshot: after, before_snapshot: before2, ...row }) => ({ ...row, before: before2 ? JSON.parse(before2) : null, after: after ? JSON.parse(after) : null, changes: holdingChanges(before2 ? JSON.parse(before2) : null, after ? JSON.parse(after) : null) }));
}
function holdingReport(db, query, user) {
  const data = holdingInventory(db, query, true), events = holdingEvents(db, query, true), images = [];
  const photo = db.prepare("SELECT image_type,image,LENGTH(image) bytes FROM holding_entries WHERE id=?");
  let imageBytes = 0;
  data.entries.forEach((r, i2) => {
    if (!r.has_image) return;
    const image = photo.get(r.id);
    if (!(image == null ? void 0 : image.image)) return;
    imageBytes += image.bytes;
    if (imageBytes > 96 * 1024 * 1024) error("\u1EA2nh b\xE1o c\xE1o qu\xE1 l\u1EDBn. L\u1ECDc theo Location ho\u1EB7c ngu\u1ED3n \u0111\u1EC3 gi\u1EA3m d\u1EEF li\u1EC7u.", 413);
    images.push({ row: i2 + 8, col: 12, data: image.image, mime: image.image_type, alt: "Nh\u1EADp Holding #" + r.id });
  });
  const sheets = [
    { name: "T\u1ED5ng quan", title: "T\u1ED4NG QUAN T\u1EE6 HOLDING", rows: [["Ch\u1EC9 ti\xEAu", "Gi\xE1 tr\u1ECB"], ["T\u1ED5ng ITEM", data.totals.items], ["T\u1ED5ng box c\xF2n h\xE0ng", data.totals.boxes], ["T\u1ED5ng QTY c\xF2n l\u1EA1i", data.totals.qty], ...data.sources.flatMap((r) => [[r.source + " \xB7 Box", r.boxes], [r.source + " \xB7 QTY", r.qty]])] },
    { name: "Theo ITEM", title: "T\u1ED2N HOLDING THEO ITEM", rows: [["STT", "ITEM code", "T\xEAn h\xE0ng", "Total QTY", "Count box", "Location"], ...data.items.map((r, i2) => [i2 + 1, r.item_code, r.item_name, r.qty, r.boxes, r.locations])] },
    { name: "Theo Barcode", title: "T\u1ED2N HOLDING THEO BARCODE", images, rows: [["STT", "Barcode-no", "ITEM code", "T\xEAn h\xE0ng", "Location", "QTY nh\u1EADp", "QTY c\xF2n l\u1EA1i", "Vendor", "Lot No", "Ngu\u1ED3n", "Ng\u01B0\u1EDDi nh\u1EADp", "Th\u1EDDi gian UTC", "\u1EA2nh \u0111\u1ED1i chi\u1EBFu"], ...data.entries.map((r, i2) => [i2 + 1, r.barcode, r.item_code, r.item_name, r.location, r.initial_qty, r.remaining_qty, r.vendor, r.lot_no, r.source, r.scanner, r.created_at, r.has_image ? "\u1EA2nh box #" + r.id : "Ch\u01B0a c\xF3 \u1EA3nh"])] },
    { name: "Nh\u1EADt k\xFD", title: "NH\u1EACT K\xDD NH\u1EACP / XU\u1EA4T / S\u1EECA HOLDING", rows: [["STT", "Barcode-no", "ITEM code", "Thao t\xE1c", "QTY thay \u0111\u1ED5i", "QTY c\xF2n sau giao d\u1ECBch", "Location", "Ngu\u1ED3n", "Ng\u01B0\u1EDDi thao t\xE1c", "Th\u1EDDi gian", "L\xFD do", "N\u1ED9i dung s\u1EEDa"], ...events.map((r, i2) => [i2 + 1, r.barcode, r.item_code, r.direction === "in" ? "Nh\u1EADp" : r.direction === "out" ? "Xu\u1EA5t" : "\u0110i\u1EC1u ch\u1EC9nh", r.direction === "out" ? -r.qty : r.qty, r.balance, r.location, r.source, r.scanner, r.created_at, r.reason, r.direction === "edit" ? r.changes : ""])] }
  ];
  return reportWorkbook(sheets, { title: "B\xC1O C\xC1O T\u1EE6 HOLDING", scope: [query.q ? "T\xECm: " + query.q : "To\xE0n b\u1ED9", query.source || "T\u1EA5t c\u1EA3 ngu\u1ED3n"].join(" \xB7 "), exportedBy: user.name });
}
function deleteHolding(db, b, userId) {
  return transaction(db, () => {
    const request = rid(b.request_id), reason = str(b.reason, "L\xFD do x\xF3a", true, 500);
    if (!Array.isArray(b.rows) || !b.rows.length || b.rows.length > 1e4 || b.rows.some((r) => !Number.isSafeInteger(r.id) || r.id < 1 || !Number.isSafeInteger(r.expected_revision))) error("Ch\u1ECDn 1\u201310.000 box h\u1EE3p l\u1EC7.");
    if (new Set(b.rows.map((r) => r.id)).size !== b.rows.length) error("Box b\u1ECB tr\xF9ng.");
    const results = b.rows.map((r) => editHoldingInside(db, { ...db.prepare("SELECT * FROM holding_entries WHERE id=?").get(r.id), entry_id: r.id, expected_revision: r.expected_revision, remaining_qty: 0, reason: "X\xF3a kh\u1ECFi t\u1EE7: " + reason, request_id: createHash("sha256").update(request + ":delete:" + r.id).digest("hex") }, userId));
    return { removed: results.length };
  });
}

// lib/cutting-data.mjs
init_polyfills();
var normalize2 = (v) => String(v ?? "").trim().toUpperCase();
function cuttingStatus(db) {
  const batch = db.prepare("SELECT id,name,row_count,sheets,created_at FROM cutting_batches ORDER BY id DESC LIMIT 1").get();
  if (!batch) return { batch: null, models: [] };
  batch.sheets = JSON.parse(batch.sheets);
  return { batch, models: db.prepare("SELECT DISTINCT model_code,model_name FROM cutting_pairs WHERE batch_id=? AND model_code<>'' ORDER BY model_code LIMIT 500").all(batch.id) };
}
function lookupCutting(db, { code: code2, model = "", direction = "auto" }) {
  code2 = normalize2(code2);
  model = normalize2(model);
  if (!code2 || code2.length > 200) throw Error("Nh\u1EADp ho\u1EB7c qu\xE9t m\xE3 AI / MI t\u1EEB 1 \u0111\u1EBFn 200 k\xFD t\u1EF1.");
  if (model.length > 200) throw Error("Model qu\xE1 d\xE0i.");
  if (!["auto", "AI_TO_MI", "MI_TO_AI"].includes(direction)) throw Error("Chi\u1EC1u quy \u0111\u1ED5i kh\xF4ng h\u1EE3p l\u1EC7.");
  const batch = db.prepare("SELECT id,name,created_at FROM cutting_batches ORDER BY id DESC LIMIT 1").get();
  if (!batch) return { code: code2, model, direction, batch: null, matches: [], count: 0 };
  const filter2 = direction === "auto" ? "(mi_code=? OR ai_code=?)" : direction === "MI_TO_AI" ? "mi_code=?" : "ai_code=?";
  const params = direction === "auto" ? [code2, code2] : [code2];
  const where = `batch_id=? AND ${filter2} AND (?='' OR model_code=?)`;
  const count = db.prepare(`SELECT COUNT(*) n FROM cutting_pairs WHERE ${where}`).get(batch.id, ...params, model, model).n;
  const rows = db.prepare(`SELECT * FROM cutting_pairs WHERE ${where} ORDER BY model_code,variant,id LIMIT 200`).all(batch.id, ...params, model, model);
  const matches = rows.flatMap((row) => {
    const directions = direction !== "auto" ? [direction] : [...row.mi_code === code2 ? ["MI_TO_AI"] : [], ...row.ai_code === code2 ? ["AI_TO_MI"] : []];
    return directions.map((d) => ({ ...row, direction: d, source_code: code2, target_code: d === "MI_TO_AI" ? row.ai_code : row.mi_code }));
  });
  return { code: code2, model, direction, batch, matches, count, truncated: count > rows.length, ambiguous_direction: new Set(matches.map((m) => m.direction)).size > 1, multiple_targets: new Set(matches.map((m) => m.target_code)).size > 1 };
}
function saveCuttingScan(db, { request_id, user_id, code: code2, model, direction, image }) {
  return transaction(db, () => {
    const previous = db.prepare("SELECT id,user_id,snapshot FROM cutting_scans WHERE request_id=?").get(request_id);
    if (previous) {
      if (previous.user_id !== user_id) throw Error("M\xE3 y\xEAu c\u1EA7u \u0111\xE3 thu\u1ED9c t\xE0i kho\u1EA3n kh\xE1c.");
      return { id: previous.id, duplicate: true, ...JSON.parse(previous.snapshot) };
    }
    const result = lookupCutting(db, { code: code2, model, direction });
    if (!result.batch) throw Error("Ch\u01B0a c\xF3 b\u1EA3ng quy \u0111\u1ED5i. Qu\u1EA3n tr\u1ECB vi\xEAn c\u1EA7n nh\u1EADp file Excel.");
    const id = Number(db.prepare("INSERT INTO cutting_scans(request_id,user_id,code,snapshot,image_type,image) VALUES (?,?,?,?,?,?)").run(request_id, user_id, result.code, JSON.stringify(result), image.mime, image.buffer).lastInsertRowid);
    return { id, ...result };
  });
}

// lib/mm-data.mjs
init_polyfills();

// lib/mm-code-registry.mjs
init_polyfills();
var normalize3 = (v) => String(v ?? "").trim().toUpperCase();
var join = (values) => [...new Set(values.map((v) => String(v ?? "").trim()).filter(Boolean))].sort().join(" / ");
function currentCodeRows(db) {
  return db.prepare(`SELECT item_code,item_name,spec,vendor FROM mm_inventory UNION ALL SELECT m.item_code,m.item item_name,m.description spec,m.vendor FROM materials m WHERE NOT EXISTS(SELECT 1 FROM mm_inventory i WHERE upper(trim(i.item_code))=upper(trim(m.item_code)))`).all();
}
function rememberCodes(db, rows, source = "", onlyNew = false) {
  const groups = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const key = normalize3(r.item_code);
    if (!key) continue;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  const find = db.prepare("SELECT * FROM mm_code_registry WHERE item_code=?"), insert = db.prepare("INSERT INTO mm_code_registry(item_code,item_name,spec,vendor) VALUES(?,?,?,?)"), update = db.prepare("UPDATE mm_code_registry SET item_name=?,spec=?,vendor=?,previous_spec=?,spec_changed=?,updated_at=CURRENT_TIMESTAMP WHERE item_code=?"), history = db.prepare("INSERT INTO mm_code_spec_history(item_code,old_spec,new_spec,source) VALUES(?,?,?,?)");
  for (const [key, group] of groups) {
    const name = join(group.map((r) => r.item_name)), spec = join(group.map((r) => r.spec)), vendor = join(group.map((r) => r.vendor)), old = find.get(key);
    if (!old) {
      insert.run(key, name, spec, vendor);
      continue;
    }
    if (onlyNew) continue;
    const changed = old.spec.replace(/\s+/g, " ").trim() !== spec.replace(/\s+/g, " ").trim();
    if (changed) history.run(key, old.spec, spec, source);
    update.run(name, spec, vendor, changed ? old.spec : old.previous_spec, changed ? 1 : old.spec_changed, key);
  }
}

// lib/mm-data.mjs
function listMM(db, { q = "", field = "all", offset = 0 }) {
  const source = `(
    SELECT i.item_code,i.barcode AS samsung,i.item_name AS item,i.spec AS description,i.maker,i.vendor,i.location,m.selling_qty,m.moq,i.qty,i.lot_no,i.storage_location,i.receipt_date,i.vendor_code,i.customer_label,i.label_status,i.source_sheet,i.source_row
    FROM mm_inventory i LEFT JOIN materials m ON m.item_code=i.item_code
    UNION ALL
    SELECT m.item_code,m.samsung,m.item,m.description,m.maker,m.vendor,m.location,m.selling_qty,m.moq,st.qty,st.lot_no,'','','','','','',NULL
    FROM materials m LEFT JOIN material_stock st ON st.item_code=m.item_code WHERE NOT EXISTS(SELECT 1 FROM mm_inventory i WHERE i.item_code=m.item_code)
  )`;
  const fields = { all: "item_code || samsung || item || description || maker || location || vendor", location: "location", item_code: "item_code", spec: "description" };
  if (!Object.hasOwn(fields, field)) throw Error("Ch\u1ECDn Location, Item code ho\u1EB7c Spec.");
  const where = `instr(lower(${fields[field]}),lower(?))>0`, order = field === "location" ? "location,item_code,samsung" : field === "spec" ? "description,item_code,samsung" : "item_code,samsung";
  if (field === "spec") {
    const grouped = `(SELECT item_code,MIN(samsung) samsung,MIN(item) item,MIN(description) description,GROUP_CONCAT(DISTINCT maker) maker,GROUP_CONCAT(DISTINCT vendor) vendor,GROUP_CONCAT(DISTINCT NULLIF(location,'')) location,MAX(selling_qty) selling_qty,MAX(moq) moq,SUM(qty) qty,GROUP_CONCAT(DISTINCT NULLIF(lot_no,'')) lot_no,COUNT(*) box_count,'' source_sheet,NULL source_row FROM ${source} WHERE ${where} GROUP BY upper(trim(item_code)))`;
    const matched2 = db.prepare(`SELECT COUNT(*) n FROM ${grouped}`).get(q).n;
    return { materials: db.prepare(`SELECT * FROM ${grouped} ORDER BY description,item_code LIMIT 200 OFFSET ?`).all(q, offset), total: db.prepare(`SELECT COUNT(*) n FROM ${source}`).get().n, total_items: db.prepare(`SELECT COUNT(DISTINCT upper(trim(item_code))) n FROM ${source}`).get().n, matched: matched2, field, next: offset + 200 < matched2 ? offset + 200 : null };
  }
  const matched = db.prepare(`SELECT COUNT(*) n FROM ${source} WHERE ${where}`).get(q).n;
  return { materials: db.prepare(`SELECT * FROM ${source} WHERE ${where} ORDER BY ${order} LIMIT 200 OFFSET ?`).all(q, offset), total: db.prepare(`SELECT COUNT(*) n FROM ${source}`).get().n, matched, field, next: offset + 200 < matched ? offset + 200 : null };
}
function lookupAndSaveMM(db, options, userId) {
  return transaction(db, () => {
    const result = listMM(db, options), q = options.q.trim();
    if (!q || !result.materials.length) return result;
    let rows = result.materials, previous = null;
    if (options.offset && options.saved_id) {
      previous = db.prepare("SELECT id,snapshot FROM mm_lookup_saved WHERE id=? AND user_id=? AND field=? AND query=?").get(options.saved_id, userId, options.field, q);
      if (previous) {
        const seen = /* @__PURE__ */ new Map();
        for (const row2 of [...JSON.parse(previous.snapshot).materials, ...rows]) seen.set(options.field === "spec" ? row2.item_code.toUpperCase().trim() : row2.item_code + "|" + row2.samsung, row2);
        rows = [...seen.values()];
      }
    }
    const saved = { ...result, materials: rows.slice(0, 1e3), next: null };
    if (previous) {
      db.prepare("UPDATE mm_lookup_saved SET snapshot=? WHERE id=? AND user_id=?").run(JSON.stringify(saved), previous.id, userId);
      return { ...result, saved_id: previous.id };
    }
    const last = db.prepare("SELECT id,snapshot FROM mm_lookup_saved WHERE user_id=? AND field=? AND query=? ORDER BY id DESC LIMIT 1").get(userId, options.field, q);
    if (last && last.snapshot === JSON.stringify(saved)) return { ...result, saved_id: last.id };
    const row = db.prepare("INSERT INTO mm_lookup_saved(user_id,field,query,snapshot) VALUES (?,?,?,?) RETURNING id").get(userId, options.field, q, JSON.stringify(saved));
    return { ...result, saved_id: row.id };
  });
}
function listMMCodes(db, { q = "", offset = 0 } = {}) {
  if (typeof q !== "string" || q.length > 200 || !Number.isSafeInteger(offset) || offset < 0) throw Error("Invalid code directory search");
  rememberCodes(db, currentCodeRows(db), "Existing MM", true);
  const grouped = "mm_code_registry";
  const where = "instr(lower(item_code||' '||COALESCE(item_name,'')||' '||COALESCE(spec,'')||' '||COALESCE(vendor,'')),lower(?))>0";
  const total = db.prepare(`SELECT COUNT(*) n FROM ${grouped}`).get().n, matched = db.prepare(`SELECT COUNT(*) n FROM ${grouped} WHERE ${where}`).get(q).n;
  return { rows: db.prepare(`SELECT * FROM ${grouped} WHERE ${where} ORDER BY item_code LIMIT 200 OFFSET ?`).all(q, offset), total, matched, next: offset + 200 < matched ? offset + 200 : null };
}

// lib/stock-data.mjs
init_polyfills();

// lib/scan-quantity.mjs
init_polyfills();
function scanQuantity(barcode, mode) {
  if (mode !== "Stock") return null;
  if ([...String(barcode).matchAll(/(?:^|[\s;|,])(?:QTY|QUANTITY)\s*[:=]/gi)].length !== 1) return null;
  const values = [...String(barcode).matchAll(/(?:^|[\s;|,])(?:QTY|QUANTITY)\s*[:=]\s*([0-9]+)(?=$|[\s;|]|,(?!\d))/gi)].map((m) => Number(m[1]));
  if (values.length !== 1 || !Number.isSafeInteger(values[0]) || values[0] < 1 || values[0] > 1e9) return null;
  return values[0];
}

// lib/stock-data.mjs
function stockField(barcode, names2) {
  const fields = [...String(barcode).matchAll(/(?:^|[;|\n])\s*([A-Z_ ]+)\s*[:=]\s*([^;|\n]+)(?=$|[;|\n])/gi)].filter((m) => names2.includes(m[1].trim().replace(/\s+/g, "_").toUpperCase()));
  return fields.length === 1 ? fields[0][2].trim().toUpperCase() : null;
}
function stockData(db, barcode) {
  const inventory = db.prepare("SELECT * FROM mm_inventory WHERE barcode=?").get(barcode);
  if (inventory) return { item_code: inventory.item_code, item_name: inventory.item_name, maker: inventory.maker, vendor: inventory.vendor, quantity: inventory.qty, quantity_source: "MM", lot_no: inventory.lot_no || null };
  const lookup = (code2) => db.prepare("SELECT m.*,st.qty AS stock_qty,st.lot_no FROM materials m LEFT JOIN material_stock st ON st.item_code=m.item_code WHERE m.samsung=? OR m.item_code=? ORDER BY CASE WHEN m.samsung=? THEN 0 ELSE 1 END LIMIT 1").get(code2, code2, code2);
  const m = lookup(barcode) || lookup(stockField(barcode, ["ITEM", "ITEM_CODE", "SAMSUNG", "BARCODE"]) || barcode);
  const fromCode = scanQuantity(barcode, "Stock");
  return { item_code: (m == null ? void 0 : m.item_code) ?? null, item_name: (m == null ? void 0 : m.item) ?? null, maker: (m == null ? void 0 : m.maker) ?? null, vendor: (m == null ? void 0 : m.vendor) ?? null, quantity: fromCode ?? (m == null ? void 0 : m.stock_qty) ?? null, quantity_source: fromCode !== null ? "barcode" : (m == null ? void 0 : m.stock_qty) != null ? "MM" : null, lot_no: stockField(barcode, ["LOT", "LOT_NO"]) || (m == null ? void 0 : m.lot_no) || null };
}

// lib/scan-report.mjs
init_polyfills();
var sum = (rows) => Number(rows.reduce((s, r) => s + (r.quantity ?? 0), 0).toFixed(9));
function scanReport(db, data, mode, user) {
  var _a2;
  const title = mode === "HS" ? "B\xC1O C\xC1O QU\xC9T HS" : mode === "Stock" ? "B\xC1O C\xC1O KI\u1EC2M K\xCA STOCK" : mode === "Label" ? "B\xC1O C\xC1O THU TH\u1EACP LABEL" : "B\xC1O C\xC1O QU\xC9T M\xC3";
  const scope = mode || "T\u1EA5t c\u1EA3 lo\u1EA1i qu\xE9t", stock = data.filter((r) => r.mode === "Stock"), images = [], imageColumn = mode === "HS" ? 7 : 11;
  const maxId = ((_a2 = data[0]) == null ? void 0 : _a2.id) || 0, bytes = db.prepare("SELECT COALESCE(SUM(LENGTH(image)),0) bytes FROM scans WHERE id<=? AND (? IS NULL OR mode=?)").get(maxId, mode, mode).bytes;
  if (bytes > 96 * 1024 * 1024) {
    const error2 = new Error("\u1EA2nh b\xE1o c\xE1o qu\xE1 l\u1EDBn. Ch\u1ECDn t\u1EEBng lo\u1EA1i HS / Stock / Label \u0111\u1EC3 xu\u1EA5t.");
    error2.status = 413;
    throw error2;
  }
  const photo = db.prepare("SELECT image_type,image FROM scans WHERE id=?");
  data.forEach((r, i2) => {
    if (r.has_image) {
      const image = photo.get(r.id);
      if (image == null ? void 0 : image.image) images.push({ row: i2 + 8, col: imageColumn, mime: image.image_type, data: image.image, alt: "L\u01B0\u1EE3t qu\xE9t #" + r.id });
    }
  });
  const overview = [["Ch\u1EC9 ti\xEAu", "Gi\xE1 tr\u1ECB"], ["Lo\u1EA1i b\xE1o c\xE1o", scope], ["T\u1ED5ng l\u01B0\u1EE3t qu\xE9t", data.length], ["S\u1ED1 barcode kh\xE1c nhau", new Set(data.map((r) => r.barcode)).size], ["S\u1ED1 ITEM \u0111\xE3 nh\u1EADn di\u1EC7n", new Set(data.map((r) => r.item_code).filter(Boolean)).size], ["L\u01B0\u1EE3t c\xF3 \u1EA3nh \u0111\u1ED1i chi\u1EBFu", images.length], ["L\u01B0\u1EE3t HS tr\xF9ng", data.filter((r) => r.mode === "HS" && r.prior_count > 0).length], ["L\u01B0\u1EE3t HS kh\xF4ng tr\xF9ng", data.filter((r) => r.mode === "HS" && !r.prior_count).length]];
  if (mode === "Stock" || stock.length) overview.push(["Total QTY Stock", stock.some((r) => r.quantity != null) ? sum(stock) : "Ch\u01B0a c\xF3 QTY"], ["L\u01B0\u1EE3t Stock c\xF3 QTY", stock.filter((r) => r.quantity != null).length], ["L\u01B0\u1EE3t Stock ch\u01B0a c\xF3 QTY", stock.filter((r) => r.quantity == null).length], ["L\u01B0\u1EE3t Stock ch\u01B0a c\xF3 ITEM", stock.filter((r) => !r.item_code).length]);
  if (!mode) for (const type of ["HS", "Stock", "Label"]) overview.push(["L\u01B0\u1EE3t " + type, data.filter((r) => r.mode === type).length]);
  overview.push(["Ghi ch\xFA", mode === "HS" ? "M\u1ED7i d\xF2ng l\xE0 m\u1ED9t l\u01B0\u1EE3t qu\xE9t \u0111\xE3 l\u01B0u. Tr\u1EA1ng th\xE1i tr\xF9ng gi\u1EEF theo th\u1EDDi \u0111i\u1EC3m qu\xE9t." : "M\u1ED7i d\xF2ng l\xE0 m\u1ED9t l\u01B0\u1EE3t qu\xE9t \u0111\xE3 l\u01B0u. QTY tr\u1ED1ng l\xE0 ch\u01B0a x\xE1c \u0111\u1ECBnh, kh\xF4ng ph\u1EA3i 0."]);
  const sheets = [{ name: "T\u1ED5ng quan", title, rows: overview }];
  if (mode === "Stock") {
    const groups = /* @__PURE__ */ new Map();
    for (const r of stock) {
      if (!r.item_code) continue;
      const item = r.item_code.trim().toUpperCase();
      let group = groups.get(item);
      if (!group) {
        group = { item_code: item, item_name: r.item_name || "", rows: [] };
        groups.set(item, group);
      }
      group.rows.push(r);
    }
    sheets.push({ name: "Total theo ITEM", title: "T\u1ED4NG QTY STOCK THEO ITEM", rows: [["STT", "ITEM code", "Item NM", "S\u1ED1 l\u01B0\u1EE3t qu\xE9t", "L\u01B0\u1EE3t c\xF3 QTY", "L\u01B0\u1EE3t ch\u01B0a c\xF3 QTY", "Total QTY"], ...[...groups.values()].sort((a, b) => a.item_code.localeCompare(b.item_code)).map((r, i2) => [i2 + 1, r.item_code, r.item_name, r.rows.length, r.rows.filter((r2) => r2.quantity != null).length, r.rows.filter((r2) => r2.quantity == null).length, r.rows.some((r2) => r2.quantity != null) ? sum(r.rows) : ""])] });
  }
  const rows = mode === "HS" ? [["STT", "ITEM", "Barcode", "K\u1EBFt qu\u1EA3", "Ng\u01B0\u1EDDi qu\xE9t", "Th\u1EDDi gian UTC", "Item NM", "\u1EA2nh \u0111\u1ED1i chi\u1EBFu"], ...data.map((r, i2) => [i2 + 1, r.item_code || r.barcode, r.barcode, r.prior_count > 0 ? "Tr\xF9ng" : "Kh\xF4ng tr\xF9ng", r.scanner, r.created_at, r.item_name || "", r.has_image ? "\u1EA2nh l\u01B0\u1EE3t #" + r.id : "Ch\u01B0a c\xF3 \u1EA3nh"])] : [["STT", "Barcode", "Lo\u1EA1i qu\xE9t", "Ng\u01B0\u1EDDi qu\xE9t", "Th\u1EDDi gian UTC", "ITEM code", "Item NM", "S\u1ED1 l\u01B0\u1EE3ng (QTY)", "Maker", "Vendor", "Lot No", "\u1EA2nh \u0111\u1ED1i chi\u1EBFu"], ...data.map((r, i2) => [i2 + 1, r.barcode, r.mode, r.scanner, r.created_at, r.item_code || "Ch\u01B0a c\xF3 trong MM", r.item_name || "", r.quantity ?? "", r.maker || "", r.vendor || "", r.lot_no || "", r.has_image ? "\u1EA2nh l\u01B0\u1EE3t #" + r.id : "Ch\u01B0a c\xF3 \u1EA3nh"])];
  sheets.push({ name: "Chi ti\u1EBFt", title: "CHI TI\u1EBET L\u01AF\u1EE2T QU\xC9T " + scope.toUpperCase(), images, rows });
  return reportWorkbook(sheets, { title, scope, exportedBy: user.name });
}

// lib/ckd-report.mjs
init_polyfills();
var imageName = (i2) => `images/SO-${i2.workbook_id}/check-${i2.check_id}-${i2.slot}.${i2.mime === "image/png" ? "png" : i2.mime === "image/webp" ? "webp" : "jpg"}`;
function ckdReport(db, workbook, options = {}) {
  var _a2, _b2;
  const overview = ckdOverview(db, workbook), maxId = ((_a2 = overview.checks[0]) == null ? void 0 : _a2.id) || 0;
  const filter2 = `c.id<=?${workbook ? " AND c.workbook_id=?" : ""}`, args = workbook ? [maxId, workbook] : [maxId];
  const imageMeta = db.prepare(`SELECT i.check_id,i.slot,i.mime,c.workbook_id,LENGTH(i.image) bytes,LENGTH(COALESCE(i.thumbnail,i.image)) preview_bytes FROM ckd_check_images i JOIN ckd_checks c ON c.id=i.check_id WHERE ${filter2} ORDER BY i.check_id,i.slot`).all(...args);
  if (imageMeta.reduce((sum2, i2) => sum2 + i2.preview_bytes, 0) > 96 * 1024 * 1024) throw Error("\u1EA2nh xem tr\u01B0\u1EDBc qu\xE1 l\u1EDBn. Ch\u1ECDn t\u1EEBng \u0111\u01A1n h\xE0ng \u0111\u1EC3 xu\u1EA5t b\xE1o c\xE1o.");
  const rowById = new Map(overview.checks.map((c, i2) => [c.id, i2 + 8]));
  const embedded = db.prepare(`SELECT i.check_id,i.slot,CASE WHEN i.thumbnail IS NOT NULL THEN 'image/jpeg' ELSE i.mime END mime,COALESCE(i.thumbnail,i.image) data FROM ckd_check_images i JOIN ckd_checks c ON c.id=i.check_id WHERE ${filter2} ORDER BY i.check_id,i.slot`).all(...args).map((i2) => ({ row: rowById.get(i2.check_id), col: i2.slot === "samsung" ? 6 : 7, data: i2.data, mime: i2.mime, alt: `${i2.slot} \xB7 Scan #${i2.check_id}` }));
  const paths = new Map(imageMeta.map((i2) => [i2.check_id + "|" + i2.slot, imageName(i2)]));
  const scope = workbook ? ((_b2 = db.prepare("SELECT name FROM ckd_workbooks WHERE id=?").get(workbook)) == null ? void 0 : _b2.name) || "\u0110\u01A1n h\xE0ng \u0111\u01B0\u1EE3c ch\u1ECDn" : "T\u1EA5t c\u1EA3 \u0111\u01A1n h\xE0ng";
  const pass = overview.checks.filter((c) => c.counted).length, ng = overview.checks.length - pass;
  const imagePath = (id, slot) => {
    const path = paths.get(id + "|" + slot);
    return path ? options.imageLinks ? path : "C\xF3 \u1EA3nh trong g\xF3i ZIP" : "";
  };
  const workbookBytes = reportWorkbook([
    { name: "T\u1ED5ng quan", title: "T\u1ED4NG QUAN KI\u1EC2M TRA CKD", summary: `${overview.checks.length} l\u01B0\u1EE3t ki\u1EC3m tra  |  ${pass} PASS  |  ${ng} NG`, rows: [["Ch\u1EC9 ti\xEAu", "Gi\xE1 tr\u1ECB"], ["Ph\u1EA1m vi", scope], ["S\u1ED1 l\u01B0\u1EE3t ki\u1EC3m tra", overview.checks.length], ["Box PASS \u0111\u01B0\u1EE3c c\u1ED9ng SO", pass], ["L\u01B0\u1EE3t NG (kh\xF4ng c\u1ED9ng SO)", ng], ["S\u1ED1 m\xE3 Samsung \u0111\xE3 scan", overview.summary.length], ["S\u1ED1 m\xE3 SO ch\u01B0a scan", overview.unsold.length], ["S\u1ED1 l\u01B0\u1EE3ng \u0111\xE3 x\xE1c nh\u1EADn", overview.summary.reduce((n, g) => n + g.total, 0)], ["M\xE3 \u0111\xE3 \u0111\u1EE7 s\u1ED1 l\u01B0\u1EE3ng", overview.summary.filter((g) => g.quantity_status === "\u0110\u1EE7").length], ["M\xE3 c\xF2n thi\u1EBFu", overview.summary.filter((g) => g.quantity_status === "Thi\u1EBFu").length], ["M\xE3 d\u01B0 s\u1ED1 l\u01B0\u1EE3ng", overview.summary.filter((g) => g.quantity_status === "D\u01B0").length], ["\u1EA2nh \u0111\u1ED1i chi\u1EBFu", imageMeta.length], ["Ghi ch\xFA", "NG kh\xF4ng c\u1ED9ng s\u1ED1 l\u01B0\u1EE3ng SO. L\u1ECBch s\u1EED gi\u1EEF k\u1EBFt qu\u1EA3 t\u1EA1i th\u1EDDi \u0111i\u1EC3m l\u01B0u."]] },
    { name: "Luot scan", images: embedded, rows: [["STT", "Samsung", "ITEM", "QTY", "B\xE1n \u0111\u1EE7 / d\u01B0 / thi\u1EBFu", "Vendor", "\u1EA2nh Samsung", "\u1EA2nh ITEM", "Ng\u01B0\u1EDDi scan", "Gi\u1EDD scan UTC", "Scan ID", "\u0110\u01A1n h\xE0ng", "Phi\xEAn qu\xE9t", "Description", "Maker b\xE1n (MM)", "SO Maker", "Selling Qty", "T\u1ED5ng sau l\u01B0\u1EE3t", "K\u1EBFt qu\u1EA3", "Maker kh\u1EDBp"], ...overview.checks.map((c, i2) => {
      var _a3, _b3, _c;
      return [i2 + 1, c.samsung, c.item_code, c.qty, c.check.quantity_status || "", c.check.selling_vendor || ((_a3 = c.check.order) == null ? void 0 : _a3.vendor) || "", imagePath(c.id, "samsung"), imagePath(c.id, "item"), c.scanner, c.created_at, c.id, c.workbook_name, c.check.session_name || "", ((_b3 = c.check.model) == null ? void 0 : _b3.description) || "", c.check.selling_maker || "", ((_c = c.check.order) == null ? void 0 : _c.so_maker) || "", c.check.target, c.counted ? c.check.after : c.check.total, c.status, c.check.maker_match === void 0 ? "Ch\u01B0a ghi" : c.check.maker_match ? "Kh\u1EDBp" : "Sai"];
    })] },
    { name: "Theo Samsung", rows: [["STT", "\u0110\u01A1n h\xE0ng", "Samsung", "ITEM b\xE1n", "L\u01B0\u1EE3t scan", "Box PASS", "NG", "Selling Qty", "\u0110\xE3 b\xE1n", "C\xF2n thi\u1EBFu", "Tr\u1EA1ng th\xE1i"], ...overview.summary.map((g, i2) => [i2 + 1, g.workbook_name, g.samsung, g.items.join(" / "), g.scans, g.boxes, g.ng, g.target, g.total, g.remaining, g.quantity_status])] },
    { name: "SO chua scan", rows: [["STT", "\u0110\u01A1n h\xE0ng", "Samsung", "ITEM b\xE1n", "SO Maker", "Selling Qty"], ...overview.unsold.map((g, i2) => [i2 + 1, g.workbook_name, g.samsung, g.items.join(" / "), g.so_makers.join(" / "), g.target])] }
  ], { title: "B\xC1O C\xC1O KI\u1EC2M TRA CKD", scope, exportedBy: options.exportedBy || "", imageLinks: options.imageLinks === true });
  if (imageMeta.length + 2 > 65535 || imageMeta.reduce((sum2, i2) => sum2 + i2.bytes, workbookBytes.length) + imageMeta.length * 200 + 3e3 > 4294967295) throw Error("B\xE1o c\xE1o qu\xE1 l\u1EDBn. Ch\u1ECDn t\u1EEBng \u0111\u01A1n h\xE0ng \u0111\u1EC3 t\u1EA3i.");
  function* entries() {
    yield { name: "report.xlsx", data: workbookBytes };
    yield { name: "README.txt", data: import_buffer.Buffer.from("WORK AREA \xB7 HANSOL / HEVH\r\n\r\n1. Gi\u1EA3i n\xE9n to\xE0n b\u1ED9 g\xF3i ZIP tr\u01B0\u1EDBc khi xem.\r\n2. M\u1EDF report.xlsx, b\u1EAFt \u0111\u1EA7u t\u1EEB sheet T\u1ED5ng quan.\r\n3. B\u1EA5m M\u1EDF \u1EA3nh trong sheet L\u01B0\u1EE3t scan \u0111\u1EC3 xem \u1EA3nh \u0111\u1ED1i chi\u1EBFu.\r\n4. Gi\u1EEF th\u01B0 m\u1EE5c images c\u1EA1nh report.xlsx \u0111\u1EC3 c\xE1c li\xEAn k\u1EBFt ho\u1EA1t \u0111\u1ED9ng.\r\n\r\n\u1EA2nh v\xE0 k\u1EBFt qu\u1EA3 l\xE0 d\u1EEF li\u1EC7u c\u1EE7a c\xE1c l\u01B0\u1EE3t \u0111\xE3 l\u01B0u. NG kh\xF4ng c\u1ED9ng s\u1ED1 l\u01B0\u1EE3ng SO.\r\n", "utf8") };
    for (const image of db.prepare(`SELECT i.check_id,i.slot,i.mime,i.image,c.workbook_id FROM ckd_check_images i JOIN ckd_checks c ON c.id=i.check_id WHERE ${filter2} ORDER BY i.check_id,i.slot`).iterate(...args)) yield { name: imageName(image), data: image.image };
  }
  return { workbookBytes, entries, images: imageMeta.length };
}

// lib/offline-business.mjs
var queuePaths = /* @__PURE__ */ new Set(["/scans", "/scans/delete", "/ckd/pair/save", "/ckd/history/delete", "/cutting/scans", "/holding/v2/receive", "/holding/v2/withdraw", "/holding/v2/edit", "/holding/v2/edit-group", "/holding/v2/delete", "/holding/v2/preferences", "/preferences", "/materials/lookup"]);
var fail = (message2, status = 400) => {
  throw Object.assign(Error(message2), { status });
};
var text = (value, label, max = 500) => {
  if (typeof value !== "string" || !value.trim() || value.trim().length > max) fail(label + " kh\xF4ng h\u1EE3p l\u1EC7.");
  return value.trim();
};
var requestId = (value) => {
  if (typeof value !== "string" || !/^[a-zA-Z0-9-]{16,80}$/.test(value)) fail("M\xE3 giao d\u1ECBch kh\xF4ng h\u1EE3p l\u1EC7.");
  return value;
};
function offlineImage(source) {
  if (!source) return { mime: null, buffer: null };
  const m = typeof source === "string" && /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(source);
  if (!m) fail("\u1EA2nh kh\xF4ng h\u1EE3p l\u1EC7.");
  const buffer = import_buffer.Buffer.from(m[2], "base64"), mime = m[1];
  const valid = mime === "image/jpeg" ? buffer.subarray(0, 3).equals(import_buffer.Buffer.from([255, 216, 255])) : mime === "image/png" ? buffer.subarray(0, 8).equals(import_buffer.Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) : buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP";
  if (!valid || buffer.length > 3 * 1024 * 1024) fail("\u1EA2nh sai \u0111\u1ECBnh d\u1EA1ng ho\u1EB7c v\u01B0\u1EE3t 3 MB.");
  return { mime, buffer };
}
var scanSelect = `SELECT s.id,s.barcode,s.raw_barcode,s.mode,s.quantity,s.prior_count,s.created_at,u.name scanner,COALESCE(ss.item_code,m.item_code) item_code,COALESCE(ss.item_name,m.item) item_name,COALESCE(ss.maker,m.maker) maker,COALESCE(ss.vendor,m.vendor) vendor,ss.lot_no,ss.quantity_source,s.image IS NOT NULL has_image FROM scans s JOIN users u ON u.id=s.user_id LEFT JOIN scan_stock ss ON ss.scan_id=s.id LEFT JOIN materials m ON m.item_code=COALESCE((SELECT item_code FROM materials WHERE samsung=s.barcode),s.barcode)`;
var binary = (bytes, mime, name) => ({ binary: true, bytes, mime, name });
function businessApi(db, user, path, { method = "GET", data: b = {} } = {}, historical = false) {
  var _a2, _b2, _c, _d;
  const url = new URL(path, "https://workarea.invalid"), p = url.pathname, q = Object.fromEntries(url.searchParams), write = () => {
    if (!["admin", "inspector"].includes(user.role)) fail("T\xE0i kho\u1EA3n ch\u1EC9 \u0111\u01B0\u1EE3c xem.", 403);
  }, admin = () => {
    if (user.role !== "admin") fail("Ch\u1EC9 qu\u1EA3n tr\u1ECB vi\xEAn \u0111\u01B0\u1EE3c th\u1EF1c hi\u1EC7n.", 403);
  };
  if (method === "POST" && !queuePaths.has(p) && p !== "/ckd/pair/check") fail("Thao t\xE1c n\xE0y c\u1EA7n k\u1EBFt n\u1ED1i m\xE1y ch\u1EE7.", 503);
  if (p === "/health") return { ok: true, app: "work-area", offline: true };
  if (p === "/me") return { user, csrf: "device-workspace", needsSetup: false };
  if (p === "/users" && method === "GET") {
    admin();
    return { users: [user] };
  }
  if (p === "/preferences") {
    if (method === "POST") {
      const old = db.prepare("SELECT * FROM user_preferences WHERE user_id=?").get(user.id), navigation = b.navigation ?? (old ? JSON.parse(old.navigation) : ["home", "scan", "assistant", "account"]), continuous = b.continuous_scan ?? (old ? Boolean(old.continuous_scan) : true);
      if (!Array.isArray(navigation) || navigation.length < 3 || navigation.length > 5 || new Set(navigation).size !== navigation.length || navigation.some((v) => !["home", "scan", "ckd", "cut", "holding", "mm", "heatsink", "assistant", "account"].includes(v)) || typeof continuous !== "boolean") fail("Ph\xEDm t\u1EAFt kh\xF4ng h\u1EE3p l\u1EC7.");
      db.prepare("INSERT INTO user_preferences(user_id,navigation,continuous_scan) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET navigation=excluded.navigation,continuous_scan=excluded.continuous_scan").run(user.id, JSON.stringify(navigation), continuous ? 1 : 0);
    }
    const r = db.prepare("SELECT * FROM user_preferences WHERE user_id=?").get(user.id);
    return { navigation: r ? JSON.parse(r.navigation) : ["home", "scan", "assistant", "account"], continuous_scan: r ? !!r.continuous_scan : true, updated_at: (r == null ? void 0 : r.updated_at) || null };
  }
  if (p === "/stats") return { scans: db.prepare("SELECT COUNT(*) n FROM scans").get().n, materials: db.prepare("SELECT COUNT(*) n FROM (SELECT item_code FROM materials UNION SELECT item_code FROM mm_inventory)").get().n, boxes: db.prepare("SELECT COUNT(*) n FROM boxes").get().n, holding: db.prepare("SELECT COALESCE(SUM(remaining_qty),0) n FROM holding_entries").get().n };
  if (p === "/materials/codes" && method === "GET") return listMMCodes(db, { q: q.q || "", offset: Number(q.offset || 0) });
  if (p === "/materials" || p === "/materials/lookup") {
    const v = method === "POST" ? b : q, field = v.field || "all", query = typeof v.q === "string" ? v.q.slice(0, 200) : "", offset = Number(v.offset || 0);
    if (!Number.isSafeInteger(offset) || offset < 0 || offset > 1e6) fail("Trang kh\xF4ng h\u1EE3p l\u1EC7.");
    if (method === "POST" && historical && b._offline_saved) {
      const saved = b._offline_saved;
      if (!["spec", "location", "item_code"].includes(field) || !query.trim() || !saved || !Array.isArray(saved.materials) || saved.materials.length > 1e3 || JSON.stringify(saved).length > 2 * 1024 * 1024 || saved.materials.some((r) => !r || typeof r.item_code !== "string")) fail("B\u1EA3n tra c\u1EE9u offline kh\xF4ng h\u1EE3p l\u1EC7.");
      const id = db.prepare("INSERT INTO mm_lookup_saved(user_id,field,query,snapshot) VALUES (?,?,?,?)").run(user.id, field, query, JSON.stringify(saved)).lastInsertRowid;
      return { ...saved, saved_id: Number(id) };
    }
    return method === "POST" ? lookupAndSaveMM(db, { q: query, field, offset, saved_id: v.saved_id }, user.id) : listMM(db, { q: query, field, offset });
  }
  if (p === "/materials/saved") {
    if (q.id) {
      const r = db.prepare("SELECT * FROM mm_lookup_saved WHERE id=? AND user_id=?").get(Number(q.id), user.id);
      if (!r) fail("Kh\xF4ng t\xECm th\u1EA5y tra c\u1EE9u \u0111\xE3 l\u01B0u.", 404);
      return { ...JSON.parse(r.snapshot), saved_at: r.updated_at, query: r.query };
    }
    return { saved: db.prepare("SELECT id,field,query,updated_at FROM mm_lookup_saved WHERE user_id=? AND field=? AND instr(lower(query),lower(?))>0 ORDER BY updated_at DESC,id DESC LIMIT 100").all(user.id, q.field || "spec", q.q || "") };
  }
  if (p === "/scans/check") return { count: db.prepare("SELECT COUNT(*) n FROM scans WHERE barcode=? AND mode=?").get(["HS", "Label"].includes(q.mode) ? hsCode(q.barcode) : q.barcode, q.mode).n, scope: "device", offline: true };
  if (p === "/scans" && method === "POST") {
    write();
    const id = requestId(b.request_id);
    if (!["HS", "Stock", "Label"].includes(b.mode)) fail("Lo\u1EA1i scan kh\xF4ng h\u1EE3p l\u1EC7.");
    const old = db.prepare("SELECT * FROM scans WHERE request_id=?").get(id);
    if (old) {
      if (old.user_id !== user.id) fail("M\xE3 giao d\u1ECBch thu\u1ED9c t\xE0i kho\u1EA3n kh\xE1c.", 409);
      return { id: old.id, duplicate: true, is_duplicate: old.prior_count > 0, prior_count: old.prior_count, barcode_count: old.prior_count + 1 };
    }
    const raw = text(["HS", "Label"].includes(b.mode) ? b.raw_barcode ?? b.barcode : b.barcode, "Barcode").toUpperCase(), barcode = ["HS", "Label"].includes(b.mode) ? hsCode(raw) : raw, image = offlineImage(b.image), prior2 = db.prepare("SELECT COUNT(*) n FROM scans WHERE barcode=? AND mode=?").get(barcode, b.mode).n;
    if (b.mode !== "HS" && b.reject_duplicate && prior2) throw Object.assign(Error("Barcode \u0111\xE3 t\u1ED3n t\u1EA1i."), { status: 409, code: "DUPLICATE_SCAN", count: prior2 });
    const stock = b.mode === "Stock" ? stockData(db, barcode) : null;
    const result = db.prepare("INSERT INTO scans(request_id,barcode,mode,user_id,image_type,image,quantity,prior_count,raw_barcode) VALUES (?,?,?,?,?,?,?,?,?)").run(id, barcode, b.mode, user.id, image.mime, image.buffer, (stock == null ? void 0 : stock.quantity) ?? scanQuantity(barcode, b.mode), prior2, ["HS", "Label"].includes(b.mode) ? raw : null), scanId = Number(result.lastInsertRowid);
    if (stock) db.prepare("INSERT INTO scan_stock(scan_id,item_code,item_name,maker,vendor,lot_no,quantity_source) VALUES (?,?,?,?,?,?,?)").run(scanId, stock.item_code, stock.item_name, stock.maker, stock.vendor, stock.lot_no, stock.quantity_source);
    return { id: scanId, prior_count: prior2, is_duplicate: prior2 > 0, barcode_count: prior2 + 1, stock };
  }
  if (p === "/scans" && method === "GET") {
    const mode = q.mode || null, rows = db.prepare(scanSelect + " WHERE s.id<? AND (? IS NULL OR s.mode=?) ORDER BY s.id DESC LIMIT 100").all(Number(q.before) || Number.MAX_SAFE_INTEGER, mode, mode), totals = db.prepare("SELECT COUNT(*) total,SUM(quantity) total_quantity,COUNT(quantity) quantity_count,COALESCE(MAX(id),0) max_id FROM scans WHERE (? IS NULL OR mode=?)").get(mode, mode);
    return { scans: rows, next: rows.length === 100 ? rows.at(-1).id : null, mode, ...totals, ...mode === "Stock" ? { stock_summary: db.prepare(`SELECT upper(trim(item_code)) item_code,MAX(item_name) item_name,COUNT(*) scans,COUNT(quantity) quantity_count,SUM(quantity) total_quantity FROM (${scanSelect} WHERE s.mode='Stock') WHERE trim(COALESCE(item_code,''))<>'' GROUP BY upper(trim(item_code))`).all() } : {} };
  }
  if (p === "/scans/delete") {
    admin();
    if (!["HS", "Stock", "Label"].includes(b.mode) || !Array.isArray(b.ids) || !b.ids.length || b.ids.length > 1e3 || b.ids.some((id) => !Number.isSafeInteger(id) || id < 1)) fail("Ch\u1ECDn t\u1ED1i \u0111a 1.000 l\u01B0\u1EE3t scan.");
    const ids = [...new Set(b.ids)];
    if (historical) {
      if (!Array.isArray(b.expected) || b.expected.length !== ids.length) fail("Thi\u1EBFu m\xE3 giao d\u1ECBch g\u1ED1c.");
      for (const id of ids) {
        const row = db.prepare("SELECT request_id FROM scans WHERE id=?").get(id);
        if (row && row.request_id !== ((_a2 = b.expected.find((v) => v.id === id)) == null ? void 0 : _a2.request_id)) fail("L\u1ECBch s\u1EED \u0111\xE3 thay \u0111\u1ED5i. Kh\xF4ng x\xF3a b\u1EA3n ghi m\u1EDBi.", 409);
      }
    }
    const result = db.prepare("DELETE FROM scans WHERE mode=? AND id IN (" + ids.map(() => "?").join(",") + ")").run(b.mode, ...ids);
    return { ok: true, deleted: result.changes };
  }
  const scanImage = /^\/scans\/(\d+)\/image$/.exec(p);
  if (scanImage) {
    const r = db.prepare("SELECT image_type mime,image bytes FROM scans WHERE id=?").get(Number(scanImage[1]));
    if (!(r == null ? void 0 : r.bytes)) fail("Ch\u01B0a c\xF3 \u1EA3nh.", 404);
    return binary(r.bytes, r.mime);
  }
  if (p === "/ckd/workbooks") return { workbooks: db.prepare("SELECT w.*,(SELECT COUNT(*) FROM ckd_models WHERE workbook_id=w.id) models,(SELECT COUNT(*) FROM ckd_orders WHERE workbook_id=w.id) orders FROM ckd_workbooks w ORDER BY id DESC").all() };
  if (p === "/ckd/pair/check") return checkCkd(db, b);
  if (p === "/ckd/pair/save") {
    write();
    const images = [];
    if (b.images && (typeof b.images !== "object" || Array.isArray(b.images) || Object.keys(b.images).some((k) => !["samsung", "item"].includes(k)))) fail("\u1EA2nh CKD kh\xF4ng h\u1EE3p l\u1EC7.");
    for (const slot of ["samsung", "item"]) if ((_b2 = b.images) == null ? void 0 : _b2[slot]) {
      const v = b.images[slot], image = offlineImage(typeof v === "string" ? v : v.source);
      let thumbnail;
      if (v.thumbnail) {
        const t = offlineImage(v.thumbnail);
        if (t.mime !== "image/jpeg" || t.buffer.length > 65536) fail("\u1EA2nh xem tr\u01B0\u1EDBc kh\xF4ng h\u1EE3p l\u1EC7.");
        thumbnail = t.buffer;
      }
      images.push({ slot, ...image, ...thumbnail ? { thumbnail } : {} });
    }
    return saveCkd(db, b, user.id, images);
  }
  if (p === "/ckd/history/delete") {
    admin();
    if (historical) {
      if (!Array.isArray(b.ids) || !Array.isArray(b.expected) || b.ids.length !== b.expected.length) fail("Thi\u1EBFu m\xE3 giao d\u1ECBch CKD g\u1ED1c.");
      for (const id of b.ids) {
        const row = db.prepare("SELECT request_id FROM ckd_checks WHERE id=?").get(id);
        if (row && row.request_id !== ((_c = b.expected.find((v) => v.id === id)) == null ? void 0 : _c.request_id)) fail("L\u1ECBch s\u1EED CKD \u0111\xE3 thay \u0111\u1ED5i.", 409);
      }
      b = { ...b, all: false, ids: b.ids.filter((id) => db.prepare("SELECT id FROM ckd_checks WHERE id=?").get(id)) };
      if (!b.ids.length) return { ok: true, deleted: 0 };
    }
    return deleteCkdHistory(db, b, user.id);
  }
  if (p === "/ckd/history") {
    const r = ckdOverview(db, q.scope === "all" ? 0 : Number(q.workbook_id)), rows = r.checks.filter((c) => !q.before || c.id < Number(q.before)), checks = rows.slice(0, 200);
    return { ...r, checks, next: rows.length > 200 ? checks.at(-1).id : null, count: r.checks.length, max_id: ((_d = r.checks[0]) == null ? void 0 : _d.id) || 0, totals: r.summary.filter((g) => g.boxes > 0) };
  }
  const ckdImage = /^\/ckd\/checks\/(\d+)\/image\/(samsung|item)$/.exec(p);
  if (ckdImage) {
    const r = db.prepare("SELECT mime,image bytes FROM ckd_check_images WHERE check_id=? AND slot=?").get(Number(ckdImage[1]), ckdImage[2]);
    if (!r) fail("Ch\u01B0a c\xF3 \u1EA3nh.", 404);
    return binary(r.bytes, r.mime);
  }
  if (p.startsWith("/holding/v2/")) {
    const a = p.slice("/holding/v2/".length);
    if (method === "POST") write();
    if (a === "delete-preview") {
      admin();
      const rows = db.prepare("SELECT id,revision expected_revision FROM holding_entries WHERE remaining_qty>0 ORDER BY id LIMIT 10001").all();
      if (rows.length > 1e4) fail("C\xF3 h\u01A1n 10.000 box; h\xE3y x\xF3a theo t\u1EEBng nh\xF3m.");
      return { rows };
    }
    if (a === "delete") {
      admin();
      return deleteHolding(db, b, user.id);
    }
    if (a === "item-mm") {
      const code2 = text(q.code, "ITEM", 200).toUpperCase();
      const savedCode = db.prepare("SELECT item_code,item_name FROM mm_code_registry WHERE item_code=?").get(code2);
      let rows = savedCode ? db.prepare("SELECT barcode,item_code,item_name,maker AS vendor,lot_no FROM mm_inventory WHERE item_code=? ORDER BY barcode LIMIT 201").all(savedCode.item_code) : db.prepare("SELECT barcode,item_code,item_name,maker AS vendor,lot_no FROM mm_inventory WHERE barcode=? ORDER BY barcode LIMIT 201").all(code2);
      if (!rows.length) rows = db.prepare("SELECT barcode,item_code,item_name,maker AS vendor,lot_no FROM mm_inventory WHERE item_code=? ORDER BY barcode LIMIT 201").all(code2);
      if (rows.length > 200 && !savedCode) fail("ITEM has more than 200 MM rows. Scan the exact MM barcode.");
      if (!rows.length) rows = db.prepare("SELECT m.samsung AS barcode,m.item_code,m.item AS item_name,m.maker AS vendor,COALESCE(st.lot_no,'') lot_no FROM materials m LEFT JOIN material_stock st ON st.item_code=m.item_code WHERE m.item_code=? OR m.samsung=?").all(code2, code2);
      if (savedCode && !rows.length) rows = [savedCode];
      rows = rows.map((row) => {
        const saved = savedCode || db.prepare("SELECT item_name FROM mm_code_registry WHERE item_code=?").get(row.item_code);
        return saved ? { ...row, item_name: saved.item_name, name_source: "code_directory" } : row;
      });
      return { rows };
    }
    if (a === "reference") return holdingReference(db);
    if (a === "lookup") return holdingLookup(db, q.barcode);
    if (a === "preferences") return holdingPreferences(db, user.id, method === "POST" ? b : void 0);
    if (a === "inventory") return holdingInventory(db, q);
    if (a === "events") {
      const events = holdingEvents(db, q);
      return { events, next: events.length === 100 ? events.at(-1).id : null };
    }
    if (a === "receive") return receiveHolding(db, b, user.id, offlineImage(b.image));
    if (a === "withdraw") return withdrawHolding(db, b, user.id);
    if (a === "edit") return editHolding(db, b, user.id);
    if (a === "edit-group") return editHoldingGroup(db, b, user.id);
    const image = /^entries\/(\d+)\/image$/.exec(a);
    if (image) {
      const r = db.prepare("SELECT image_type mime,image bytes FROM holding_entries WHERE id=?").get(Number(image[1]));
      if (!(r == null ? void 0 : r.bytes)) fail("Ch\u01B0a c\xF3 \u1EA3nh.", 404);
      return binary(r.bytes, r.mime);
    }
    if (a === "export") return binary(holdingReport(db, q, { ...user, name: user.name + " \xB7 OFFLINE / T\u1EA0M T\xCDNH" }), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Holding-Offline.xlsx");
  }
  if (p === "/heatsink") {
    initHeatsink(db);
    return listHeatsink(db, q);
  }
  const heatsinkImage = /^\/heatsink\/image\/([a-f0-9]{64})$/.exec(p);
  if (heatsinkImage) {
    const r = db.prepare("SELECT mime,bytes FROM heatsink_images WHERE id=?").get(heatsinkImage[1]);
    if (!r) fail("Ch\u01B0a c\xF3 \u1EA3nh.", 404);
    return binary(r.bytes, r.mime);
  }
  if (p === "/cutting/status") return cuttingStatus(db);
  if (p === "/cutting/lookup") return lookupCutting(db, { code: q.code, model: q.model, direction: q.direction || "auto" });
  if (p === "/cutting/scans" && method === "POST") {
    write();
    return saveCuttingScan(db, { ...b, user_id: user.id, request_id: requestId(b.request_id), image: offlineImage(b.image) });
  }
  if (p === "/cutting/scans") {
    const rows = db.prepare("SELECT s.id,s.code,s.snapshot,s.created_at,u.name scanner,s.image IS NOT NULL has_image FROM cutting_scans s JOIN users u ON u.id=s.user_id WHERE s.id<? ORDER BY s.id DESC LIMIT 50").all(Number(q.before) || Number.MAX_SAFE_INTEGER);
    return { scans: rows.map(({ snapshot: snapshot2, ...r }) => {
      const v = JSON.parse(snapshot2);
      return { ...r, count: v.count, targets: [...new Set(v.matches.map((m) => m.target_code))], model: v.model, direction: v.direction };
    }), next: rows.length === 50 ? rows.at(-1).id : null, total: db.prepare("SELECT COUNT(*) n FROM cutting_scans").get().n };
  }
  const cutImage = /^\/cutting\/scans\/(\d+)\/image$/.exec(p);
  if (cutImage) {
    const r = db.prepare("SELECT image_type mime,image bytes FROM cutting_scans WHERE id=?").get(Number(cutImage[1]));
    if (!(r == null ? void 0 : r.bytes)) fail("Ch\u01B0a c\xF3 \u1EA3nh.", 404);
    return binary(r.bytes, r.mime);
  }
  const cutDetail = /^\/cutting\/scans\/(\d+)$/.exec(p);
  if (cutDetail) {
    const r = db.prepare("SELECT s.*,u.name scanner,s.image IS NOT NULL has_image FROM cutting_scans s JOIN users u ON u.id=s.user_id WHERE s.id=?").get(Number(cutDetail[1]));
    if (!r) fail("Kh\xF4ng t\xECm th\u1EA5y l\u01B0\u1EE3t qu\xE9t.", 404);
    return { ...JSON.parse(r.snapshot), id: r.id, scanner: r.scanner, created_at: r.created_at, has_image: r.has_image };
  }
  if (p === "/export/scans") {
    const mode = q.mode || null, rows = db.prepare(scanSelect + " WHERE (? IS NULL OR s.mode=?) ORDER BY s.id DESC").all(mode, mode);
    return binary(scanReport(db, rows, mode, { ...user, name: user.name + " \xB7 OFFLINE / T\u1EA0M T\xCDNH" }), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Scan-Offline.xlsx");
  }
  if (p === "/ckd/export" || p === "/ckd/report.zip") {
    const report = ckdReport(db, q.scope === "all" ? 0 : Number(q.workbook_id), { exportedBy: user.name + " \xB7 OFFLINE / T\u1EA0M T\xCDNH", imageLinks: p.endsWith(".zip") });
    return p.endsWith(".zip") ? { binary: true, zip: report.entries, mime: "application/zip", name: "CKD-Offline.zip" } : binary(report.workbookBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "CKD-Offline.xlsx");
  }
  if (p === "/cutting/export") {
    const rows = db.prepare("SELECT s.*,u.name scanner FROM cutting_scans s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC").all();
    return binary(reportWorkbook([{ name: "L\u1ECBch s\u1EED", rows: [["STT", "M\xE3 qu\xE9t", "Model", "K\u1EBFt qu\u1EA3", "Ng\u01B0\u1EDDi scan", "Gi\u1EDD scan"], ...rows.map((r, i2) => {
      const s = JSON.parse(r.snapshot);
      return [i2 + 1, r.code, s.model, s.matches.map((m) => m.target_code).join(" / "), r.scanner, r.created_at];
    })] }], { title: "B\xC1O C\xC1O C\u1EAET CH\xC2N \xB7 OFFLINE / T\u1EA0M T\xCDNH", exportedBy: user.name }), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Cutting-Offline.xlsx");
  }
  fail("T\xEDnh n\u0103ng qu\u1EA3n tr\u1ECB / nh\u1EADp file n\xE0y c\u1EA7n m\xE1y ch\u1EE7 online.", 503);
}
function stampOfflineTime(db, path, body, result, iso, userId) {
  const at = iso.replace("T", " ").replace("Z", ""), tables = { "/scans": "scans", "/ckd/pair/save": "ckd_checks", "/cutting/scans": "cutting_scans" };
  if (tables[path]) db.prepare("UPDATE " + tables[path] + " SET created_at=? WHERE request_id=? AND user_id=?").run(at, body.request_id, userId);
  if (path.startsWith("/holding/v2/") && body.request_id) {
    db.prepare("UPDATE holding_events SET created_at=? WHERE request_id=? AND user_id=?").run(at, body.request_id, userId);
    if (path.endsWith("/receive")) db.prepare("UPDATE holding_entries SET created_at=? WHERE id=? AND user_id=?").run(at, result.id, userId);
  }
  if (path === "/holding/v2/edit-group") db.prepare("UPDATE holding_events SET created_at=? WHERE user_id=? AND json_extract(response,'$.group_request_id')=?").run(at, userId, body.request_id);
  if (path === "/holding/v2/delete") for (const row of body.rows || []) db.prepare("UPDATE holding_events SET created_at=? WHERE user_id=? AND request_id=?").run(at, userId, createHash("sha256").update(body.request_id + ":delete:" + row.id).digest("hex"));
  if (path === "/materials/lookup" && result.saved_id) db.prepare("UPDATE mm_lookup_saved SET updated_at=? WHERE id=? AND user_id=?").run(at, result.saved_id, userId);
}

// offline/client.mjs
var esc2 = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var message = (error2) => (error2 == null ? void 0 : error2.message) || "Ch\u01B0a k\u1EBFt n\u1ED1i \u0111\u01B0\u1EE3c m\xE1y ch\u1EE7.";
var fail2 = (text2, status = 400) => {
  throw Object.assign(Error(text2), { status });
};
var names = { "/scans": "Qu\xE9t m\xE3", "/scans/delete": "X\xF3a l\u1ECBch s\u1EED", "/ckd/pair/save": "Check CKD", "/ckd/history/delete": "X\xF3a CKD", "/holding/v2/receive": "Nh\u1EADp Holding", "/holding/v2/withdraw": "Xu\u1EA5t Holding", "/holding/v2/edit": "S\u1EEDa Holding", "/holding/v2/edit-group": "S\u1EEDa nh\xF3m ITEM", "/holding/v2/delete": "X\xF3a kh\u1ECFi Holding", "/cutting/scans": "C\u1EAFt ch\xE2n", "/materials/lookup": "L\u01B0u tra c\u1EE9u MM", "/preferences": "Ph\xEDm t\u1EAFt", "/holding/v2/preferences": "Location Holding" };
var OfflineClient = class {
  constructor() {
    this.enabled = true;
    this.meta = { active: false, maps: {} };
    this.ops = [];
    this.db = null;
    this.online = navigator.onLine;
    this.csrf = null;
    this.notice = "";
    this.chain = Promise.resolve();
    this.images = /* @__PURE__ */ new Map();
    this.generation = 0;
    this.nextAttempt = 0;
  }
  async ready() {
    var _a2;
    try {
      this.meta = await read("meta", "active") || this.meta;
      this.ops = await read("ops") || [];
      const base = await read("base", "active");
      if (base && this.meta.baseUserId === ((_a2 = this.meta.profile) == null ? void 0 : _a2.id)) {
        this.db = await openDeviceDatabase(base);
        for (const op of this.ops) {
          try {
            this.apply(op);
            if (op.ack) this.applyReceipt(op);
          } catch (error2) {
            this.notice = "Kh\xF4ng d\u1EF1ng l\u1EA1i \u0111\u01B0\u1EE3c h\xE0ng ch\u1EDD: " + message(error2);
            this.replayError = true;
            break;
          }
        }
      }
    } catch (error2) {
      this.notice = "Kh\xF4ng \u0111\u1ECDc \u0111\u01B0\u1EE3c b\u1ED9 nh\u1EDB offline: " + message(error2);
    }
    this.install();
    return this;
  }
  install() {
    const strip = document.createElement("div");
    strip.id = "device-offline-strip";
    strip.className = "device-offline-strip";
    document.body.prepend(strip);
    this.showStatusStrip();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") this.showStatusStrip();
    });
    document.addEventListener("click", (event2) => {
      const a = event2.target.closest("a");
      if (!a || !this.db || !this.meta.active) return;
      const url = new URL(a.href, location.href);
      if (url.origin !== location.origin || !url.pathname.startsWith("/api/")) return;
      if (/\/(?:export|report\.zip)(?:\/|$)|\/image(?:\/|$)/.test(url.pathname)) {
        event2.preventDefault();
        this.downloadResource(url.pathname.slice(4) + url.search).catch((error2) => this.notify(message(error2)));
      }
    }, true);
    let scheduled = false;
    new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      queueMicrotask(() => {
        scheduled = false;
        this.localImages();
      });
    }).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("online", () => {
      this.online = true;
      this.paint();
      this.sync().then(() => this.refreshIfDue()).catch(() => {
      });
    });
    window.addEventListener("offline", () => {
      this.online = false;
      this.paint();
    });
    this.timer = setInterval(() => {
      if (document.visibilityState === "visible" && this.meta.active && navigator.onLine && !this.conflict) this.sync().then(() => this.refreshIfDue()).catch(() => {
      });
    }, 15e3);
    if (this.meta.active && this.db) setTimeout(() => this.probe().then(() => this.sync()).then(() => this.refreshIfDue()).catch(() => {
    }), 500);
  }
  showStatusStrip() {
    clearTimeout(this.stripTimer);
    this.stripVisible = true;
    this.paint();
    this.stripTimer = setTimeout(() => {
      this.stripVisible = false;
      this.paint();
    }, 3e4);
  }
  pending() {
    return this.ops.filter((op) => !op.ack);
  }
  serial(fn) {
    const next = this.chain.then(fn, fn);
    this.chain = next.catch(() => {
    });
    return next;
  }
  async persist() {
    await change(["meta"], (tx) => tx.objectStore("meta").put(this.meta, "active"));
  }
  notify(text2) {
    this.notice = text2;
    this.paint();
    if (document.querySelector("#offline-message")) document.querySelector("#offline-message").textContent = text2;
  }
  paint() {
    const strip = document.querySelector("#device-offline-strip");
    if (!strip) return;
    strip.hidden = this.stripVisible === false;
    const count = this.pending().length;
    strip.dataset.waiting = String(count > 0 || !this.online);
    strip.dataset.error = String(!!this.conflict || !!this.replayError);
    strip.innerHTML = `<span>${!this.meta.active ? "Work Area \xB7 Online + Offline" : !this.db ? "Ch\u01B0a t\u1EA3i d\u1EEF li\u1EC7u offline" : this.online ? "D\u1EEF li\u1EC7u tr\xEAn m\xE1y" : "\u0110ang offline"}${count ? " \xB7 " + count + " ch\u1EDD \u0111\u1ED3ng b\u1ED9" : ""}${this.conflict ? " \xB7 C\u1EA7n ki\u1EC3m tra" : ""}</span><a href="#offline">\u0110\u1ED3ng b\u1ED9</a>`;
  }
  async remote(path, { method = "GET", data, timeout = 1e4 } = {}) {
    let response;
    try {
      response = await fetch("/api" + path, { method, credentials: "same-origin", headers: data ? { "Content-Type": "application/json", "X-CSRF-Token": this.csrf || "" } : {}, body: data ? JSON.stringify(data) : void 0, signal: AbortSignal.timeout(timeout) });
    } catch (error2) {
      this.online = false;
      this.nextAttempt = Date.now() + 15e3;
      this.paint();
      throw Object.assign(Error("Kh\xF4ng k\u1EBFt n\u1ED1i \u0111\u01B0\u1EE3c server. D\u1EEF li\u1EC7u v\u1EABn gi\u1EEF tr\xEAn \u0111i\u1EC7n tho\u1EA1i."), { network: true });
    }
    if (response.status >= 500) {
      this.online = false;
      this.nextAttempt = Date.now() + 15e3;
      this.paint();
      throw Object.assign(Error("M\xE1y ch\u1EE7 \u0111ang g\u1EB7p v\u1EA5n \u0111\u1EC1. D\u1EEF li\u1EC7u v\u1EABn gi\u1EEF tr\xEAn \u0111i\u1EC7n tho\u1EA1i."), { network: true, status: response.status });
    }
    let value;
    try {
      value = await response.json();
    } catch {
      this.online = false;
      this.nextAttempt = Date.now() + 15e3;
      throw Object.assign(Error("Ph\u1EA3n h\u1ED3i server ch\u01B0a \u0111\u1EA7y \u0111\u1EE7; gi\u1EEF giao d\u1ECBch \u0111\u1EC3 g\u1EEDi l\u1EA1i."), { network: true });
    }
    if (!response.ok) throw Object.assign(Error(value.error || "M\xE1y ch\u1EE7 t\u1EEB ch\u1ED1i thao t\xE1c."), { status: response.status });
    this.online = true;
    this.paint();
    return value;
  }
  async probe() {
    var _a2;
    const value = await this.remote("/me");
    if (!value.user || value.user.id !== ((_a2 = this.meta.profile) == null ? void 0 : _a2.id)) {
      this.csrf = null;
      this.authNeeded = true;
      throw Object.assign(Error("\u0110\u0103ng nh\u1EADp l\u1EA1i server \u0111\u1EC3 \u0111\u1ED3ng b\u1ED9 \u0111\xFAng t\xE0i kho\u1EA3n."), { status: 401 });
    }
    this.csrf = value.csrf;
    this.authNeeded = false;
    this.meta.profile = value.user;
    await this.persist();
    return value;
  }
  async verifier(password, salt) {
    const bytes = new TextEncoder().encode(password), key = await crypto.subtle.importKey("raw", bytes, "PBKDF2", false, ["deriveBits"]);
    const value = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: new Uint8Array(salt), iterations: 21e4, hash: "SHA-256" }, key, 256);
    return [...new Uint8Array(value)];
  }
  async login(data) {
    var _a2, _b2, _c, _d, _e;
    if (this.pending().length && ((_a2 = this.meta.profile) == null ? void 0 : _a2.username.toLowerCase()) !== String(data.username).toLowerCase()) fail2("C\xF2n h\xE0ng ch\u1EDD c\u1EE7a t\xE0i kho\u1EA3n " + this.meta.profile.username + ". \u0110\u1ED3ng b\u1ED9 tr\u01B0\u1EDBc khi \u0111\u1ED5i t\xE0i kho\u1EA3n.");
    let result;
    try {
      result = await this.remote("/login", { method: "POST", data });
    } catch (error2) {
      if (!error2.network) throw error2;
      const v = this.meta.verifier;
      if (!this.db || !v || String(data.username).toLowerCase() !== ((_b2 = this.meta.profile) == null ? void 0 : _b2.username.toLowerCase())) fail2("C\u1EA7n \u0111\u0103ng nh\u1EADp v\xE0 t\u1EA3i d\u1EEF li\u1EC7u khi c\xF3 m\u1EA1ng \xEDt nh\u1EA5t m\u1ED9t l\u1EA7n.");
      const actual = await this.verifier(data.password, v.salt);
      let difference = 0;
      for (let i2 = 0; i2 < actual.length; i2++) difference |= actual[i2] ^ v.hash[i2];
      if (difference) fail2("T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng.", 401);
      this.meta.active = true;
      await this.persist();
      this.paint();
      return { user: this.meta.profile, csrf: "device-workspace" };
    }
    const same = ((_c = this.meta.profile) == null ? void 0 : _c.id) === result.user.id;
    if (!same && (this.pending().length || this.db && ((_d = this.meta.profile) == null ? void 0 : _d.username.toLowerCase()) === result.user.username.toLowerCase())) {
      this.csrf = null;
      this.authNeeded = true;
      this.conflict = "T\xE0i kho\u1EA3n server kh\xF4ng c\xF2n c\xF9ng \u0111\u1ECBnh danh v\u1EDBi d\u1EEF li\u1EC7u tr\xEAn m\xE1y. H\xE0ng ch\u1EDD \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn; h\xE3y xu\u1EA5t d\u1EF1 ph\xF2ng v\xE0 kh\xF4i ph\u1EE5c \u0111\xFAng d\u1EEF li\u1EC7u server.";
      this.notify(this.conflict);
      fail2(this.conflict, 409);
    }
    if (!same) {
      (_e = this.db) == null ? void 0 : _e.close();
      this.db = null;
      this.ops = [];
      this.meta.maps = {};
      this.conflict = null;
    }
    this.meta.profile = result.user;
    this.meta.active = true;
    this.csrf = result.csrf;
    this.authNeeded = false;
    const salt = [...crypto.getRandomValues(new Uint8Array(16))];
    this.meta.verifier = { salt, hash: await this.verifier(data.password, salt) };
    await this.persist();
    if (!this.db) {
      try {
        await this.prepare();
      } catch (error2) {
        this.notify("\u0110\u0103ng nh\u1EADp th\xE0nh c\xF4ng. Ch\u01B0a t\u1EA3i xong d\u1EEF li\u1EC7u offline: " + message(error2));
      }
    }
    this.paint();
    return result;
  }
  async api(path, options = {}, network) {
    var _a2, _b2;
    const method = options.method || "GET";
    if (path === "/register") return this.remote("/register", { method: "POST", data: options.data });
    if (path === "/login") return this.login(options.data);
    if (path === "/logout") {
      this.meta.active = false;
      await this.persist();
      if (this.csrf) this.remote("/logout", { method: "POST", data: {} }).catch(() => {
      });
      this.csrf = null;
      this.paint();
      return { ok: true };
    }
    if (path === "/me") {
      if (this.meta.active && this.db && !this.replayError) return { user: this.meta.profile, csrf: "device-workspace", needsSetup: false };
      if (this.meta.profile && !this.meta.active) return { user: null, csrf: null, needsSetup: false };
      const value = await network();
      if (value.user) {
        this.meta.profile = value.user;
        this.meta.active = true;
        this.csrf = value.csrf;
        await this.persist();
      }
      return value;
    }
    if (!this.db || !this.meta.active || this.replayError) {
      if (path === "/scans" && ((_a2 = options.data) == null ? void 0 : _a2.mode) === "HS") fail2("C\u1EA7n \u0111\u0103ng nh\u1EADp v\xE0 t\u1EA3i l\u1ECBch s\u1EED v\u1EC1 \u0111i\u1EC7n tho\u1EA1i tr\u01B0\u1EDBc khi so tr\xF9ng HS tr\xEAn m\xE1y.", 503);
      if (!navigator.onLine || this.replayError) fail2(this.notice || "\u0110\u0103ng nh\u1EADp v\xE0 t\u1EA3i d\u1EEF li\u1EC7u offline tr\u01B0\u1EDBc khi l\xE0m vi\u1EC7c.", 503);
      return network();
    }
    if (method === "DELETE" && /^\/scans\/\d+$/.test(path)) {
      const id = Number(path.split("/").at(-1)), row = this.db.prepare("SELECT mode FROM scans WHERE id=?").get(id);
      if (!row) fail2("Kh\xF4ng c\xF2n l\u01B0\u1EE3t qu\xE9t.", 404);
      path = "/scans/delete";
      options = { method: "POST", data: { mode: row.mode, ids: [id] } };
    }
    const verb = options.method || "GET";
    if (verb === "POST" && queuePaths.has(path)) {
      const committed = await this.serial(() => this.commit(path, options.data || {}));
      if (!committed.op) return committed.result;
      if (path === "/scans" && ((_b2 = options.data) == null ? void 0 : _b2.mode) === "HS") {
        if (navigator.onLine && this.online && !this.conflict && !this.syncing && Date.now() >= this.nextAttempt) this.sync().catch(() => {
        });
        return { ...committed.result, duplicate_scope: "device", offline: true };
      }
      if (navigator.onLine && this.online && !this.conflict && !this.syncing && Date.now() >= this.nextAttempt) {
        let timer;
        await Promise.race([this.sync().catch(() => {
        }), new Promise((resolve) => {
          timer = setTimeout(resolve, 1200);
        })]);
        clearTimeout(timer);
      }
      return { ...committed.result, ...committed.op.serverResult || {}, ...committed.result.id ? { id: committed.result.id } : {}, offline: !committed.op.ack };
    }
    const heatsinkRead = verb === "GET" && (path === "/heatsink" || path.startsWith("/heatsink?"));
    if (heatsinkRead) {
      if (navigator.onLine && this.online) {
        try {
          if (!this.csrf) await this.probe();
          return await network();
        } catch (error2) {
          if (error2.status === 401) {
            this.csrf = null;
            this.authNeeded = true;
            this.paint();
          } else if (!error2.network && !(error2.status >= 500)) throw error2;
        }
      }
      return { ...businessApi(this.db, this.meta.profile, path, options), source: "device", snapshot_at: this.meta.snapshotAt || null, auth_required: !!this.authNeeded };
    }
    if (path === "/users" && verb === "GET" && navigator.onLine && this.online) {
      try {
        if (!this.csrf) await this.probe();
        return await network();
      } catch (error2) {
        if (!error2.network && !(error2.status >= 500)) throw error2;
      }
    }
    try {
      return businessApi(this.db, this.meta.profile, path, options);
    } catch (error2) {
      if (error2.status !== 503) throw error2;
      if (!navigator.onLine) throw error2;
      if (!this.csrf) await this.probe();
      const result = await network();
      if (path === "/password") {
        const salt = [...crypto.getRandomValues(new Uint8Array(16))];
        this.meta.verifier = { salt, hash: await this.verifier(options.data.password, salt) };
        this.meta.active = false;
        this.csrf = null;
        await this.persist();
      }
      if (verb !== "GET") this.notice = "D\u1EEF li\u1EC7u server \u0111\xE3 thay \u0111\u1ED5i. V\xE0o \u0110\u1ED3ng b\u1ED9 \u0111\u1EC3 t\u1EA3i b\u1EA3n m\u1EDBi sau khi g\u1EEDi h\u1EBFt h\xE0ng ch\u1EDD.";
      return result;
    }
  }
  prepareBody(path, value) {
    const b = structuredClone(value);
    if (path === "/scans/delete" && b.all) {
      b.ids = this.db.prepare("SELECT id FROM scans WHERE mode=? AND id<=? ORDER BY id").all(b.mode, b.through_id).map((r) => r.id);
      delete b.all;
    }
    if (path === "/scans/delete") {
      b.expected = (b.ids || []).map((id) => {
        var _a2;
        return { id, request_id: (_a2 = this.db.prepare("SELECT request_id FROM scans WHERE id=?").get(id)) == null ? void 0 : _a2.request_id };
      });
    }
    if (path === "/ckd/history/delete" && b.all) {
      b.ids = this.db.prepare("SELECT id FROM ckd_checks WHERE id<=? AND (?=1 OR workbook_id=?)").all(b.through_id, b.scope === "all" ? 1 : 0, Number(b.workbook_id) || 0).map((r) => r.id);
      delete b.all;
    }
    if (path === "/ckd/history/delete") b.expected = (b.ids || []).map((id) => {
      var _a2;
      return { id, request_id: (_a2 = this.db.prepare("SELECT request_id FROM ckd_checks WHERE id=?").get(id)) == null ? void 0 : _a2.request_id };
    });
    return b;
  }
  apply(op) {
    const result = businessApi(this.db, op.actor || this.meta.profile, op.path, { method: "POST", data: op.body });
    this.preserveIds(op, result);
    stampOfflineTime(this.db, op.path, op.body, result, op.at, (op.actor || this.meta.profile).id);
    return result;
  }
  preserveIds(op, result) {
    var _a2;
    const table = { "/scans": "scans", "/ckd/pair/save": "ckd_checks", "/holding/v2/receive": "holding_entries", "/cutting/scans": "cutting_scans", "/materials/lookup": "mm_lookup_saved" }[op.path], key = op.path === "/materials/lookup" ? "saved_id" : "id", wanted = (_a2 = op.localResult) == null ? void 0 : _a2[key], actual = result[key];
    if (!table || !wanted || !actual || wanted === actual) return;
    this.db.exec("SAVEPOINT stable_device_ids; PRAGMA defer_foreign_keys=ON");
    try {
      this.db.prepare("UPDATE " + table + " SET id=? WHERE id=?").run(wanted, actual);
      if (table === "scans") this.db.prepare("UPDATE scan_stock SET scan_id=? WHERE scan_id=?").run(wanted, actual);
      if (table === "ckd_checks") this.db.prepare("UPDATE ckd_check_images SET check_id=? WHERE check_id=?").run(wanted, actual);
      if (table === "holding_entries") {
        this.db.prepare("UPDATE holding_events SET entry_id=?,response=json_set(response,'$.id',?) WHERE entry_id=?").run(wanted, wanted, actual);
      }
      this.db.exec("RELEASE SAVEPOINT stable_device_ids");
      result[key] = wanted;
    } catch (error2) {
      this.db.exec("ROLLBACK TO SAVEPOINT stable_device_ids; RELEASE SAVEPOINT stable_device_ids");
      throw error2;
    }
  }
  async commit(path, value) {
    var _a2;
    const body = this.prepareBody(path, value);
    if ((path === "/scans/delete" || path === "/ckd/history/delete") && !((_a2 = body.ids) == null ? void 0 : _a2.length)) return { result: { ok: true, deleted: 0 } };
    const op = { id: crypto.randomUUID(), path, body, at: (/* @__PURE__ */ new Date()).toISOString(), actor: { ...this.meta.profile }, realm: this.meta.realm, ack: false };
    this.db.exec("SAVEPOINT device_write");
    try {
      const result = this.apply(op);
      op.localResult = result;
      if (path === "/materials/lookup" && result.saved_id) op.wireBody = { ...body, _offline_saved: JSON.parse(this.db.prepare("SELECT snapshot FROM mm_lookup_saved WHERE id=?").get(result.saved_id).snapshot) };
      op.seq = await addOperation(op);
      this.db.exec("RELEASE SAVEPOINT device_write");
      this.ops.push(op);
      this.generation++;
      this.paint();
      return { result, op };
    } catch (error2) {
      this.db.exec("ROLLBACK TO SAVEPOINT device_write; RELEASE SAVEPOINT device_write");
      if (error2.name === "QuotaExceededError") fail2("B\u1ED9 nh\u1EDB \u0111i\u1EC7n tho\u1EA1i \u0111\u1EA7y. L\u01B0\u1EE3t n\xE0y ch\u01B0a l\u01B0u; h\xE3y \u0111\u1ED3ng b\u1ED9 ho\u1EB7c gi\u1EA3i ph\xF3ng dung l\u01B0\u1EE3ng r\u1ED3i th\u1EED l\u1EA1i.", 507);
      throw error2;
    }
  }
  wire(op) {
    const b = structuredClone(op.wireBody || op.body), map = (entity, id) => {
      var _a2;
      return ((_a2 = this.meta.maps) == null ? void 0 : _a2[entity + ":" + id]) ?? id;
    };
    if (op.path.startsWith("/holding/v2/")) {
      if (b.entry_id) b.entry_id = map("holding", b.entry_id);
      if (b.rows) b.rows = b.rows.map((row) => ({ ...row, id: map("holding", row.id) }));
    }
    if (op.path === "/scans/delete" || op.path === "/ckd/history/delete") {
      const entity = op.path === "/scans/delete" ? "scan" : "ckd";
      b.ids = b.ids.map((id) => map(entity, id));
      if (b.expected) b.expected = b.expected.map((row) => ({ ...row, id: map(entity, row.id) }));
    }
    return b;
  }
  applyReceipt(op) {
    if (op.path !== "/scans" || !op.serverResult) return;
    const r = op.serverResult;
    if (op.body.mode !== "HS") this.db.prepare("UPDATE scans SET prior_count=? WHERE request_id=? AND user_id=?").run(r.prior_count || 0, op.body.request_id, op.actor.id);
    if (r.stock) {
      const s = r.stock;
      this.db.prepare("UPDATE scans SET quantity=? WHERE request_id=? AND user_id=?").run(s.quantity, op.body.request_id, op.actor.id);
      this.db.prepare("UPDATE scan_stock SET item_code=?,item_name=?,maker=?,vendor=?,lot_no=?,quantity_source=? WHERE scan_id=?").run(s.item_code, s.item_name, s.maker, s.vendor, s.lot_no, s.quantity_source, op.localResult.id);
    }
  }
  async refreshIfDue() {
    if (this.db && this.meta.active && this.online && !this.pending().length && !this.preparing && !this.conflict && !document.querySelector("#camera-dialog[open]") && Date.now() - Date.parse(this.meta.snapshotAt || 0) > 15 * 6e4) await this.prepare();
  }
  async sync() {
    if (this.syncing) return this.syncing;
    if (!this.meta.active || !this.db || this.replayError) return;
    if (!this.pending().length) {
      this.notice = "Kh\xF4ng c\xF3 thao t\xE1c ch\u1EDD \u0111\u1ED3ng b\u1ED9.";
      this.paint();
      return;
    }
    this.syncing = (async () => {
      try {
        if (!this.csrf) await this.probe();
        while (this.pending().length) {
          const op = this.pending()[0];
          const receipt = await this.remote("/offline/replay", { method: "POST", data: { request_id: op.id, path: op.path, body: this.wire(op), captured_at: op.at, realm: op.realm || this.meta.realm }, timeout: 15e3 });
          if (!receipt.result || receipt.request_id !== op.id) throw Object.assign(Error("Ch\u01B0a nh\u1EADn \u0111\u01B0\u1EE3c x\xE1c nh\u1EADn \u0111\u1ED3ng b\u1ED9 \u0111\u1EA7y \u0111\u1EE7."), { network: true });
          await this.serial(async () => {
            var _a2;
            op.ack = true;
            op.serverResult = receipt.result;
            op.error = null;
            const entity = { "/scans": "scan", "/ckd/pair/save": "ckd", "/holding/v2/receive": "holding", "/cutting/scans": "cut" }[op.path];
            if (entity && op.localResult.id && receipt.result.id) {
              (_a2 = this.meta).maps ?? (_a2.maps = {});
              this.meta.maps[entity + ":" + op.localResult.id] = receipt.result.id;
            }
            this.meta.lastUpload = (/* @__PURE__ */ new Date()).toISOString();
            await change(["meta", "ops"], (tx) => {
              tx.objectStore("ops").put(op);
              tx.objectStore("meta").put(this.meta, "active");
            });
            this.applyReceipt(op);
            this.paint();
          });
        }
        this.conflict = null;
        this.notice = this.pending().length ? "C\xF2n l\u01B0\u1EE3t ch\u1EDD \u0111\u1ED3ng b\u1ED9." : "\u0110\xE3 g\u1EEDi h\u1EBFt h\xE0ng ch\u1EDD l\xEAn server.";
      } catch (error2) {
        if (error2.status === 401 || error2.status === 403) {
          this.csrf = null;
          this.authNeeded = true;
        }
        if (!error2.network) {
          const op = this.pending()[0];
          if (op) {
            op.error = message(error2);
            await change(["ops"], (tx) => tx.objectStore("ops").put(op));
          }
          this.conflict = message(error2);
        }
        this.notice = message(error2);
        throw error2;
      } finally {
        this.paint();
        this.syncing = null;
      }
    })();
    return this.syncing;
  }
  async prepare() {
    var _a2;
    if (this.preparing) return;
    if (this.pending().length) fail2("G\u1EEDi h\u1EBFt h\xE0ng ch\u1EDD tr\u01B0\u1EDBc khi thay b\u1EA3n d\u1EEF li\u1EC7u offline.");
    if (!this.meta.active) fail2("\u0110\u0103ng nh\u1EADp tr\u01B0\u1EDBc khi t\u1EA3i d\u1EEF li\u1EC7u.");
    this.preparing = true;
    const version = this.generation;
    this.notify("\u0110ang t\u1EA3i d\u1EEF li\u1EC7u offline. Gi\u1EEF app m\u1EDF\u2026");
    try {
      await this.probe();
      let response;
      try {
        response = await fetch("/api/offline/snapshot", { credentials: "same-origin", signal: AbortSignal.timeout(18e4) });
      } catch {
        throw Error("Kh\xF4ng t\u1EA3i \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u offline. Ki\u1EC3m tra m\u1EA1ng r\u1ED3i th\u1EED l\u1EA1i.");
      }
      if (!response.ok) {
        const error2 = await response.json();
        throw Error(error2.error || "Server ch\u01B0a chu\u1EA9n b\u1ECB \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u.");
      }
      const actor = JSON.parse(decodeURIComponent(response.headers.get("X-WorkArea-User") || "")), at = response.headers.get("X-WorkArea-Snapshot-At"), bytes = new Uint8Array(await response.arrayBuffer());
      if (actor.id !== this.meta.profile.id) fail2("B\u1EA3n d\u1EEF li\u1EC7u thu\u1ED9c t\xE0i kho\u1EA3n kh\xE1c.");
      const next = await openDeviceDatabase(bytes);
      if (next.prepare("PRAGMA quick_check").get().quick_check !== "ok") {
        next.close();
        fail2("B\u1EA3n d\u1EEF li\u1EC7u kh\xF4ng h\u1EE3p l\u1EC7.");
      }
      const realm = (_a2 = next.prepare("SELECT value FROM offline_settings WHERE name='realm'").get()) == null ? void 0 : _a2.value;
      if (this.db && this.meta.realm && realm !== this.meta.realm) {
        next.close();
        fail2("Server \u0111ang d\xF9ng b\u1ED9 d\u1EEF li\u1EC7u kh\xE1c. B\u1EA3n tr\xEAn m\xE1y \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn; c\u1EA7n qu\u1EA3n tr\u1ECB kh\xF4i ph\u1EE5c \u0111\xFAng b\u1EA3n sao l\u01B0u.", 409);
      }
      await this.serial(async () => {
        var _a3;
        if (this.pending().length || this.generation !== version) {
          next.close();
          fail2("C\xF3 thao t\xE1c m\u1EDBi trong khi t\u1EA3i. H\xE0ng ch\u1EDD v\u1EABn gi\u1EEF nguy\xEAn; t\u1EA3i l\u1EA1i sau khi \u0111\u1ED3ng b\u1ED9.");
        }
        const previous = this.db;
        this.meta.baseUserId = actor.id;
        this.meta.profile = actor;
        this.meta.snapshotAt = at;
        this.meta.realm = (_a3 = next.prepare("SELECT value FROM offline_settings WHERE name='realm'").get()) == null ? void 0 : _a3.value;
        this.meta.maps = {};
        await change(["base", "meta", "ops"], (tx) => {
          tx.objectStore("base").put(bytes, "active");
          tx.objectStore("meta").put(this.meta, "active");
          tx.objectStore("ops").clear();
        });
        this.db = next;
        this.ops = [];
        previous == null ? void 0 : previous.close();
        for (const url of this.images.values()) URL.revokeObjectURL(url);
        this.images.clear();
        this.replayError = false;
        this.conflict = null;
      });
      this.notify("\u0110\xE3 t\u1EA3i xong. App c\xF3 th\u1EC3 l\xE0m vi\u1EC7c khi m\u1EA5t m\u1EA1ng ho\u1EB7c server l\u1ED7i.");
      this.localImages();
    } catch (error2) {
      if (error2.status === 409) this.conflict = message(error2);
      throw error2;
    } finally {
      this.preparing = false;
      this.paint();
    }
  }
  cancellationGroup(target) {
    const selected = /* @__PURE__ */ new Set([target.id]), affected = /* @__PURE__ */ new Set(), holding = (op) => op.path === "/holding/v2/receive" ? [op.localResult.id] : op.path.startsWith("/holding/v2/") && op.body.rows ? (op.body.rows || []).map((row) => row.id) : op.path.startsWith("/holding/v2/") && op.body.entry_id ? [op.body.entry_id] : [];
    for (const id of holding(target)) affected.add(id);
    for (const op of this.pending().filter((v) => v.seq > target.seq)) {
      const ids = holding(op), dependent = ids.some((id) => affected.has(id)) || target.path === "/holding/v2/delete" && op.path.startsWith("/holding/v2/") || target.path.startsWith("/ckd/") && op.path.startsWith("/ckd/") || target.path === "/scans/delete" && op.path.startsWith("/scans") || target.path === "/scans" && op.path === "/scans/delete" && (op.body.expected || []).some((v) => v.request_id === target.body.request_id);
      if (dependent) {
        selected.add(op.id);
        for (const id of ids) affected.add(id);
      }
    }
    return this.pending().filter((op) => selected.has(op.id));
  }
  async cancelFailed(id) {
    if (this.syncing) fail2("\u0110\u1EE3i l\u01B0\u1EE3t \u0111\u1ED3ng b\u1ED9 hi\u1EC7n t\u1EA1i ho\xE0n t\u1EA5t tr\u01B0\u1EDBc khi h\u1EE7y.");
    return this.serial(async () => {
      const target = this.pending().find((op) => op.id === id);
      if (!(target == null ? void 0 : target.error)) fail2("Ch\u1EC9 h\u1EE7y l\u01B0\u1EE3t \u0111\xE3 \u0111\u01B0\u1EE3c server b\xE1o l\u1ED7i r\xF5 r\xE0ng.");
      const group = this.cancellationGroup(target);
      if (!confirm("H\u1EE7y " + group.length + " thao t\xE1c ch\u01B0a g\u1EEDi g\u1ED3m l\u01B0\u1EE3t l\u1ED7i v\xE0 c\xE1c l\u01B0\u1EE3t ph\u1EE5 thu\u1ED9c? C\xE1c l\u01B0\u1EE3t \u0111\xE3 \u0111\u01B0\u1EE3c server nh\u1EADn v\u1EABn gi\u1EEF nguy\xEAn. H\xE3y t\u1EA3i b\u1EA3n d\u1EF1 ph\xF2ng h\xE0ng ch\u1EDD tr\u01B0\u1EDBc.")) return;
      const ids = new Set(group.map((op) => op.id)), keep = this.ops.filter((op) => !ids.has(op.id)), bytes = await read("base", "active"), fresh = await openDeviceDatabase(bytes), old = this.db;
      this.db = fresh;
      try {
        for (const op of keep) {
          this.apply(op);
          if (op.ack) this.applyReceipt(op);
        }
        await change(["ops", "canceled"], (tx) => {
          for (const op of group) {
            tx.objectStore("ops").delete(op.seq);
            tx.objectStore("canceled").put({ ...op, canceled_at: (/* @__PURE__ */ new Date()).toISOString(), id_mappings: structuredClone(this.meta.maps) });
          }
        });
        this.ops = keep;
        old.close();
        this.generation++;
        this.conflict = null;
        this.notice = "\u0110\xE3 h\u1EE7y " + group.length + " thao t\xE1c ch\u01B0a g\u1EEDi. B\u1EA3n l\u01B0u l\u01B0\u1EE3t h\u1EE7y v\u1EABn gi\u1EEF tr\xEAn m\xE1y v\xE0 c\xF3 trong file d\u1EF1 ph\xF2ng.";
        for (const url of this.images.values()) URL.revokeObjectURL(url);
        this.images.clear();
        this.paint();
      } catch (error2) {
        this.db = old;
        fresh.close();
        throw Error("Ch\u01B0a h\u1EE7y \u0111\u01B0\u1EE3c v\xEC c\xF3 thao t\xE1c ph\u1EE5 thu\u1ED9c. B\u1EA3n g\u1ED1c v\u1EABn gi\u1EEF nguy\xEAn: " + message(error2));
      }
    });
  }
  localImages() {
    if (!this.db || !this.meta.active) return;
    for (const image of document.querySelectorAll('img[src^="/api/"]')) {
      const path = image.getAttribute("src").slice(4);
      if (!/\/image(?:\/|$)/.test(path)) continue;
      try {
        let url = this.images.get(path);
        if (!url) {
          const data = businessApi(this.db, this.meta.profile, path);
          if (!data.binary) continue;
          url = URL.createObjectURL(new Blob([new Uint8Array(data.bytes)], { type: data.mime }));
          this.images.set(path, url);
        }
        image.src = url;
      } catch {
      }
    }
  }
  async saveFile(name, mime, bytes) {
    var _a2;
    if ((_a2 = window.WorkAreaNative) == null ? void 0 : _a2.beginFile) {
      const bridge = window.WorkAreaNative, id = bridge.beginFile(name, mime);
      if (!id) fail2("Ho\xE0n t\u1EA5t h\u1ED9p tho\u1EA1i l\u01B0u file tr\u01B0\u1EDBc ho\u1EB7c ki\u1EC3m tra dung l\u01B0\u1EE3ng \u0111i\u1EC7n tho\u1EA1i.");
      try {
        for (let offset = 0; offset < bytes.length; offset += 65536) {
          if (!bridge.appendFile(id, import_buffer.Buffer.from(bytes.subarray(offset, offset + 65536)).toString("base64"))) fail2("Ch\u01B0a ghi \u0111\u01B0\u1EE3c file. Ki\u1EC3m tra dung l\u01B0\u1EE3ng \u0111i\u1EC7n tho\u1EA1i.");
          if (offset % (32 * 65536) === 0) await new Promise((resolve) => setTimeout(resolve, 0));
        }
        bridge.finishFile(id);
      } catch (error2) {
        bridge.abortFile(id);
        throw error2;
      }
      return;
    }
    const url = URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: mime })), a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3e4);
  }
  async downloadResource(path) {
    const value = businessApi(this.db, this.meta.profile, path);
    if (!value.binary) fail2("Kh\xF4ng ph\u1EA3i file b\xE1o c\xE1o.");
    let bytes = value.bytes;
    if (value.zip) {
      const files = {};
      for await (const file of value.zip()) files[file.name] = file.data;
      bytes = zipSync(files);
    }
    await this.saveFile(value.name || "WorkArea-Offline", value.mime, bytes);
  }
  async render({ target = "#main", embedded = false } = {}) {
    var _a2, _b2;
    const main = document.querySelector(target), profile = this.meta.profile, pending = this.pending();
    if (!this.meta.active) {
      main.innerHTML = '<section class="panel"><h1>Online & Offline</h1><p>\u0110\u0103ng nh\u1EADp \u0111\u1EC3 m\u1EDF d\u1EEF li\u1EC7u v\xE0 h\xE0ng ch\u1EDD c\u1EE7a t\xE0i kho\u1EA3n.</p><a class="button primary" href="#account">\u0110\u0103ng nh\u1EADp</a></section>';
      return;
    }
    main.innerHTML = `<div class="page-top"><a class="back-link" href="#home">\u2190 Trang ch\u1EE7</a><h1>Online & Offline</h1><p class="lead">D\u1EEF li\u1EC7u tr\xEAn \u0111i\u1EC7n tho\u1EA1i \xB7 \u0110\u1ED3ng b\u1ED9 v\u1EDBi server</p></div><section class="panel device-sync-page"><span class="badge ${this.db ? "green" : "amber"}">${this.db ? "\u0110\xE3 c\xF3 d\u1EEF li\u1EC7u offline" : "Ch\u01B0a t\u1EA3i d\u1EEF li\u1EC7u offline"}</span><p>${esc2((profile == null ? void 0 : profile.name) || "C\u1EA7n \u0111\u0103ng nh\u1EADp t\xE0i kho\u1EA3n")}</p><p class="device-sync-time">D\u1EEF li\u1EC7u t\u1EA3i l\xFAc: ${this.meta.snapshotAt ? esc2(new Date(this.meta.snapshotAt).toLocaleString("vi-VN")) : "Ch\u01B0a t\u1EA3i"}</p><p><strong>${pending.length}</strong> thao t\xE1c ch\u1EDD \u0111\u1ED3ng b\u1ED9.</p><p class="notice">QTY, ti\u1EBFn \u0111\u1ED9 SO v\xE0 t\u1ED3n Holding tr\xEAn m\xE1y l\xE0 t\u1EA1m t\xEDnh \u0111\u1EBFn khi server x\xE1c nh\u1EADn. Ch\u1EC9 t\u1EA3i \u0111\u01B0\u1EE3c d\u1EEF li\u1EC7u c\u1EE7a l\u1EA7n \u0111\u1ED3ng b\u1ED9 g\u1EA7n nh\u1EA5t.</p><div class="device-sync-buttons"><button class="button primary" id="offline-sync">G\u1EEDi h\xE0ng ch\u1EDD l\xEAn server</button><button class="button" id="offline-prepare">T\u1EA3i / c\u1EADp nh\u1EADt d\u1EEF li\u1EC7u offline</button><button class="button" id="offline-export">Xu\u1EA5t b\u1EA3n d\u1EF1 ph\xF2ng h\xE0ng ch\u1EDD</button></div><p id="offline-message" class="muted device-sync-message" role="status">${esc2(this.notice)}</p><details class="mt"><summary>\u0110\u0103ng nh\u1EADp server \u0111\u1EC3 \u0111\u1ED3ng b\u1ED9</summary><form id="offline-login"><label class="field">T\xEAn \u0111\u0103ng nh\u1EADp<input name="username" autocomplete="username" required value="${esc2((profile == null ? void 0 : profile.username) || "")}"></label><label class="field">M\u1EADt kh\u1EA9u<input name="password" type="password" autocomplete="current-password" required></label><button class="button primary" type="submit">\u0110\u0103ng nh\u1EADp</button></form></details><ul class="device-sync-list">${pending.slice(0, 100).map((op) => `<li><strong>${esc2(names[op.path] || op.path)}</strong><small>${esc2(op.body.barcode || op.body.samsung || op.body.code || op.body.item_code || op.body.location || "")} \xB7 ${esc2(new Date(op.at).toLocaleString("vi-VN"))}</small>${op.error ? `<p class="notice error">${esc2(op.error)}</p>` : ""}</li>`).join("")}</ul><p class="muted">Kh\xF4ng x\xF3a d\u1EEF li\u1EC7u ho\u1EB7c g\u1EE1 app khi c\xF2n h\xE0ng ch\u1EDD. Nh\u1EADp file d\u1EEF li\u1EC7u v\xE0 qu\u1EA3n l\xFD t\xE0i kho\u1EA3n c\u1EA7n m\u1EA1ng. App ch\u1EC9 t\u1EF1 g\u1EEDi khi \u0111ang m\u1EDF; b\u1EA3n c\u0169 tr\xEAn \u0111i\u1EC7n tho\u1EA1i kh\xF4ng thay cho b\u1EA3n sao l\u01B0u server.</p></section>`;
    if (embedded) {
      (_a2 = main.querySelector(".page-top")) == null ? void 0 : _a2.remove();
      (_b2 = main.querySelector(".device-sync-page")) == null ? void 0 : _b2.insertAdjacentHTML("afterbegin", "<h2>\u0110\u1ED3ng b\u1ED9 offline</h2>");
    }
    const run = (id, fn) => document.querySelector("#" + id).onclick = async (event2) => {
      const button = event2.currentTarget;
      button.disabled = true;
      try {
        await fn();
        if (main.isConnected && (embedded || location.hash === "#offline")) await this.render({ target, embedded });
      } catch (error2) {
        this.notify(message(error2));
      } finally {
        if (button.isConnected) button.disabled = false;
      }
    };
    run("offline-sync", async () => {
      this.conflict = null;
      await this.sync();
    });
    run("offline-prepare", () => this.prepare());
    run("offline-export", async () => {
      const canceled = (await read("canceled") || []).filter((op) => {
        var _a3;
        return ((_a3 = op.actor) == null ? void 0 : _a3.id) === profile.id;
      }), data = { format: 1, exported_at: (/* @__PURE__ */ new Date()).toISOString(), owner: profile, snapshot_at: this.meta.snapshotAt, realm: this.meta.realm, id_mappings: this.meta.maps, pending: this.pending(), acknowledged: this.ops.filter((op) => op.ack), canceled };
      await this.saveFile("WorkArea-Hang-Cho-" + Date.now() + ".json", "application/json", import_buffer.Buffer.from(JSON.stringify(data, null, 2)));
    });
    for (const op of pending.filter((v) => v.error)) {
      const button = document.createElement("button");
      button.className = "button danger mt full";
      button.textContent = "H\u1EE7y l\u01B0\u1EE3t l\u1ED7i v\xE0 " + Math.max(0, this.cancellationGroup(op).length - 1) + " l\u01B0\u1EE3t ph\u1EE5 thu\u1ED9c";
      button.onclick = async () => {
        button.disabled = true;
        try {
          await this.cancelFailed(op.id);
          await this.render({ target, embedded });
        } catch (error2) {
          this.notify(message(error2));
        } finally {
          if (button.isConnected) button.disabled = false;
        }
      };
      document.querySelector(".device-sync-page").append(button);
    }
    document.querySelector("#offline-login").onsubmit = async (event2) => {
      event2.preventDefault();
      const form = event2.currentTarget, button = form.querySelector("button");
      button.disabled = true;
      try {
        await this.login(Object.fromEntries(new FormData(form)));
        form.reset();
        this.conflict = null;
        await this.sync();
        await this.render({ target, embedded });
      } catch (error2) {
        this.notify(message(error2));
      } finally {
        if (button.isConnected) button.disabled = false;
      }
    };
  }
};
var offlineClient = new OfflineClient();
window.WorkAreaOffline = offlineClient;
export {
  offlineClient
};
/*! Bundled license information:

ieee754/index.js:
  (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)

buffer/index.js:
  (*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)
*/
